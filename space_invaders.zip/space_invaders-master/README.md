### Space Invaders

A web-based, browser version of the classic Arcade game: Space Invaders.
Use the arrow keys to move and the space bar to shoot
Every once in a while, a UFO will spawn. If you manage to shoot it down, you may receive a power up item! These power up items can upgrade your weapons or boost speed. Be sure to pick these up quickly because they will disappear!

[Click here to Play Space Invaders](https://jay-ithiel.github.io/space_invaders/)

![space invaders gameplay](images/space_invaders.png)
![space invaders gameplay](images/space_invaders1.png)
![space invaders gameplay](images/space_invaders2.png)
