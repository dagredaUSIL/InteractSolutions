-- -----------------------------------------------------------------------------
--
-- Module:   DATA
--
-- Schema:   80.1
--
-- Revision: $Revision: 100691 $
--
-- Date:     $Date: 2011-12-21 14:04:37 -0200 (Qua, 21 Dez 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-data.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------
-- initialize module versioning
insert into cmn_properties ( name, value ) values ( 'SchemaVersion', '80.1' );
insert into cmn_properties ( name, value ) values ( 'ac.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'am.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'aud.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'bi.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'bpm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'brm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'bsc.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'bud.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'dat.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'cmn.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'clb.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'crt.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'dms.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'ext.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'fav.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'hrm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'lic.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'orm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'qms.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'vfs.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'web.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'prj.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'crm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'ftr_cm.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'snap.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'svc.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'im.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'mob.schema', '80.1' );
insert into cmn_properties ( name, value ) values ( 'wd.schema', '80.1' );

-- create SAS Administrator account
insert into cmn_users
(
    id,
    login,
    password,
    name,
    category,
    "number",
    info,
    email,
    phone1,
    phone2,
    confidence,
    last_version,
    last_login,
    ref_unit,
    type,
    designation,
    certificate,
    authorizations,
    credential,
    options,
    ref_tags
)
values
(
    1,
    'sas',
    '<2fcc1dd51cb7514a99f03debf513ca7af3b25669>',
    'Administrador do SAS',
    5,
    '',
    '',
    '',
    '',
    '',
    1,
    '',
    null,
    0,
    0,
    '',
    0,
    0,
    0,
    '',
    0
);

-- create SAS Anonymous account
insert into cmn_users
(
    id,
    login,
    password,
    name,
    category,
    "number",
    info,
    email,
    phone1,
    phone2,
    confidence,
    last_version,
    last_login,
    ref_unit,
    type,
    designation,
    certificate,
    authorizations,
    credential,
    options,
    ref_tags
)
values
(
    2,
    'anonimo',
    '<5ba7d31bb3360b040f77122307c58be97cc61c41>',
    'Anonymous',
    3,
    '',
    '',
    '',
    '',
    '',
    1,
    '',
    null,
    0,
    0,
    '',
    0,
    0,
    0,
    '',
    0
);

insert into cmn_units ( id, state, name, info, type,ref_tags ) values ( 1, 0, 'Strategic Adviser', '', 0, 0 );
insert into cmn_departments ( id, ref_unit, state, name, info, ref_tags, mnemonic ) values ( 1, 1, 0, 'Sistema', '', 0, '#1' );
insert into cmn_sectors ( id, ref_department, state, name, info, ref_tags, mnemonic ) values ( 1, 1, 0, 'Default', '', 0, '#1' );
insert into cmn_functions(id, ref_category, ref_type_function, name, info, sex, age, salary, experience, state) values(1, 1, 2, 'Default', '', '', '', '', '', 0);
insert into cmn_employments(id, ref_user, ref_function, is_default, dt_from, dt_until, state, info, ref_category, ref_unit, ref_department, ref_sector) values (1, 1, 1, 1, null, null, 1, '', 0, 1, 1, 1);
insert into hrm_categories(id, ref_user, name, description, family, state) values (1, 1, 'Cargos', '', 3, 1);
insert into hrm_categories(id, ref_user, name, description, family, state) values (2, 1, 'Administrador do SA', '', 1, 1);
insert into hrm_employment_states ( family, ref_source, num_qualified, num_unqualified ) values ( 1, 1, 0, 0 );
insert into hrm_employment_states ( family, ref_source, num_qualified, num_unqualified ) values ( 0, 1, 0, 0 );

insert into cmn_roles ( cmn_roles.id, cmn_roles.role, cmn_roles.ref_user, cmn_roles.permission ) values ( 1, 'anonymous.app.documents', 2, 1 );
insert into cmn_roles ( cmn_roles.id, cmn_roles.role, cmn_roles.ref_user, cmn_roles.permission ) values ( 2, 'anonymous.app.occurrences', 2, 1 );
insert into cmn_roles ( cmn_roles.id, cmn_roles.role, cmn_roles.ref_user, cmn_roles.permission ) values ( 3, 'anonymous.app.survey', 2, 1 );
-- -----------------------------------------------------------------------------
-- insere os atributos
-- -----------------------------------------------------------------------------  

insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(1,0,0,'@serial','Variável de sistema referente ao serial da instância do processo','serial',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(2,0,0,'@mnemonic','Variável de sistema referente ao mnemonic do processo','mnemonic',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(3,0,0,'@processOwner','Variável de sistema referente ao usuário responsável pelo processo','processOwner',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(4,0,0,'@taskClaimer','Variável de sistema referente ao usuário que assumiu a tarefa','taskClaimer',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(5,0,0,'@loggedUser', 'Usuário logado no sistema','loggedUser',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(6,0,0,'@t_min', 'Tempo mínimo de execução do processo','t_min',1,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(7,0,0,'@t_max', 'Tempo máximo de execução do processo','t_max',1,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(8,0,0,'@t_avg', 'Tempo médio de execução do processo','t_avg',1,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(10,0,0,'@processInstanceOwner','Variável de sistema referente ao usuário responsável pela instância de processo','processInstanceOwner',3,0,0,0,0,'','',0,0,0);
insert into bpm_attributes (id,ref_process,ref_parent_attribute,mnemonic,info,label,family,ref_option,scope,seq,"precision",link,family_data,fl_hidden,disposition,doc_type) values(11,0,0,'@lastTaskUser','Variável de sistema referente ao usuário responsável pela última atividade completada na instância de processo','lastTaskUser',3,0,0,0,0,'','',0,0,0);


-- -----------------------------------------------------
-- Data for table crm_classifications
-- -----------------------------------------------------
-- FAMILY_RATING = 0
insert into crm_classifications (id, family, name, info, domain, seqno) values (1, 0, 'Standard', 'Contas padrão', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (2, 0, 'Corporate', 'Contas diferenciados', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (3, 0, 'Small Business', 'Contas menores', '', 0);

-- FAMILY_SEGMENT = 1
insert into crm_classifications (id, family, name, info, domain, seqno) values (4, 1, 'Agência de Publicidade', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (5, 1, 'Alimentos', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (6, 1, 'Consultoria', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (7, 1, 'Construção', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (8, 1, 'Petroquímica', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (9, 1, 'Hospitalar', '', '', 0);

-- FAMILY_ORIGIN = 2
insert into crm_classifications (id, family, name, info, domain, seqno) values (10, 2, 'Revista HSM', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (11, 2, 'Evento Hospitalar 2012', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (12, 2, 'Mail Marketing', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (13, 2, 'Visita', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (14, 2, 'Indicação', '', '', 0);

-- FAMILY_INFLUENCE = 3
insert into crm_classifications (id, family, name, info, domain, seqno) values (15, 3, 'Decisor Financeiro', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (16, 3, 'Decisor Técnico', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (17, 3, 'Contato Estratégico', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (18, 3, 'Sem Influência', '', '', 0);

-- FAMILY_POSITION = 4
insert into crm_classifications (id, family, name, info, domain, seqno) values (19, 4, 'Favorável Interact', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (20, 4, 'Favorável Concorrente', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (21, 4, 'Neutro', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (22, 4, 'Não identificado', '', '', 0);

-- FAMILY_REASON_CONQUEST = 5
insert into crm_classifications (id, family, name, info, domain, seqno) values (23, 5, 'Melhor Preço', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (24, 5, 'Melhor Produto', '', '', 0);

-- FAMILY_REASON_LOSS = 6
insert into crm_classifications (id, family, name, info, domain, seqno) values (25, 6, 'Valor Elevado', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (26, 6, 'Produto Inferior', '', '', 0);

-- FAMILY_OPPORTUNITY = 7
insert into crm_classifications (id, family, name, info, domain, seqno) values (27, 7, 'Licenciamento', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (28, 7, 'Locação', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (29, 7, 'Ampliação', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (30, 7, 'On Demand', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (31, 7, 'Capacitação', '', '', 0);

-- FAMILY_ATTACHMENT = 8
insert into crm_classifications (id, family, name, info, domain, seqno) values (32, 8, 'Proposta', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (33, 8, 'Contrato', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (34, 8, 'Aceite', '', '', 0);

-- FAMILY_ITEM_CLASSIFICATION = 9
insert into crm_classifications (id, family, name, info, domain, seqno) values (35, 9, 'Produto', '', '', 0);
insert into crm_classifications (id, family, name, info, domain, seqno) values (36, 9, 'Serviço', '', '', 0);

-- -----------------------------------------------------
-- Data for table cus_crm_country
-- -----------------------------------------------------
insert into crm_countries (id, name, acronym, currency, language) values (1, 'Brasil', 'BR', 'BRL', 'Português Brasil');
insert into crm_countries (id, name, acronym, currency, language) values (2, 'Argentina', 'AR', 'USD', 'Espanhol');
insert into crm_countries (id, name, acronym, currency, language) values (3, 'Colômbia', 'CO', 'USD', 'Espanhol');
insert into crm_countries (id, name, acronym, currency, language) values (4, 'México', 'MX', 'USD', 'Espanhol');
insert into crm_countries (id, name, acronym, currency, language) values (5, 'Peru', 'PE', 'USD', 'Espanhol');

-- -----------------------------------------------------
-- Data for table crm_states
-- -----------------------------------------------------
insert into crm_states (id, ref_country, name, acronym) values (1, 1, 'Rio Grande do Sul', 'RS');
insert into crm_states (id, ref_country, name, acronym) values (2, 1, 'Santa Catarina', 'SC');
insert into crm_states (id, ref_country, name, acronym) values (3, 1, 'Paraná', 'PR');
insert into crm_states (id, ref_country, name, acronym) values (4, 1, 'São Paulo', 'SP');
insert into crm_states (id, ref_country, name, acronym) values (5, 1, 'Rio de Janeiro', 'RJ');
insert into crm_states (id, ref_country, name, acronym) values (6, 1, 'Minas Gerais', 'MG');
insert into crm_states (id, ref_country, name, acronym) values (7, 1, 'Espírito Santo', 'ES');
insert into crm_states (id, ref_country, name, acronym) values (8, 1, 'Bahia', 'BA');
insert into crm_states (id, ref_country, name, acronym) values (9, 1, 'Mato Grosso do Sul', 'MS');
insert into crm_states (id, ref_country, name, acronym) values (10, 1, 'Mato Grosso', 'MT');
insert into crm_states (id, ref_country, name, acronym) values (11, 1, 'Goiás', 'GO');
insert into crm_states (id, ref_country, name, acronym) values (12, 1, 'Distrito Federal', 'DF');
insert into crm_states (id, ref_country, name, acronym) values (13, 1, 'Tocantins', 'TO');
insert into crm_states (id, ref_country, name, acronym) values (14, 1, 'Amazonas', 'AM');
insert into crm_states (id, ref_country, name, acronym) values (15, 1, 'Acre', 'AC');
insert into crm_states (id, ref_country, name, acronym) values (16, 1, 'Rondônia', 'RO');
insert into crm_states (id, ref_country, name, acronym) values (17, 1, 'Roraima', 'RR');
insert into crm_states (id, ref_country, name, acronym) values (18, 1, 'Pará', 'PA');
insert into crm_states (id, ref_country, name, acronym) values (19, 1, 'Amapá', 'AP');
insert into crm_states (id, ref_country, name, acronym) values (20, 1, 'Maranhão', 'MA');
insert into crm_states (id, ref_country, name, acronym) values (21, 1, 'Piauí', 'PI');
insert into crm_states (id, ref_country, name, acronym) values (22, 1, 'Rio Grande do Norte', 'RN');
insert into crm_states (id, ref_country, name, acronym) values (23, 1, 'Ceará', 'CE');
insert into crm_states (id, ref_country, name, acronym) values (24, 1, 'Sergipe', 'SE');
insert into crm_states (id, ref_country, name, acronym) values (25, 1, 'Alagoas', 'AL');
insert into crm_states (id, ref_country, name, acronym) values (26, 1, 'Paraíba', 'PB');
insert into crm_states (id, ref_country, name, acronym) values (27, 1, 'Pernambuco', 'PE');

-- -----------------------------------------------------
-- Data for table crm_status
-- -----------------------------------------------------
insert into crm_status (id, name, is_closed, seqno) values (1, 'Em Negociação', 0, 1);
insert into crm_status (id, name, is_closed, seqno) values (2, 'Eminente de Fechamento', 0, 2);
insert into crm_status (id, name, is_closed, seqno) values (3, 'Fechada - Conquistado', 1, 3);
insert into crm_status (id, name, is_closed, seqno) values (4, 'Fechada - Perdido', 1, 4);

-- -----------------------------------------------------
-- Data for table cus_crm_social_network
-- -----------------------------------------------------
insert into crm_networks (id, name, domain) values (1, 'E-mail', '.E_MAIL' );
insert into crm_networks (id, name, domain) values (2, 'Site', '.SITE' );
insert into crm_networks (id, name, domain) values (3, 'Newsletter', '.SUBSCRIPTION' );
insert into crm_networks (id, name, domain) values (4, 'MSN', '' );
insert into crm_networks (id, name, domain) values (5, 'Skype', '' );
insert into crm_networks (id, name, domain) values (6, 'Facebook', '' );
insert into crm_networks (id, name, domain) values (7, 'Linkedin', '' );
insert into crm_networks (id, name, domain) values (8, 'Twitter', '' );
insert into crm_networks (id, name, domain) values (9, 'G+', '' );

-- -----------------------------------------------------
-- Data for table crm_identities
-- -----------------------------------------------------
insert into crm_identities (id, name, ref_country, mask) values (1, 'CPF', 1, '999.999.999-99');
insert into crm_identities (id, name, ref_country, mask) values (2, 'CNPJ', 1, '99.999.999.9999/99');

-- -----------------------------------------------------
-- Data for table crm_item_type 
-- ref_classification:
-- Produto = 35
-- Serviço = 36
-- -----------------------------------------------------
insert into crm_item_types (id, ref_classification, name, unit) values (1, 35, 'Performance Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (2, 35, 'Competence Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (3, 35, 'Survey Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (4, 35, 'Business Process Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (5, 35, 'Contract Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (6, 35, 'Occurrence Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (7, 35, 'Document Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (8, 35, 'Audit Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (9, 35, 'Risk Manager', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (10, 35, 'Business Intelligence', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (11, 35, 'Suíte SA - Strategic Adviser', 'Suíte');
insert into crm_item_types (id, ref_classification, name, unit) values (12, 36, 'Treinamento', 'Horas');
insert into crm_item_types (id, ref_classification, name, unit) values (13, 36, 'Projeto', 'Horas');
insert into crm_item_types (id, ref_classification, name, unit) values (14, 36, 'Custom', 'Licenças');
insert into crm_item_types (id, ref_classification, name, unit) values (15, 36, 'Integrações', 'Licenças');


-- -----------------------------------------------------
-- Script para inserção na tabela ftr_CM_RELEVANCES:
-- -----------------------------------------------------

insert into ftr_cm_relevances (id, name, description, period, state, seqno) values (1, 'Irrelevante', 'Abrangência: limites da organização. Impacto sobre o meio/pessoa/organização: irrisório; A falta dos serviços não ocasionará perdas e dados para a organização', 365, 0, 0);
insert into ftr_cm_relevances (id, name, description, period, state, seqno) values (2, 'Pouco Relevante', 'Abrangência: limites da organização. Impacto sobre o meio/pessoa/organização: pontual; A falta dos serviços ocasionará perdas e dados a longo prazo para a organização', 183, 0, 0);
insert into ftr_cm_relevances (id, name, description, period, state, seqno) values (3, 'Relevante', 'Abrangência: outros limites além da organização. Impacto sobre o meio/pessoa/organização: reversível a longo prazo; A falta dos serviços ocasionará perdas e dados a curto prazo para a organização', 60, 0, 0);
insert into ftr_cm_relevances (id, name, description, period, state, seqno) values (4, 'Muito Relevante', 'Abrangência: outros limites além da organização. Impacto sobre o meio/pessoa/organização: irreversível; A falta dos serviços ocasionará perdas e dados irreversíveis para a organização', 30, 0, 0);

-- -----------------------------------------------------
-- Script para inserção nas tabelas ftr_cm_supplier_scale e ftr_cm_supplier_scale_OPTIONS
-- -----------------------------------------------------

insert into ftr_cm_supplier_scales (id, ref_suppliers, name, type, state, info) values (1, 0, 'Escala de Qualificação', 1, 0, 'Escala criada para avaliação de qualificação dos fornecedores');
insert into ftr_cm_supplier_scales (id, ref_suppliers, name, type, state, info) values (2, 0, 'Escala de Desempenho', 2, 0, 'Escala criada para avaliação de desempenho dos fornecedores');
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (1, 1, 'Não Qualificar', 0, 60, -52480);
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (2, 1, 'Qualificar com Restrições', 60, 80, -205);
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (3, 1, 'Qualificar Pleno', 80, 100, -13369600);
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (4, 2, 'Desqualificar', 0, 60, -52480);
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (5, 2, 'Solicitar Ação Corretiva', 60, 80, -205);
insert into ftr_cm_supplier_scale_options (id, ref_supplier_scale, name, score_from, score_until, color) values (6, 2, 'Manter Qualificação', 80, 100, -13369600);

-- -----------------------------------------------------
-- Script para inserção nas tabelas ftr_cm_questionnaire_scales e ftr_cm_questions_scale_options:
-- -----------------------------------------------------

insert into ftr_cm_questionnaire_scales (id, ref_questionnaire, name, type, state) values (1, 0, 'Escala de Qualificação', 1, 0);
insert into ftr_cm_questionnaire_scales (id, ref_questionnaire, name, type, state) values (2, 0, 'Escala de Desempenho', 2, 0);
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (1, 1, 'Sim', 1, ' ');
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (2, 1, 'Não', -1, ' ');
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (3, 1, 'n/a', 2, ' ');
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (4, 2, 'Sim', 1, ' ');
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (5, 2, 'Não', -1, ' ');
insert into ftr_cm_questions_scale_options (id, ref_questionnaire_scale, name, score, info) values (6, 2, 'n/a', 2, ' ');

-- -----------------------------------------------------
-- Script para inserção nas tabelas ftr_cm_actions e ftr_cm_topics_actions:
-- -----------------------------------------------------

insert into ftr_cm_actions (id, name, state, type, info) values (1, 'Notificação através de Registro da Não Conformidade', 0, 0, 'Não Conformidade');
insert into ftr_cm_actions (id, name, state, type, info) values (2, 'Nova Realização de serviço', 0, 1, 'Novo Serviço');
insert into ftr_cm_actions (id, name, state, type, info) values (3, 'Compensação através de serviços', 0, 2, 'Compensação');
insert into ftr_cm_actions (id, name, state, type, info) values (4, 'Compensação Financeira', 0, 3, 'Compensação');

-- -----------------------------------------------------
-- Script para inserção nas tabelas ftr_cm_type_activities
-- -----------------------------------------------------

insert into ftr_cm_type_activities (id, name, state, info, seqno) values (1, 'Aluguéis (Locação)', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (2, 'Prestação de Serviços', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (3, 'Comodato', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (4, 'Mútuo', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (5, 'Repasses', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (6, 'Bancários', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (7, 'Fornecedores', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (8, 'Outros', 0, '', 0);
insert into ftr_cm_type_activities (id, name, state, info, seqno) values (9, 'Operadora', 0, '', 0);

update cmn_sequences set id = 3 where name = 'ftr_cm_questionnaire_scales.id';
update cmn_sequences set id = 6 where name = 'ftr_cm_questions_scale_options.id';

-- -----------------------------------------------------
-- Default calendar
-- -----------------------------------------------------
insert into cmn_calendars (id, name, ref_calendar, is_default, ref_project, begin_tolerance, end_tolerance, login_control ) values ( 0, 'DEFAULT', 0, 1, 0, 0, 0, 0 );
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 0, 0, 2, '08:00:00', '12:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 1, 0, 2, '13:30:00', '18:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 2, 0, 3, '08:00:00', '12:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 3, 0, 3, '13:30:00', '18:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 4, 0, 4, '08:00:00', '12:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 5, 0, 4, '13:30:00', '18:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 6, 0, 5, '08:00:00', '12:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 7, 0, 5, '13:30:00', '18:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 8, 0, 6, '08:00:00', '12:00:00');
insert into cmn_calendar_schedules (id, ref_calendar, week_day, tm_begin, tm_end ) values ( 9, 0, 6, '13:30:00', '18:00:00');
