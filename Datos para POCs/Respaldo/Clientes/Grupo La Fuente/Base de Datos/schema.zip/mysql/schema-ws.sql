-- ----------------------------------------------------------------------------
--
-- Module:   WS - WebServices
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL$
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- WS_CONTRACTS
--
-- Stores: com.interact.sas.ws.data.Contract
-- -----------------------------------------------------------------------------
create table ws_contracts
(
    id              int             not null,
    state           tinyint         not null,    -- See: com.interact.sas.ws.data.Contract.STATE
    alias           varchar(64)     not null,
    domain          varchar(80)     not null,
    name            varchar(160)    not null,
    info            text            not null,
    
    primary key ( id ),
    unique ( alias )
);
create index ix_ws_contracts_domain on ws_contracts ( domain );
create index ix_ws_contracts_alias  on ws_contracts ( alias );
create index ix_ws_contracts_state  on ws_contracts ( state );

-- -----------------------------------------------------------------------------
-- WS_ACCESSES
--
-- Stores: com.interact.sas.ws.data.Access
-- -----------------------------------------------------------------------------
create table ws_accesses
(
    id              int            not null, 
    ref_contract    int            not null,    -- References: ws_contracts.id
    usage_count     int            not null,
    state           tinyint        not null,    -- See: com.interact.sas.ws.data.Access.STATE 
    service         varchar(64)    not null,
    application     varchar(64)    not null,
    secret          varchar(64)    not null,
    info            text           not null,

    primary key ( id ),
    unique ( ref_contract, service, application )
);
create index ix_ws_accesses_contract    on ws_accesses ( ref_contract );
create index ix_ws_accesses_service     on ws_accesses ( service );
create index ix_ws_accesses_application on ws_accesses ( application );

-- -----------------------------------------------------------------------------
-- WS_SESSIONS
--
-- Stores: com.interact.sas.ws.data.Session
-- -----------------------------------------------------------------------------
create table ws_sessions
(
    id              int            not null, 
    ref_contract    int            not null,    -- References: ws_contracts.id
    ref_access      int            not null,    -- References: ws_accesses.id
    request_count   int            not null,
    state           tinyint        not null,    -- See: com.interact.sas.ws.data.Session.STATE
    started         timestamp      not null,
    closed          timestamp      null,
    timeout         timestamp      null,
    alias           varchar(64)    not null,
    
    primary key ( id ),
    unique ( alias )
);
create index ix_ws_sessions_contract on ws_sessions ( ref_contract );
create index ix_ws_sessions_access   on ws_sessions ( ref_access );
create index ix_ws_sessions_alias    on ws_sessions ( alias );