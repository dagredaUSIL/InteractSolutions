-- ----------------------------------------------------------------------------
--
-- Module:   LIC
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-lic.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- LIC_SESSIONS
--
-- Stores: com.interact.sas.cmn.data.Session
-- -----------------------------------------------------------------------------
create table lic_sessions
(
    ref_login   int             not null,    -- References: cmn_logins.id
    origin      varchar(80)     not null,
    module      varchar(40)     not null,
    instance    varchar(250)    not null,
    age         double          not null
);

-- -----------------------------------------------------------------------------
-- LIC_REQUESTS
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table lic_requests
(
    origin      varchar(80)     not null,
    granted     int             not null,
    denied      int             not null
);

-- -----------------------------------------------------------------------------
-- LIC_SCORES
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table lic_scores
(
    origin      varchar(80)     not null,
    module      varchar(40)     not null,
    score       int             not null,
    peek        int             not null
);

-- -----------------------------------------------------------------------------
-- LIC_MEMORY
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table lic_memory
(
    origin        varchar(80)    not null,
    mem_alloc     int            not null,
    mem_avail     int            not null,
    mem_usage     double         not null,
    dt_recorded   timestamp      not null,

    primary key( origin )
);