-- ----------------------------------------------------------------------------
--
-- Module:   QMS
--
-- Schema:   80.1
--
-- Revision: $Revision: 107682 $
--
-- Date:     $Date: 2012-04-04 11:14:59 -0300 (Qua, 04 Abr 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-qms.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------


-- --------------------------------------------------------
-- QMS_CATEGORIES
--
-- Stores: com.interact.sas.qms.data.OccurrenceCategory
-- --------------------------------------------------------
create table qms_categories
(
    id                      int             not null,
    ref_owner               int             not null,    -- References: cmn_users.id
    ref_serial              int             not null,    -- References: cmn_serials.id
    state                   int             not null,    -- See: com.interact.sas.qms.data.OccurrenceCategory.STATUS 
    seq_no                  smallint        not null,
    name                    varchar(80)     not null,
    info                    text            not null,
    
    primary key ( id ),
    unique ( name )
);

-- --------------------------------------------------------
-- QMS_FAVOURITES
--
-- Stores: com.interact.sas.qms.data.OccurrenceFavourite
-- --------------------------------------------------------
create table qms_favourites
(
    id                      int             not null,
    ref_owner               int             not null,    -- References: cmn_users.id
    ref_field               int             not null,    -- References: qms_fields.id
    ref_team                int             not null,    -- References: cmn_groups.id
    ref_scope               int             not null,    -- References: scope id
    state                   int             not null,    -- See: com.interact.sas.qms.data.OccurrenceFavourite.STATE
    scope                   tinyint         not null,    -- See: com.interact.sas.qms.data.OccurrenceFavourite.SCOPE
    ts_created              timestamp       null default null,
    mnemonic                varchar(40),
    name                    varchar(120)    not null,
    info                    text            not null,

    primary key  ( id )
);
create index qms_favourites_owner     on qms_favourites (ref_owner);
create index qms_favourites_field     on qms_favourites (ref_field);
create index qms_favourites_mnemonic  on qms_favourites (mnemonic);
create index qms_favourites_ref_team  on qms_favourites (ref_team);
create index qms_favourites_ref_scope on qms_favourites (ref_scope);

-- --------------------------------------------------------
-- QMS_FAVOURITE_ITEMS
--
-- Stores: com.interact.sas.qms.data.OccurrenceFavouriteItem
-- --------------------------------------------------------
create table qms_favourite_items
(
    ref_favourite     int         not null,    -- References: qms_favourites.id
    ref_occurrence    int         not null,    -- References: qms_occurrences.id
    classification    smallint    not null,

    unique key (ref_favourite, ref_occurrence)
);

-- --------------------------------------------------------
-- QMS_FILTERS
--
-- Stores: com.interact.sas.qms.data.OccurrenceFilter
-- --------------------------------------------------------
create table qms_filters
(
    id                      int             not null,
    ref_owner               int             not null,    -- References: cmn_users.id
    family                  tinyint         not null,
    scope                   tinyint         not null,
    mnemonic                varchar(40),
    name                    varchar(200)    not null,
    info                    text            not null,

    primary key  ( id )
);

-- --------------------------------------------------------
-- QMS_FILTER_ITEMS
--
-- Stores: com.interact.sas.qms.data.OccurrenceFilterItem
-- --------------------------------------------------------
create table qms_filter_items
(
    ref_filter              int             not null,    -- References: qms_filters.id
    ref_field               int             not null,    -- References: qms_fields.id
    state                   tinyint         not null,    -- See: com.interact.sas.qms.data.OccurrenceFilterItem.STATE
    type                    tinyint         not null,
    value                   varchar(4000)   not null,
	context					varchar(255)	not null
);

create index qms_filter_items_filter on qms_filter_items (ref_filter);
create index qms_filter_items_field  on qms_filter_items (ref_field);

-- --------------------------------------------------------
-- QMS_FORMS
--
-- Stores: N/A
-- --------------------------------------------------------
create table qms_forms
(
    ref_user    int             not null,    -- References: cmn_users.id
    ref_type    int             not null,    -- References: qms_types.id
    type        int             null,

    unique ( ref_user, ref_type, type )
);

create index qms_forms_user on qms_forms (ref_user);
create index qms_forms_type on qms_forms (ref_type);

-- --------------------------------------------------------
-- QMS_OCCURRENCES
--
-- Stores: com.interact.sas.qms.data.Occurrence
-- --------------------------------------------------------
create table qms_occurrences
(
    id                            int              not null,
    ref_created_by                int              not null,    -- References: cmn_users.id
    ref_category                  int              not null,    -- References: qms_categories.id
    ref_type                      int              not null,    -- References: qms_types.id
    ref_actionplan_analysis       int              not null,    -- References: bsc_actionplans.id
    ref_actionplan_disposition    int              not null,    -- References: bsc_actionplans.id
    ref_previous                  int              not null,    -- References: qms_occurrences.id
    ref_accepted_by               int              not null,    -- References: cmn_users.id
    ref_analised_by               int              not null,    -- References: cmn_users.id
    ref_approved_by               int              not null,    -- References: cmn_users.id
    ref_executed_by               int              not null,    -- References: cmn_users.id
    ref_owner                     int              not null,    -- References: cmn_users.id
    ref_event_accepted            int              not null,    -- References: qms_events.id
    ref_event_approved            int              not null,    -- References: qms_events.id
    ref_event_executed            int              not null,    -- References: qms_events.id
    ref_event_verified            int              not null,    -- References: cmn_users.id
    ref_verified_by               int              not null,    -- References: cmn_users.id
    restriction                   int              not null,
    initiative_count              int              not null,
    context_count                 int              not null,
    archived                      tinyint          not null,
    state                         smallint         not null,  
    execute_state                 smallint         default null,
    priority                      smallint         not null,
    workflow                      smallint         not null,
    stage_origin                  smallint         not null,
    stage_current                 smallint         not null,
    dt_created                    date             not null,
    dt_analyse_due                date             default null,
    dt_analysed                   date             default null,
    dt_execute_estim_start        date             default null,
    dt_execute_estim_end          date             default null,
    dt_execute_real_start         date             default null,
    dt_execute_real_end           date             default null,
    dt_approve_due                date             default null,
    dt_execute_due                date             default null,
    dt_verify_due                 date             default null,
    dt_last_verification          date             default null,
    next_update                   date             default null,
    serial                        varchar(24)      not null,
    "options"                     varchar(32)      not null,
    reason                        varchar(160)     not null,
    disposition                   varchar(160)     not null,
    title                         varchar(160)     not null,
    sector                        varchar(250)     not null,
    description                   text             not null,

    
    
    primary key ( id )
);
create index qms_occurrences_restriction    on      qms_occurrences ( restriction );
create index qms_occurrences_state          on      qms_occurrences ( state );
create index qms_occurrences_created        on      qms_occurrences ( ref_created_by );
create index qms_occurrences_category       on      qms_occurrences ( ref_category );
create index qms_occurrences_type           on      qms_occurrences ( ref_type );
create index qms_occurrences_analysis       on      qms_occurrences ( ref_actionplan_analysis );
create index qms_occurrences_disposition    on      qms_occurrences ( ref_actionplan_disposition );
create index qms_occurrences_previous       on      qms_occurrences ( ref_previous );
create index qms_occurrences_accepted       on      qms_occurrences ( ref_accepted_by );
create index qms_occurrences_analised       on      qms_occurrences ( ref_analised_by );
create index qms_occurrences_approved       on      qms_occurrences ( ref_approved_by );
create index qms_occurrences_executed       on      qms_occurrences ( ref_executed_by );
create index qms_occurrences_verified       on      qms_occurrences ( ref_verified_by );
create index qms_occurrences_owner          on      qms_occurrences ( ref_owner );
create index qms_occurrences_evaccepted     on      qms_occurrences ( ref_event_accepted );
create index qms_occurrences_evapproved     on      qms_occurrences ( ref_event_approved );
create index qms_occurrences_evexecuted     on      qms_occurrences ( ref_event_executed );
create index qms_occurrences_evverified     on      qms_occurrences ( ref_event_verified );
create index qms_occurrences_created_on     on      qms_occurrences ( dt_created );
create index qms_occurrences_archived       on      qms_occurrences ( archived );
create index qms_occurrences_workflow       on      qms_occurrences ( workflow );
create index qms_occurrences_dt_analysed    on      qms_occurrences ( dt_analysed );
create index qms_occu_stage_origin          on      qms_occurrences ( stage_origin );
create index qms_occu_stage_current         on      qms_occurrences ( stage_current );

-- --------------------------------------------------------
-- QMS_TYPES
--
-- Stores: com.interact.sas.qms.data.OccurrenceType
-- --------------------------------------------------------
create table qms_types
(
    id                     int              not null,
    ref_serial             int              not null,    -- References: cmn_serials.id
    ref_team               int              not null,    -- References: cmn_groups.id
    ref_accepted_by        int              not null,    -- References: cmn_users.id
    ref_analised_by        int              not null,    -- References: cmn_users.id
    ref_approved_by        int              not null,    -- References: cmn_users.id
    ref_category           int              not null,    -- References: qms_categories.id
    ref_executed_by        int              not null,    -- References: cmn_users.id
    ref_owner              int              not null,    -- References: cmn_users.id
    ref_verified_by        int              not null,    -- References: cmn_users.id
    ref_tags               int              not null,    -- References: cmn_tag_kinds.id
    ref_registered_by      int              not null,    -- References: cmn_users.id
    ref_family             int              not null,
    state                  int              not null,
    restriction            int              not null,
    is_public              int              not null,
    type_accepted_by       tinyint          not null,
    type_analised_by       tinyint          not null,
    type_approved_by       tinyint          not null,
    type_executed_by       tinyint          not null,
    type_verified_by       tinyint          not null,
    type_registered_by     tinyint          not null,
    workflow               smallint         not null,
    seq_no                 smallint         not null,
    options                char(128)        not null,
    mnemonic               varchar(40)      not null,
    name                   varchar(80)      not null,
    info                   text             not null,

    primary key ( id ),
    unique ( mnemonic )
);
create index qms_types_restriction   on qms_types ( restriction );
create index qms_types_tags          on qms_types ( ref_tags );
create index qms_types_registered_by on qms_types ( ref_registered_by );

-- --------------------------------------------------------
-- QMS_OPTIONS
--
-- Stores: com.interact.sas.qms.data.OccurrenceOption
-- --------------------------------------------------------
create table qms_options
(
    id              int              not null,
    ref_category    int              not null,    -- References: qms_categories.id
    name            varchar(160)     not null,
    info            varchar(4000)    not null,

    primary key ( id )
);
create index qms_options_category on qms_options (ref_category);

-- --------------------------------------------------------
-- QMS_OPTIONS_ITEMS
--
-- Stores: com.interact.sas.qms.data.OccurrenceOptionItem
-- --------------------------------------------------------
create table qms_option_items
(
    id            int             not null,
    ref_option    int             not null,    -- References: qms_options.id
    position      int             not null,
    state         tinyint         not null,    -- See: com.interact.sas.qms.data.OccurrenceOptionItem.STATES 
    value         varchar(250)    not null,
    
    primary key (id)
);

-- --------------------------------------------------------
-- QMS_CAUSES
--
-- Stores: com.interact.sas.qms.data.OccurrenceCause
-- --------------------------------------------------------
create table qms_causes
(
    id                     int              not null,
    ref_occurrence         int              not null,    -- References: qms_occurrences.id
    type                   smallint         not null,    -- See: com.interact.sas.qms.data.OccurrenceCause.TYPE_NAMES 
    name                   varchar(160)     not null,
    info                   text             not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- QMS_FIELDS
--
-- Stores: com.interact.sas.qms.data.OccurrenceField
-- --------------------------------------------------------
create table qms_fields
(
    id                     int             not null,
    ref_type               int             not null,    -- References: qms_types.id
    ref_option             int             not null,    -- References: qms_options.id
    ref_parent             int             not null,    -- References: qms_fields.id
    ref_tab                int             not null,    -- References: qms_tabs.id
    "options"              int             not null,    -- See: com.interact.sas.qms.data.OccurrenceField.OPTION
    restriction            int             null,
    scope                  tinyint         not null,
    data_type              tinyint         not null,    -- See: com.interact.sas.qms.data.OccurrenceField.TYPE
    notification           tinyint         not null,
    position               smallint        not null,
    classification         smallint        not null,
    label                  varchar(40)     not null,
    mnemonic               varchar(40)     not null,
    data_family            varchar(250),
    info                   text            not null,

    primary key ( id ),
    unique ( ref_type, mnemonic )
);
create index qms_fields_tab         on qms_fields( ref_tab );
create index qms_fields_restriction on qms_fields( restriction );

-- --------------------------------------------------------
-- QMS_VALUES
--
-- Stores: com.interact.sas.qms.data.FieldValue
-- --------------------------------------------------------
create table qms_values
(
    ref_occurrence         int             not null,    -- References: qms_occurrences.id
    ref_field              int             not null,    -- References: qms_fields.id
    content                varchar(255)    not null,
    type                   int             not null
);

create index ix_qms_values_field       on qms_values ( ref_field );
create index ix_qms_values_occurrence  on qms_values ( ref_occurrence );
create index ix_qms_values_content     on qms_values ( content );
create index ix_qms_values_type        on qms_values ( type );

-- --------------------------------------------------------
-- QMS_CONSTRAINTS
--
-- Stores: com.interact.sas.qms.data.OccurrenceConstraint
-- --------------------------------------------------------
create table qms_constraints 
(
    ref_field     int    not null,    -- References: qms_fields.id
    ref_option    int    not null,    -- References: qms_options.id
    ref_item      int    not null,    -- References: item id
    
    unique key ( ref_field, ref_item )
);
create index qms_constraints_field     on qms_constraints ( ref_field );
create index qms_constraints_option    on qms_constraints ( ref_option );
create index qms_constraints_item      on qms_constraints ( ref_item );

-- -----------------------------------------------------
-- QMS_EVENTS
--
-- Stores: com.interact.sas.qms.data.OccurrenceEvent
-- -----------------------------------------------------
create table qms_events 
(
    id                int          not null,
    ref_occurrence    int          not null,    -- References: qms_occurrences.id
    ref_owner_in      int          not null,    -- References: cmn_users.id
    ref_owner_out     int          not null,    -- References: cmn_users.id
    stage_input       int          not null,
    stage_output      int          not null,
    action            int          not null,    -- See: com.interact.sas.qms.data.OccurrenceEvent.ACTIONS 
    final_state       tinyint      not null,
    origin            tinyint      not null,
    created_at        timestamp    not null,
    info              text,
    
    primary key  (id)
);
create index qms_events_occurrence   on qms_events ( ref_occurrence );
create index qms_events_owner_in     on qms_events ( ref_owner_in );
create index qms_events_owner_out    on qms_events ( ref_owner_out );
create index qms_events_created      on qms_events ( created_at );
create index qms_events_stage_in     on qms_events ( stage_input );
create index qms_events_stage_out    on qms_events ( stage_output );
create index qms_events_action       on qms_events ( action );

-- -----------------------------------------------------
-- QMS_INFORMATIONS
--
-- Stores: com.interact.sas.qms.data.OccurrenceFieldInformation
-- -----------------------------------------------------
create table qms_informations
(
    ref_occurrence    int     not null,    -- References: qms_occurrences.id
    ref_field         int     not null,    -- References: qms_fields.id
    info              text    not null,
    
    unique key (ref_occurrence, ref_field)
);
create index qms_info_occurrence    on qms_informations ( ref_occurrence );
create index qms_info_field         on qms_informations ( ref_field );

-- -----------------------------------------------------
-- QMS_NOTIFICATIONS
--
-- Stores: com.interact.sas.qms.data.OccurrenceNotification
-- -----------------------------------------------------
create table qms_notifications
(
    ref_source        int    not null,    -- References: source item id
    ref_occurrence    int    not null,    -- References: qms_occurrences.id
    family            int    not null,    -- See: com.interact.sas.qms.data.OccurrenceNotification.FAMILIES 
    options           int    not null,
    
    unique key (family, ref_source, ref_occurrence)
);

-- -----------------------------------------------------
-- QMS_TYPES_INDICATORS
--
-- Stores: com.interact.sas.qms.data.OccurrenceTypeIndicator
-- -----------------------------------------------------
create table qms_types_indicators
(
    ref_indicator    int    not null,    -- References: bsc_indicators.id
    ref_type         int    not null,    -- References: qms_types.id
    stage            int    not null,

    unique ( ref_indicator, ref_type, stage )
);
create index qms_types_indicators_ref_indicator    on qms_types_indicators( ref_indicator );
create index qms_types_indicators_ref_type         on qms_types_indicators( ref_type );
create index qms_types_indicators_stage            on qms_types_indicators( stage );

-- -----------------------------------------------------
-- QMS_MONITOR
--
-- Stores: com.interact.sas.qms.data.OccurrenceMonitor
-- -----------------------------------------------------
create table qms_monitor
(
    ref_type    int,    -- References: qms_types.id
    ref_user    int,    -- References: cmn_users.id
    stage       int,    -- See: com.interact.sas.qms.data.OccurrenceMonitor.STAGE

    unique(ref_type, ref_user, stage )
);

-- -------------------------------------------------------------------
-- QMS_TABS
--
-- Stores: com.interact.sas.qms.data.OccurrenceFieldTab
-- -------------------------------------------------------------------
create table qms_tabs
(
    id          int            not null,
    label       varchar(80)    not null,
    ref_type    int            not null,    -- References: qms_types.id
    position    int            not null,
    scope       int            not null,
  
    primary key( id )
);
create index qms_tabs_type on qms_tabs( ref_type );

-- --------------------------------------------------------
-- QMS_RANDOM_SERIALS
--
-- Stores: com.interact.sas.qms.data.OccurrenceRandomSerial
-- --------------------------------------------------------
create table qms_random_serials
(
    ref_occurrence    int             not null,    -- References: qms_occurrences.id
    random_serial     varchar (80)    not null,
    email             varchar (80),

    unique ( ref_occurrence, random_serial )
);
create index qms_random_serials_occurrence on qms_random_serials ( ref_occurrence );