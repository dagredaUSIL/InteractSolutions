-- ----------------------------------------------------------------------------
--
-- Module:   WEB - WEB Access
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-web.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--

-- -----------------------------------------------------------------------------
-- WEB_EMBEDDINGS
--
-- Stores: com.interact.sas.web.data.Embedding
-- -----------------------------------------------------------------------------
create table web_embeddings
(
    ref_owner     int             not null,    -- References: cmn_users.id
    dt_created    timestamp       not null,
    uuid          varchar(40)     not null,
    name          varchar(250)    not null,
    source        varchar(250)    not null,


    primary key ( uuid )
);

-- -------------------------------------------------------------------
-- WEB_TOKENS
--
-- Stores: com.interact.sas.web.data.Token
-- -------------------------------------------------------------------
create table web_tokens
(
    keep       smallint         not null,
    token      varchar(36)      not null,
    content    varchar(4000)    not null,

    primary key (token)
);