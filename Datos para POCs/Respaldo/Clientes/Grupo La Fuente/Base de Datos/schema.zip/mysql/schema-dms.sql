-- ----------------------------------------------------------------------------
--
-- Module:   DMS
--
-- Schema:   80.1
--
-- Revision: $Revision: 92575 $
--
-- Date:     $Date: 2011-07-14 08:20:17 -0300 (Qui, 14 Jul 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-dms.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- DMS_BASELINE_DOCUMENTS
--
-- Stores: com.interact.sas.dms.data.DocumentBaseline
-- --------------------------------------------------------
create table dms_baseline_documents
(
    ref_document             int       not null,    -- References: dms_documents.id
    ref_baseline_document    int       not null,    -- References: dms_documents.id

    unique ( ref_document, ref_baseline_document )
);
create index dms_bas_doc_ref_doc     on dms_baseline_documents ( ref_document );
create index dms_bas_doc_ref_bas_doc on dms_baseline_documents ( ref_baseline_document );

-- --------------------------------------------------------
-- DMS_FOLDERS
--
-- Stores: com.interact.sas.dms.data.DocumentFolder
-- --------------------------------------------------------
create table dms_folders
(
    id               int            not null,
    ref_parent       int            not null,    -- References: dms_folders.id
    ref_owner        int            not null,    -- References: cmn_users.id
    ref_team         int            not null,    -- References: cmn_groups.id
    ref_tags         int            not null,
    restriction      int            not null,
    classification   int            not null,
    num_childs       smallint       not null,
    name             varchar(250)   not null,
    parents          varchar(250)   not null,
    info             text           not null,

    primary key ( id ),
    unique ( ref_parent, name )
);
create index dms_folders_name     on dms_folders ( name );
create index dms_folders_class    on dms_folders ( classification );
create index dms_folders_ref_par  on dms_folders ( ref_parent );
create index dms_folders_ref_ow   on dms_folders ( ref_owner );
create index dms_folders_ref_team on dms_folders ( ref_team );
create index dms_folders_restr    on dms_folders ( restriction );
create index dms_folders_tags     on dms_folders ( ref_tags );

-- --------------------------------------------------------
-- DMS_CATEGORIES
--
-- Stores: com.interact.sas.dms.data.DocumentCategory
-- --------------------------------------------------------
create table dms_categories
(
    id                    int            not null,
    ref_folder            int            not null,    -- References: dms_folders.id
    ref_owner             int            not null,    -- References: cmn_users.id
    ref_serial            int            not null,    -- References: cmn_serials.id
    ref_tags              int            not null,    -- References: cmn_tag_kinds.id
    expiration_period     int            not null,    
    expiration_tolerance  int            not null,
    max_versions          int            not null,
    fl_default_expiration smallint       not null,
    classification        varchar(80)    not null,
    name                  varchar(100)   not null,
    options               char(128)      not null,    -- See: com.interact.sas.dms.data.DocumentCategory.OPTION
    info                  text           not null,
	
    primary key ( id ),
    unique ( classification, name )
);
create index dms_categ_ref_folder    on dms_categories( ref_folder );
create index dms_categ_ref_owner     on dms_categories( ref_owner );
create index dms_categ_ref_serial    on dms_categories( ref_serial );
create index dms_categories_tags     on dms_categories( ref_tags );

-- --------------------------------------------------------
-- DMS_DOCUMENTS
--
-- Stores: com.interact.sas.dms.data.Document
-- --------------------------------------------------------
create table dms_documents
(
    id                   int            not null,
    ref_category         int            not null,    -- References: dms_categories.id
    ref_folder           int            not null,    -- References: dms_folders.id
    ref_owner            int            not null,    -- References: cmn_users.id
    ref_compound         int            not null,    -- References: dms_documents.id
    ref_distributed      int            not null,    -- References: dms_distributions.id
    ref_rule             int            not null,    -- References: cmn_rules.id
    ref_original         int            not null,    -- References: dms_documents.id
    ref_tags             int            not null,    -- References: cmn_tag_kinds.id
    id_work              int            not null,
    restriction          int            not null,
    "size"               int            not null,
    release_count        int            not null,
    quarentine_stage     int            not null,
    reject_count         int            not null,
    indexation           tinyint        not null,
    signature_state      tinyint        not null,    -- See: com.interact.sas.dms.data.Document.SIGNATURE_STATE
    autoconversion_state tinyint        not null,    -- See: com.interact.sas.dms.data.Document.AUTOCONVERSION
    template             tinyint        not null,
    state                smallint       not null,    -- See: com.interact.sas.dms.data.Document.STATES
    quarantine           smallint       not null,    -- See: com.interact.sas.dms.data.Document.QUARANTINE
    doc_type             smallint       not null,
    workflow             smallint       not null,    -- See: com.interact.sas.dms.data.Document.WORKFLOW
    conversion           smallint       not null,
    conversion_state     smallint       not null,
    requested            smallint       not null,
    dt_prorogation       date           default null,
    dt_creation          date           not null,
    dt_valid_from        date           default null,
    dt_valid_until       date           default null,
    dt_checkin           date           default null,
    dt_checkout          date           default null,
    dt_verified          date           default null,
    dt_approved          date           default null,
    version              varchar(8)     not null,
    code                 varchar(24)    not null,
    type                 varchar(32)    not null,
    signature            varchar(42),
    medium               varchar(160)   not null,
    location             varchar(160)   not null,
    lifetime             varchar(160)   not null,
    disposition          varchar(160)   not null,
    name                 varchar(250)   not null,
    description          text           not null,
    topics               text           not null,
    justification        text           default null,

    primary key ( id )
);
create index dms_documents_folder       on dms_documents ( ref_folder );
create index dms_documents_restriction  on dms_documents ( restriction );
create index dms_documents_state        on dms_documents ( state );
create index dms_documents_quarantine   on dms_documents ( quarantine );
create index dms_documents_owner        on dms_documents ( ref_owner );
create index dms_documents_valid_until  on dms_documents ( dt_valid_until );
create index dms_documents_work         on dms_documents ( id_work );
create index dms_documents_name         on dms_documents ( name );
create index dms_documents_code         on dms_documents ( code );
create index dms_documents_sig_state    on dms_documents ( signature_state );
create index dms_documents_tags         on dms_documents ( ref_tags );

-- --------------------------------------------------------
-- DMS_COPIES
--
-- Stores: com.interact.sas.dms.data.LocalCopy
-- --------------------------------------------------------
create table dms_copies
(
    ref_document     int            not null,    -- References: dms_documents.id
    ref_owner        int            not null,    -- References: cmn_users.id
    dt_obtained      date           not null,
    local_path       varchar(250)   not null,

    unique ( ref_document, ref_owner )
);

-- --------------------------------------------------------
-- DMS_DISTRIBUTIONS
--
-- Stores: com.interact.sas.dms.data.DocumentDistribution
-- --------------------------------------------------------
create table dms_distributions
(
    id               int            not null,
    ref_work         int            not null,    -- References: dms_documents.id_work
    ref_owner        int            not null,    -- References: cmn_users.id
    quantity         smallint       not null,
    location         varchar(160)   not null,
    info             varchar(255)   not null,

    primary key ( id )
);
create index dms_distributions_ref_owner on dms_distributions ( ref_owner );
create index dms_distributions_ref_work  on dms_distributions ( ref_work );

-- --------------------------------------------------------
-- DMS_SUBSCRIPTIONS
--
-- Stores: com.interact.sas.dms.data.DocumentSubscription
-- --------------------------------------------------------
create table dms_subscriptions
(
    ref_work         int            not null,    -- References: dms_documents.id_work
    ref_user         int            not null,    -- References: cmn_users.id

    unique ( ref_work, ref_user )
);

-- --------------------------------------------------------
-- DMS_HISTORY
--
-- Stores: N/A
-- --------------------------------------------------------
create table dms_history
(
    ref_document int            not null,    -- References: dms_documents.id
    ref_user     int            not null,    -- References: cmn_users.id
    dt_access    date           not null,

    unique ( ref_document, ref_user, dt_access )
);
create index dms_history_document on dms_history ( ref_document );
create index dms_history_user on dms_history ( ref_user );
create index dms_history_access on dms_history ( dt_access );

-- --------------------------------------------------------
-- DMS_ACCESS
--
-- Stores: com.interact.sas.dms.data.DocumentAccess
-- --------------------------------------------------------
create table dms_access
(
    ref_document    int     not null,    -- References: dms_documents.id
    ref_user        int     not null,    -- References: cmn_users.id
    access_count    int     not null,
    last_access     date    default null,

    unique ( last_access, ref_document, ref_user )
);

-- --------------------------------------------------------
-- DMS_CONTROLLERS
--
-- Stores: com.interact.sas.dms.data.DocumentController
-- --------------------------------------------------------
create table dms_controllers 
( 
    ref_category         int         not null,    -- References: dms_categories.id
    ref_user             int         not null,    -- References: cmn_users.id
    ref_controller_group int         not null,    -- References: dms_controller_groups.id
    stage_position       int         not null,
    realization_period   int         not null,
    signature            tinyint     not null,    -- See: com.interact.sas.dms.data.DocumentController.SIGNATURE
    action               smallint    not null,
    required             smallint    not null,
    options              varchar(32) not null,
    stage                varchar(80) not null,

    unique ( ref_category, ref_user, ref_controller_group, action, stage )
);

-- --------------------------------------------------------
-- DMS_EVENTS
--
-- Stores: com.interact.sas.dms.data.DocumentEvent
-- --------------------------------------------------------
create table dms_events
(
    id                   int           not null,
    ref_document         int           not null,    -- References: dms_documents.id
    ref_user             int           not null,    -- References: cmn_users.id
    ref_controller_group int           not null,    -- References: dms_controller_groups.id
    release_count        int           not null,
    origin               int           not null,
    stage_position       int           not null,
    type                 smallint      not null,    -- See: com.interact.sas.dms.data.DocumentEvent.TYPES
    dt_created           timestamp     not null,
    dt_ocurred           timestamp     null,
    dt_due               date          default null,
    info                 text          not null,


    primary key ( id )
);
create index dms_events_document on dms_events ( ref_document );
create index dms_events_user     on dms_events ( ref_user );
create index dms_events_ocurred  on dms_events ( dt_ocurred );
create index dms_events_type     on dms_events ( type );
create index dms_events_comp     on dms_events ( ref_document, type, release_count, dt_ocurred );

-- ---------------------------------------------------------
-- DMS_FEATURES
--
-- Stores: N/A
-- --------------------------------------------------------
create table dms_features
(
    ref_work             int     not null,    -- References: dms_documents.id_work
    ref_requirement      int     not null,    -- References: cmn_requirements.id

    unique ( ref_work, ref_requirement )
);

-- --------------------------------------------------------
-- DMS_RECEIPTS
--
-- Stores: com.interact.sas.dms.data.Receipts
-- --------------------------------------------------------
create table dms_receipts
(
    id                int            not null,
    ref_document      int            not null,    -- References: dms_documents.id
    ref_owner         int            not null,    -- References: cmn_users.id
    num_copies        smallint       not null,
    situation         smallint       not null,
    dt_printed        date           default null,
    dt_received       date           default null,
    dt_loss           date           default null,
    dt_returned       date           default null,
    location          varchar(602)   not null,
    info_loss         text           default null,
    info              text           not null,

    primary key ( id )
);
create index dms_receipts_ref_document on dms_receipts ( ref_document );
create index dms_receipts_ref_owner    on dms_receipts ( ref_owner );
create index dms_receipts_situation    on dms_receipts ( situation );

-- --------------------------------------------------------
-- DMS_TEMPLATES
--
-- Stores: N/A
-- --------------------------------------------------------
create table dms_templates
(
    ref_user          int            not null,    -- References: cmn_users.id
    ref_work          int            not null,    -- References: dms_documents.id_work

    unique ( ref_user, ref_work )
);
create index dms_templates_user on dms_templates ( ref_user );
create index dms_templates_work on dms_templates ( ref_work );

-- --------------------------------------------------------
-- DMS_REFERENCES
--
-- Stores: com.interact.sas.dms.data.Reference
-- --------------------------------------------------------
create table dms_references
(
    ref_master       int       not null,    -- References: dms_documents.id
    ref_work         int       not null,    -- References: dms_documents.id_work
    autoupdate       tinyint   not null,

    unique ( ref_master, ref_work )
);

-- --------------------------------------------------------
-- DMS_REPORTS
--
-- Stores: com.interact.sas.dms.data.DocumentReportLayout
-- --------------------------------------------------------
create table dms_reports
(
    id              int             not null,
    orientation     smallint        not null,    -- See: com.interact.sas.dms.data.DocumentReportLayout.ORIENTATION
    name            varchar(80)     not null,
    "columns"       text            not null,
    info            text            not null,

    primary key ( id )
);
create index dms_reports_name on dms_reports ( name );

-- --------------------------------------------------------
-- DMS_CONTROLLER_GROUPS
--
-- Stores: com.interact.sas.dms.data.DocumentControllerGroup
-- --------------------------------------------------------
create table dms_controller_groups
(
    id                  int             not null,
    ref_owner           int             not null,    -- References: cmn_users.id
    ref_team_verified   int             not null,    -- References: cmn_groups.id
    ref_team_approved   int             not null,    -- References: cmn_groups.id
    state               tinyint         default 1,   -- See: com.interact.sas.dms.data.DocumentControllerGroup.STATES
    classification      varchar(80)     not null,
    name                varchar(80)     not null,

    primary key ( id )
);
create index dms_control_g_name         on dms_controller_groups ( name );
create index dms_control_g_class        on dms_controller_groups ( classification );
create index dms_control_g_ref_owner    on dms_controller_groups ( ref_owner );
create index dms_control_g_ref_team_ver on dms_controller_groups ( ref_team_verified );
create index dms_control_g_ref_team_app on dms_controller_groups ( ref_team_approved );

-- --------------------------------------------------------
-- DMS_PORTFOILS
--
-- Stores: com.interact.sas.dms.data.Portfoil
-- --------------------------------------------------------
create table dms_portfoils
(
    ref_type_origin		smallint	not null,
    ref_source          int         not null,    -- References: id source item
    ref_source_origin   int         not null,    -- References: id source item
    ref_document        int         not null,    -- References: dms_documents.id
    ref_owner           int         not null,    -- References: cmn_users.id
    type                smallint	not null,    -- See: com.interact.sas.dms.data.Portfoil.TYPES
    state               smallint	not null,    -- See: com.interact.sas.dms.data.Portfoil.STATE
    active              smallint	not null,
    dt_confirmation     date		default null,
    dt_read             date		default null,
    dt_created          timestamp   null
);
create index dms_portfoil_type          on dms_portfoils (type);
create index dms_portfoil_source        on dms_portfoils (ref_source);
create index dms_portfoil_source_origin on dms_portfoils (ref_source_origin);
create index dms_portfoil_type_origin   on dms_portfoils (ref_type_origin);
create index dms_portfoil_document      on dms_portfoils (ref_document);
create index dms_portfoils_owner        on dms_portfoils ( ref_owner);

-- --------------------------------------------------------
-- DMS_CATALOG_PAGES
--
-- Stores: com.interact.sas.dms.data.CatalogPage
-- --------------------------------------------------------
create table dms_catalog_pages
(
    id                 int                  not null,
    options            varchar(32)          not null,
    mnemonic           varchar(40)          not null,
    title              varchar(160)         not null,
    info               text                 not null,

    primary key ( id ),
    unique (mnemonic)
);

-- --------------------------------------------------------
-- DMS_CATALOG_SECTIONS
--
-- Stores: com.interact.sas.dms.data.CatalogSection
-- --------------------------------------------------------
create table dms_catalog_sections
(
    id                 int                  not null,
    ref_page           int                  not null,    -- References: dms_catalog_pages.id
    ref_parent         int                  not null,    -- References: dms_catalog_sections.id
    title              varchar(160)         not null,
    position           smallint             not null,
	
    primary key ( id )
);
create index dms_catalog_sections_page on dms_catalog_sections( ref_page );
create index dms_catalog_secs_ref_par on dms_catalog_sections( ref_parent );

-- --------------------------------------------------------
-- DMS_CATALOG_ITEMS
--
-- Stores: com.interact.sas.dms.data.CatalogItem
-- --------------------------------------------------------
create table dms_catalog_items
(
    id                 int                  not null,
    ref_section        int                  not null,    -- References: dms_catalog_sections.id
    ref_document       int                  not null,    -- References: dms_documents.id
    ref_parent         int                  not null,    -- References: dms_catalog_items.id
    alias              varchar(40)          not null,
    position           smallint             not null,
    options            int                  not null,
	
    primary key ( id ),
    unique ( alias )
);
create index dms_catalog_items_section  on dms_catalog_items( ref_section );
create index dms_catalog_items_document on dms_catalog_items( ref_document );
create index dms_catalog_items_parent   on dms_catalog_items( ref_parent );
create index dms_catalog_items_posit    on dms_catalog_items( position );

-- --------------------------------------------------------
-- DMS_SIGNATURES
--
-- Stores: com.interact.sas.dms.data.Signature
-- --------------------------------------------------------
create table dms_signatures
(
    id           int       not null,
    ref_document int       not null,    -- References: dms_documents.id
    ref_user     int       not null,    -- References: cmn_users.id
    ref_event    int       not null,    -- References: dms_events.id
    role         smallint  not null,    -- See: com.interact.sas.dms.data.Signature.ROLES
    dt_created   timestamp not null,
    signature    text,

    primary key ( id )
);
create index dms_signatures_document on dms_signatures( ref_document );
create index dms_signatures_user     on dms_signatures( ref_user );
create index dms_signatures_event    on dms_signatures( ref_event );

-- --------------------------------------------------------
-- DMS_NOTES
--
-- Stores: com.interact.sas.dms.data.DocumentNote
-- --------------------------------------------------------
create table dms_notes
(
    id           int       not null,
    ref_owner    int       not null,    -- References: cmn_users.id
    ref_document int       not null,    -- References: dms_documents.id
    "release"    int       not null,
    stage        int       not null,    -- See: com.interact.sas.dms.data.DocumentNote.STAGE
    type         int       not null,    -- See: com.interact.sas.dms.data.DocumentNote.TYPE
    page         int       not null,
    dt_creation  timestamp not null,
    dt_update    timestamp null,
    message      text      not null,
    data         text      not null,
    
    primary key ( id )
);
create index dms_notes_owner    on dms_notes ( ref_owner );
create index dms_notes_document on dms_notes ( ref_document );
create index dms_notes_page     on dms_notes ( page );
create index dms_notes_type     on dms_notes ( type );
create index dms_notes_stage    on dms_notes ( stage );
create index dms_notes_update   on dms_notes ( dt_update );