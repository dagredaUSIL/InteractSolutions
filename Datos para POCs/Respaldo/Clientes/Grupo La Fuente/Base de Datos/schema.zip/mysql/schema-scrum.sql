-- --------------------------------------------------------
--
-- Module:   SCRUM
--
-- Schema:   80.1
--
-- Revision: $Revision: 100701 $
--
-- Date:     $Date: 2011-12-21 15:01:03 -0200 (Qua, 21 Dez 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-ac.sql $
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- --------------------------------------------------------

-- -----------------------------------------------------------------------------
-- SCRUM_GROUPS
--
-- Stores: com.interact.sas.web.zk.scrum.data.Group
-- -----------------------------------------------------------------------------
create table scrum_groups
(
    id          int         not null,
    ref_owner   int         not null,    -- References: cmn_users.id
    mnemonic    varchar(40) not null,
    name        varchar(40) not null,
    info        text,
    
    primary key (id),
    unique (mnemonic)
);
create index scrum_groups_owner on scrum_groups (ref_owner);

-- -----------------------------------------------------------------------------
-- SCRUM_CATEGORIES
--
-- Stores: com.interact.sas.web.zk.scrum.data.Category
-- -----------------------------------------------------------------------------
create table scrum_categories
(
    id          int         not null,
    ref_group   int         not null,    -- References: scrum_groups.id
    position    int         not null,
    state       tinyint     not null,
    name        varchar(80) not null,
    mnemonic    varchar(40) not null,
    
    primary key (id)
);
create index scrum_categories_group on scrum_categories (ref_group);

-- -----------------------------------------------------------------------------
-- SCRUM_CLASSIFICATIONS
--
-- Stores: com.interact.sas.web.zk.scrum.data.Classification
-- -----------------------------------------------------------------------------
create table scrum_classifications
(
    id          int         not null,
    ref_group   int         not null,    -- References: scrum_groups.id
    position    int         not null,
    state       tinyint     not null,
    name        varchar(80) not null,
    mnemonic    varchar(40) not null,

    primary key (id)
);
create index scrum_classifications_group on scrum_classifications (ref_group);

-- -----------------------------------------------------------------------------
-- SCRUM_SPRINTS
--
-- Stores: com.interact.sas.web.zk.scrum.data.Sprint
-- -----------------------------------------------------------------------------
create table scrum_sprints
(
    id          int         not null,
    ref_owner   int         not null,    -- References: cmn_users.id
    ref_group   int         not null,    -- References: scrum_groups.id
    ref_team    int         not null,    -- References: cmn_teams.ref_team
    alias       varchar(20) not null,
    info        text,

    primary key (id),
    unique (alias)
);
create index scrum_sprints_owner on scrum_sprints (ref_owner);
create index scrum_sprints_group on scrum_sprints (ref_group);
create index scrum_sprints_team  on scrum_sprints (ref_team);

-- -----------------------------------------------------------------------------
-- SCRUM_SPRINT_INSTANCES
--
-- Stores: com.interact.sas.web.zk.scrum.data.SprintInstance
-- -----------------------------------------------------------------------------    
create table scrum_sprint_instances
(
    id          int         not null,
    ref_sprint  int         not null,    -- References: scrum_sprints.id
    ref_owner   int         not null,    -- References: cmn_users.id
    ref_team    int         not null,    -- References: cmn_teams.ref_team
    state       tinyint     not null,
    serial      varchar(80) not null,
    dt_from     date        not null,
    dt_until    date        not null,
    annotation  text,

    primary key (id),
    unique (serial)
);
create index scrum_sprint_instances_sprint on scrum_sprint_instances (ref_sprint);
create index scrum_sprint_instances_owner  on scrum_sprint_instances (ref_owner);
create index scrum_sprint_instances_team   on scrum_sprint_instances (ref_team);

-- -----------------------------------------------------------------------------
-- SCRUM_SPRINT_ITEMS
--
-- Stores: com.interact.sas.web.zk.scrum.data.Item
-- -----------------------------------------------------------------------------    
create table scrum_sprint_items
(
    id                  int          not null,
    ref_sprint_instance int          not null,    -- References: scrum_sprint_instances.id
    ref_category        int          not null,    -- References: scrum_categories.id
    ref_classification  int          not null,    -- References: scrum_classifications.id
    estimated           int          not null,
    duration            int          not null,
    seq_no              int          not null,
    type                tinyint      not null,
    protocol            varchar(40),
    name                varchar(160) not null,
    info                text,
    
    primary key (id)
);
create index scrum_sprint_items_instance    on scrum_sprint_items (ref_sprint_instance);
create index scrum_sprint_items_category    on scrum_sprint_items (ref_category);
create index scrum_sprint_items_classificat on scrum_sprint_items (ref_classification);

-- -----------------------------------------------------------------------------
-- SCRUM_SPRINT_TASKS
--
-- Stores: com.interact.sas.web.zk.scrum.data.Task
-- -----------------------------------------------------------------------------
create table scrum_sprint_tasks
(
    id                 int          not null,
    ref_sprint_item    int          not null,    -- References: scrum_sprint_items.id
    ref_category       int          not null,    -- References: scrum_categories.id
    ref_classification int          not null,    -- References: scrum_classifications.id
    ref_owner          int          not null,    -- References: cmn_users.id
    estimated          int          not null,
    duration           int          not null,
    seq_no             int          not null,
    state              tinyint      not null,
    is_current         tinyint      not null,
    type               tinyint      not null,
    protocol           varchar(40),
    name               varchar(160) not null,
    dt_from            datetime,
    dt_until           datetime,
    info               text,

    primary key (id)
);
create index scrum_sprint_tasks_item        on scrum_sprint_tasks (ref_sprint_item);
create index scrum_sprint_tasks_category    on scrum_sprint_tasks (ref_category);
create index scrum_sprint_tasks_classificat on scrum_sprint_tasks (ref_classification);
create index scrum_sprint_tasks_owner       on scrum_sprint_tasks (ref_owner);