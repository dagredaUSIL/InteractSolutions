-- ----------------------------------------------------------------------------
--
-- Module:   SVC 
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL$
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- SVC_SERVICES
--
-- Stores: com.interact.sas.svc.data.Service
-- --------------------------------------------------------
create table svc_services
(
    id                int              not null,
    ref_category      int              not null,    -- References: cmn_categories.id
    ref_serial        int              not null,    -- References: cmn_serials.id
    ref_owner         int              not null,    -- References: cmn_users.id
    ref_team          int              not null,    -- References: cmn_groups.id
    ref_tags          int              not null,    -- References: cmn_tag_kinds.id
    restriction       int              not null,
    state             tinyint          not null,    -- See: com.interact.sas.svc.data.Service.STATES
    mnemonic          varchar(40)      not null,
    name              varchar(160)     not null,
    info              varchar(4000)    not null,

    primary key ( id )
);
create index ix_svc_services_category    on svc_services( ref_category );
create index ix_svc_services_serial      on svc_services( ref_serial );
create index ix_svc_services_owner       on svc_services( ref_owner );
create index ix_svc_services_restriction on svc_services( restriction );
create index ix_svc_services_team        on svc_services( ref_team );
create index svc_services_tags           on svc_services( ref_tags );

-- --------------------------------------------------------
-- SVC_PROVIDERS
--
-- Stores: com.interact.sas.svc.data.Provider
-- --------------------------------------------------------
create table svc_providers
(
    id                     int             not null,
    ref_category           int             not null,    -- References: cmn_categories.id
    ref_owner              int             not null,    -- References: cmn_users.id
    ref_tags               int             not null,    -- References: cmn_tag_kinds.id
    type                   tinyint         not null,    -- See: com.interact.sas.svc.data.Provider.TYPES
    state                  tinyint         not null,    -- See: com.interact.sas.svc.data.Provider.STATES
    requirements_state     tinyint         not null,
    dt_last_performance    date            null,
    dt_next_performance    date            null,
    country                char(2)         not null,
    uf                     varchar(10)     not null,
    cep                    varchar(10)     not null,
    options                varchar(32)     not null,
    "identity"             varchar(40)     not null,
    legal_name             varchar(160)    not null,
    public_name            varchar(160)    not null,
    address                varchar(200)    not null,
    location               varchar(200)    not null,
    region                 varchar(200)    not null,
    info                   text            not null,

    primary key ( id )
);
create index ix_svc_providers_category on svc_providers( ref_category );
create index ix_svc_providers_owner    on svc_providers( ref_owner );
create index svc_providers_tags        on svc_providers( ref_tags );

-- --------------------------------------------------------
-- SVC_PROVIDER_CONTACTS
--
-- Stores: com.interact.sas.svc.data.ProviderContact
-- --------------------------------------------------------
create table svc_provider_contacts
(
    id                     int             not null,
    ref_provider           int             not null,    -- References: svc_providers.id
    position               tinyint         not null,
    type                   varchar(40)     not null,
    phone                  varchar(40)     not null,
    name                   varchar(160)    not null,
    email                  varchar(160)    not null,
    info                   text            not null,
    primary key ( id )
);
create index ix_svc_provider_cont_prov on svc_provider_contacts( ref_provider );

-- --------------------------------------------------------
-- SVC_CONTRACTS
--
-- Stores: com.interact.sas.svc.data.Contract
-- --------------------------------------------------------
create table svc_contracts
(
    id                  int                   not null,
    ref_provider        int                   not null,    -- References: svc_providers.id
    ref_service         int                   not null,    -- References: svc_services.id
    ref_owner           int                   not null,    -- References: cmn_users.id
    ref_tags            int                   not null,
    restriction         int                   not null,
    state               tinyint               not null,    -- See: com.interact.sas.svc.data.Contract.STATES
    contract_value      double                not null,
    dt_from             date                  not null, 
    dt_until            date                  null,
    dt_signature        date                  not null,
    dt_negotiation      date                  null,
    dt_readjustment     date                  null,
    currency            varchar(30)           not null,
    serial              varchar(32)           not null,
    contract_adjustment varchar(160)          not null,
    invoice_day         varchar(160)          not null,
    name                varchar(160)          not null,
    info                text                  not null,

    primary key ( id )
);
create index ix_svc_contracts_prov     on svc_contracts( ref_provider );
create index ix_svc_contracts_serv     on svc_contracts( ref_service );
create index ix_svc_contracts_owner    on svc_contracts( ref_owner );
create index ix_svc_contracts_restrict on svc_contracts( restriction );
create index svc_contracts_tags        on svc_contracts( ref_tags );

-- --------------------------------------------------------
-- SVC_PROVIDER_CANDIDATES
--
-- Stores: N/A
-- --------------------------------------------------------
create table svc_provider_candidates
(
    ref_provider        int                   not null,    -- References: svc_providers.id
    ref_service         int                   not null,    -- References: svc_services.id
    
    unique(ref_provider,ref_service)  
);

-- --------------------------------------------------------
-- SVC_CONTRACT_REQUIREMENTS
--
-- Stores: com.interact.sas.svc.data.ContractRequirement
-- --------------------------------------------------------
create table svc_contract_requirements
(
    id                  int          not null,
    ref_contract        int          not null,    -- References: svc_contracts.id
    ref_requirement     int          not null,    -- References: svc_service_requirements.id
    ref_approver        int          not null,    -- References: cmn_users.id
    ref_document        int          not null,    -- References: dms_documents.id
    version             int          not null,
    origin              tinyint      not null,
    state               tinyint      not null,    -- See: com.interact.sas.svc.data.ContractRequirement.STATES
    dt_from             date         not null,
    dt_limit            date         not null,
    dt_approval         date,
    info                text,
    name                varchar(160) not null,

    primary key (id)
);
create index svc_cont_req_ref_contract    on svc_contract_requirements(ref_contract);
create index svc_cont_req_ref_requirement on svc_contract_requirements(ref_requirement);
create index svc_cont_req_ref_approver    on svc_contract_requirements(ref_approver);
create index svc_cont_req_ref_document    on svc_contract_requirements(ref_document);

-- --------------------------------------------------------
-- SVC_SERVICE_REQUIREMENTS
--
-- Stores: com.interact.sas.svc.data.ServiceRequirement
-- --------------------------------------------------------
create table svc_service_requirements 
(
    id                 int             not null,
    ref_service        int             not null,    -- References: svc_services.id
    validity_limit     int             not null,
    type               tinyint         not null,    -- See: com.interact.sas.svc.data.ServiceRequirement.TYPES
    validity_unit      tinyint         not null,
    "option"           tinyint         not null,    -- See: com.interact.sas.svc.data.ServiceRequirement.OPTIONS
    state              tinyint         not null,
    name               varchar(160)    not null,
    info               text,

    primary key (id)
);
create index svc_serv_req_ref_service on svc_service_requirements(ref_service);

-- --------------------------------------------------------
-- SVC_EVALUATIONS
--
-- Stores: com.interact.sas.svc.data.Evaluation
-- --------------------------------------------------------
create table svc_evaluations
(
    id                  int                  not null,
    ref_contract        int                  not null,    -- References: svc_contracts.id  
    ref_provider        int                  not null,    -- References: svc_providers.id
    ref_service         int                  not null,    -- References: svc_services.id
    ref_checklist       int                  not null,    -- References: cmn_checklists.id
    ref_owner           int                  not null,    -- References: cmn_users.id
    ref_appraiser       int                  not null,    -- References: cmn_users.id
    type                int                  not null,
    state               int                  not null,    -- See: com.interact.sas.svc.data.Evaluation.STATES
    result              double               not null,
    dt_from             date                 null,
    dt_until            date                 null,
    dt_created          date                 not null, 
    dt_finished         date                 not null,
    name                varchar(160)         not null,
    info                text                 not null,
    feedback            text                 not null,

    primary key ( id )
);
create index svc_evaluat_ref_contract  on svc_evaluations(ref_contract);
create index svc_evaluat_ref_provider  on svc_evaluations(ref_provider);
create index svc_evaluat_ref_service   on svc_evaluations(ref_service);
create index svc_evaluat_ref_checklist on svc_evaluations(ref_checklist);
create index svc_evaluat_ref_owner     on svc_evaluations(ref_owner);
create index svc_evaluat_ref_appraiser on svc_evaluations(ref_appraiser);

-- --------------------------------------------------------
-- SVC_RESULT_TOPICS
--
-- Stores: N/A
-- --------------------------------------------------------
create table svc_topic_results
(
   ref_evaluation               int              not null,    -- References: svc_evaluations.id
   ref_checklist_topics         int              not null,    -- References: cmn_checklist_topics.id
   ref_scale_items              int              not null,    -- References: cmn_scale_items.id
   result                       int              not null,
   feedback                     varchar(4000),
   
   unique ( ref_evaluation, ref_checklist_topics )
);

-- --------------------------------------------------------
-- SVC_REQUIREMENT_VALIDATIONS
--
-- Stores: com.interact.sas.svc.data.RequirementValidation
-- --------------------------------------------------------
create table svc_requirement_validations
(
  id                      int not null,
  ref_service_requirement int not null,    -- References: svc_service_requirements.id
  ref_contract            int not null,    -- References: svc_contracts.id
  state                   int not null,    -- See: com.interact.sas.svc.data.RequirementValidation.STATE

  primary key (id)
);
create index svc_req_val_requirement on svc_requirement_validations(ref_service_requirement);
create index svc_req_val_contract    on svc_requirement_validations(ref_contract);
create index svc_req_val_state       on svc_requirement_validations(state);

-- --------------------------------------------------------
-- SVC_PAYMENTS
--
-- Stores: com.interact.sas.svc.data.Payment
-- --------------------------------------------------------
create table svc_payments
(
    id            int            not null,
    ref_contract  int            not null,    -- References: svc_contracts.id
    ref_owner     int            not null,    -- References: cmn_users.id
    ref_approver  int            not null,    -- References: cmn_users.id
    nf            int            null,
    seq_no        int            not null,
    state         int            not null,    -- See: com.interact.sas.svc.data.Payment.STATES
    score         double         null,    
    v_nominal     double         not null,
    v_liquid      double         null,
    dt_from       date           not null,
    dt_until      date           not null,
    dt_payment    date           null,
    dt_due        date           null,
    dt_approved   date           null,
    n_ticket      varchar(50)    null,
    info_approved text           null,
    info_paid     text           null,
    
    primary key (id)
);

create index svc_payments_contract on svc_payments( ref_contract );
create index svc_payments_owner    on svc_payments( ref_owner );
create index svc_payments_approver on svc_payments( ref_approver );