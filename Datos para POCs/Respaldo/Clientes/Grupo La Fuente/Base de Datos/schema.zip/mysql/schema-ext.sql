-- ----------------------------------------------------------------------------
--
-- Module:   EXT
--
-- Schema:   80.1
--
-- Revision: $Revision: 91822 $
--
-- Date:     $Date: 2011-06-29 14:00:26 -0300 (Qua, 29 Jun 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-ext.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- Tables for Extension Management
-- --------------------------------------------------------

-- -----------------------------------------------------------------------------
-- EXT_SCRIPTS
--
-- Stores: com.interact.sas.ext.data.Script
-- -----------------------------------------------------------------------------
create table ext_scripts
(
    id                          int                not null,
    ref_file                    int                not null,    -- References: vfs_files.id
    ref_owner                   int                not null,    -- References: cmn_users.id
    interactive                 tinyint            not null,
    period                      smallint           not null,    -- See: com.interact.sas.ext.data.Script.PERIOD
    state                       smallint           not null,    -- See: com.interact.sas.ext.data.Script.STATES
    duration                    double             not null,
    dt_scheduled                date               default null,
    dt_finished                 datetime,
    dt_started                  datetime,
    mnemonic                    varchar(40)        not null,
    category                    varchar(80)        not null,
    classification              varchar(20)        not null,
    name                        varchar(160)       not null,
    info                        text               not null,

    primary key ( id ),
    unique ( mnemonic )
);
create index ext_scripts_owner on ext_scripts ( ref_owner );

-- -----------------------------------------------------------------------------
-- Table EXT_DATASOURCES
--
-- Stores: com.interact.sas.cmn.data.DataSource
-- -----------------------------------------------------------------------------
create table ext_datasources
(
    id                          int                not null,
    ref_owner                   int                not null,    -- References: cmn_users.id
    ref_team                    int                not null,    -- References: cmn_groups.id
    name                        varchar(80)        not null,
    driver                      varchar(160)       not null,
    "user"                      varchar(80)        not null,
    password                    varchar(80)        not null,
    url                         varchar(4000)      not null,
    
    primary key ( id ),
    unique ( name )
);
create index ext_datasources_owner on ext_datasources(ref_owner);
create index ext_datasources_team  on ext_datasources(ref_team);

-- -----------------------------------------------------------------------------
-- EXT_FUNCTIONS
--
-- Stores: com.interact.sas.ext.data.FunctionDescriptor
-- -----------------------------------------------------------------------------
create table ext_functions
(
    id                      int                     not null,
    ref_owner               int                     not null,    -- References: cmn_users.id
    ref_file                int                     not null,    -- References: vfs_files.id
    flavour                 tinyint                 not null,
    type                    tinyint                 not null,
    family                  tinyint                 not null,
    name                    varchar(250)            not null,
    info                    text                    not null,
    
    primary key ( id ),
    unique ( family, name )
);
create index ext_functions_owner on ext_functions ( ref_owner );
create index ext_functions_file  on ext_functions ( ref_file );

-- -----------------------------------------------------------------------------
-- EXT_ARGUMENTS
--
-- Stores: com.interact.sas.ext.data.Argument
-- -----------------------------------------------------------------------------
create table ext_arguments
(
    id                      int                     not null,
    ref_function            int                     not null,    -- References: ext_functions.id
    type                    tinyint                 not null,    -- See: com.interact.sas.ext.data.Argument.TYPE
    fl_required             tinyint                 not null,
    seq_no                  smallint                not null,
    label                   varchar(250)            not null,
    name                    varchar(250)            not null,
    default_value           varchar(250)            not null,

    primary key ( id ),
    unique ( ref_function, name )
);

create index ext_args_function on ext_arguments ( ref_function );

-- -----------------------------------------------------------------------------
-- EXT_BATCH_JOBS
--
-- Stores: com.interact.sas.ext.data.BatchJob
-- -----------------------------------------------------------------------------
create table ext_batch_jobs
(
    id             int               not null,
    errors         int               not null,
    progress       smallint          not null,
    state          smallint          not null,    -- See: com.interact.sas.ext.data.BatchJob.STATES
    ts_schedule    timestamp         null,
    ts_started     timestamp         null,
    ts_finished    timestamp         null,
    ts_queued       timestamp         not null default current_timestamp,
    domain         varchar(30)       not null,
    uuid           varchar(36)       not null,
    runtime        varchar(160)      not null,
    stage          varchar(160)      not null,
    item           varchar(160)      not null,
    subject        varchar(250)      not null,
    data           text              not null,

    primary key ( id ),
    unique ( uuid )
);
create index ix_ext_batch_jobs_domain     on ext_batch_jobs ( domain );
create index ix_ext_batch_jobs_schedule   on ext_batch_jobs ( ts_schedule );
create index ix_ext_batch_jobs_started    on ext_batch_jobs ( ts_started );
create index ix_ext_batch_jobs_finishedon on ext_batch_jobs ( ts_finished );
create index ix_ext_batch_jobs_state      on ext_batch_jobs ( state );

-- -----------------------------------------------------------------------------
-- EXT_BATCH_ERRORS
--
-- Stores: com.interact.sas.ext.data.BatchError
-- -----------------------------------------------------------------------------
create table ext_batch_errors
(
    id             int               not null,
    ref_job        int               not null,    -- References: ext_batch_jobs.id
    code           int               not null,    
    ts_error       timestamp         not null,
    message        varchar(160)      not null,
    info           text              not null,

    primary key ( id )
);
create index ix_ext_batch_errors_ref_job on ext_batch_errors( ref_job );
create index ix_ext_batch_errors_ts      on ext_batch_errors( ts_error );
create index ix_ext_batch_errors_code    on ext_batch_errors( code );

-- -----------------------------------------------------------------------------
-- EXT_STATES
--
-- Stores: com.interact.sas.ext.data.State
-- -----------------------------------------------------------------------------
create table ext_states
(
    name varchar(250) not null,
    data longtext     not null,

    unique ( name )
);

-- --------------------------------------------------------
-- EXT_ADSOURCES
--
-- Stores: N/A
-- --------------------------------------------------------
create table ext_adsources
(
    id          int              not null,
    ref_owner   int              not null,    -- References: cmn_users.id
    protocol    varchar(20)      not null,
    options     varchar(32)      not null,
    name        varchar(80)      not null,
    user        varchar(80)      not null,
    password    varchar(80)      not null,
    filter      varchar(4000)    not null,
    base        varchar(4000)    not null,
    url         varchar(4000)    not null,  
    info        varchar(4000)    not null,
    
    primary key(id)
);

-- --------------------------------------------------------
-- EXT_BATCH_JOB_BINDS
--
-- Stores: N/A
-- --------------------------------------------------------
create table ext_batch_job_binds
(
    ref_job    int not null,    -- References: ext_batch_jobs.id
    ref_source int not NULL,    -- References: item source id
    family     int not null

);
create index ext_batch_job_binds_job    on ext_batch_job_binds( ref_job );
create index ext_batch_job_binds_family on ext_batch_job_binds( family );
create index ext_batch_job_binds_source on ext_batch_job_binds( ref_source );
