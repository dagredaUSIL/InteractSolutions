 -- -----------------------------------------------------------------------------
--
-- Module:   BUD
--
-- Schema:   80.1
--
-- Revision: $Revision: 101730 $
--
-- Date:     $Date: 2012-01-09 15:07:37 -0200 (Seg, 09 Jan 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-bsc.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------


-- ------------------------------------------------------------
-- BUD_PLANS
--
-- Stores: com.interact.sas.bud.data.Budget
-- ------------------------------------------------------------
create table bud_plans
(
    id              int             not null,
    ref_category    int             not null,    -- References: cmn_categories.id
    ref_director    int             not null,    -- References: cmn_users.id
    ref_executive   int             not null,    -- References: cmn_users.id
    ref_owner       int             not null,    -- References: cmn_users.id
    ref_team        int             not null,    -- References: cmn_teams.ref_team
    restriction     int             not null,
    state           int             not null,
    competence      int,
    currency_code   char(3)         not null,
    currency_format varchar(40)     not null,
    mnemonic        varchar(60)     not null,
    name            varchar(160)    not null,
    info            text            not null,


    primary key ( id ),
    unique ( mnemonic )
);
create index bud_plans_category    on bud_plans( ref_category );
create index bud_plans_director    on bud_plans( ref_director );
create index bud_plans_executive   on bud_plans( ref_executive );
create index bud_plans_owner       on bud_plans( ref_owner );
create index bud_plans_team        on bud_plans( ref_team );
create index bud_plans_restriction on bud_plans( restriction );
create index bud_plans_state       on bud_plans( state );

-- ------------------------------------------------------------
-- BUD_PLAN_ITEMS
--
-- Stores: com.interact.sas.bud.data.BudgetItem
-- ------------------------------------------------------------
create table bud_plan_items
(
    id              int             not null,
    ref_plan        int             not null,    -- References: bud_plans.id
    operation       char(1)         not null,
    account         varchar(20)     not null,
    classification  varchar(40)     not null,
    alias           varchar(20)     not null,
    label           varchar(80)     not null,

    primary key ( id ),
    unique ( ref_plan, alias )
);
create index bud_plan_items_plan on bud_plan_items( ref_plan );

-- ------------------------------------------------------------
-- BUD_PLAN_INSTANCES
--
-- Stores: com.interact.sas.bud.data.BudgetInstance
-- ------------------------------------------------------------
create table bud_plan_instances
(
    id              int             not null,
    ref_parent      int             not null,    -- References: bud_instances.id
    ref_plan        int             not null,    -- References: bud_plans.id
    ref_unit        int             not null,    -- References: cmn_units.id
    ref_director    int             not null,    -- References: cmn_users.id
    ref_executive   int             not null,    -- References: cmn_users.id
    ref_owner       int             not null,    -- References: cmn_users.id
    ref_team        int             not null,    -- References: cmn_teams.ref_team
    ref_ap_proposed int             not null,    -- References: bsc_actionplans.id 
    ref_ap_approved int             not null,    -- References: bsc_actionplans.id 
    restriction     int             not null,
    state           tinyint         not null,    -- See: com.interact.sas.bud.data.BudgetInstance.STATE
    deployed        tinyint         not null,
    seqno           smallint        not null,
    mnemonic        varchar(60)     not null,
    name            varchar(160)    not null,
    info            text            not null,
    
    primary key ( id ),
    unique ( mnemonic )
);
create index bud_plan_instances_parent      on bud_plan_instances( ref_parent );
create index bud_plan_instances_plan        on bud_plan_instances( ref_plan );
create index bud_plan_instances_unit        on bud_plan_instances( ref_unit );
create index bud_plan_instances_director    on bud_plan_instances( ref_director );
create index bud_plan_instances_executive   on bud_plan_instances( ref_executive );
create index bud_plan_instances_owner       on bud_plan_instances( ref_owner );
create index bud_plan_instances_team        on bud_plan_instances( ref_team );
create index bud_plan_instances_proposed    on bud_plan_instances( ref_ap_proposed );
create index bud_plan_instances_approved    on bud_plan_instances( ref_ap_approved );
create index bud_plan_instances_restriction on bud_plan_instances( restriction );

-- ------------------------------------------------------------
-- BUD_PLAN_CAMPAIGNS
--
-- Stores: com.interact.sas.bud.data.BudgetCampaign
-- ------------------------------------------------------------
create table bud_plan_campaigns
(
    id              int             not null,
    ref_plan        int             not null,    -- References: bud_plans.id
    ref_instance    int             not null,    -- References: bud_instances.id
    competence      int             not null,
    mnemonic        varchar(60)     not null,
    name            varchar(160)    not null,
    info            text            not null,
    
    primary key ( id ),
    unique ( mnemonic, competence )
);
create index bud_plan_campaigns_plan     on bud_plan_campaigns(ref_plan );
create index bud_plan_campaigns_instance on bud_plan_campaigns(ref_instance);

-- ------------------------------------------------------------
-- BUD_PLAN_SERIES
--
-- Stores: com.interact.sas.bud.data.BudgetSerie
-- ------------------------------------------------------------
create table bud_plan_series
(
    id              int             not null,
    ref_plan        int             not null,    -- References: bud_plans.id
    ref_original    int             not null,    -- References: bud_plan_series.id
    type            tinyint         not null,    -- See: com.interact.sas.bud.data.BudgetSerie.TYPE
    deployed        tinyint         not null,
    label           varchar(40)     not null,
    mnemonic        varchar(40)     not null,
    
    primary key ( id )
);
create index bud_plan_series_plan     on bud_plan_series( ref_plan );
create index bud_plan_series_original on bud_plan_series( ref_original );

-- ------------------------------------------------------------
-- BUD_PLAN_DATA
--
-- Stores: com.interact.sas.bud.data.BudgetData
-- ------------------------------------------------------------
create table bud_plan_data
(
    ref_plan        int             not null,    -- References: bud_plans.id
    ref_instance    int             not null,    -- References: bud_instances.id
    ref_item        int             not null,    -- References: bud_plan_items.id
    ref_serie       int             not null,    -- References: bud_plan_series.id
    ref_campaign    int             not null,    -- References: bud_campaigns.id
    ref_info        int             not null,    -- References: cmn_info.id
    competence      int             not null,
    value           double          not null,
    
    unique ( ref_plan, ref_instance, ref_item, ref_serie, ref_campaign, competence )
);
create index bud_plan_data_plan     on bud_plan_data( ref_plan );
create index bud_plan_data_instance on bud_plan_data( ref_instance );
create index bud_plan_data_item     on bud_plan_data( ref_item );
create index bud_plan_data_serie    on bud_plan_data( ref_serie );
create index bud_plan_data_campaign on bud_plan_data( ref_campaign );
create index bud_plan_data_info     on bud_plan_data( ref_info );

-- ------------------------------------------------------------
-- BUD_PLAN_DETAILS
--
-- Stores: com.interact.sas.bud.data.BudgetDetail
-- ------------------------------------------------------------
create table bud_plan_details
(
    id             int          not null,
    ref_item       int          not null,    -- References: bud_plan_item.id
    ref_instance   int          not null,    -- References: bud_plan_instances.id
    ref_parent     int          not null,
    account        varchar(20)  not null,
    classification varchar(40)  not null,   
    name           varchar(160) not null,

    primary key ( id )
);
create index bud_plan_details_class        on bud_plan_details(classification);
create index bud_plan_details_ref_item     on bud_plan_details(ref_item);
create index bud_plan_details_ref_instance on bud_plan_details(ref_instance);
create index bud_plan_details_ref_parent   on bud_plan_details(ref_parent);

-- ------------------------------------------------------------
-- BUD_PLAN_DETAIL_DATA
--
-- Stores: com.interact.sas.bud.data.BudgetDetailData
-- ------------------------------------------------------------
create table bud_plan_detail_data
(
    ref_plan        int             not null,   -- References: bud_plans.id
    ref_instance    int             not null,   -- References: bud_instances.id
    ref_detail      int             not null,   -- References: bud_plan_items.id
    ref_serie       int             not null,   -- References: bud_plan_series.id
    competence      int             not null,
    amount          double,
    value           double          not null,
    total           double,

    unique key ( ref_plan, ref_instance,ref_detail,ref_serie,competence )
);
create index bud_plan_detail_data_plan     on bud_plan_detail_data( ref_plan );
create index bud_plan_detail_data_instance on bud_plan_detail_data( ref_instance );
create index bud_plan_detail_data_detail   on bud_plan_detail_data( ref_detail );
create index bud_plan_detail_data_serie    on bud_plan_detail_data( ref_serie );

-- ------------------------------------------------------------
-- BUD_PACKAGES
--
-- Stores: com.interact.sas.bud.data.BudgetPackage
-- ------------------------------------------------------------
create table bud_packages 
(
    id              int,
    ref_plan        int,    -- References: bud_plans.id
    ref_owner       int,    -- References: cmn_users.id
    ref_serie       int,    -- References: bud_plan_series.id
    restriction     int not null,
    state           tinyint,
    total           decimal,
    name            varchar(80),
    info            text,

    primary key ( id )
);

-- ------------------------------------------------------------
-- BUD_PACKAGE_TOTALS
--
-- Stores: com.interact.sas.bud.data.BudgetPackageTotal
-- ------------------------------------------------------------
create table bud_package_totals
(
	ref_package		int,    -- References: bud_package.id
	ref_instance    int,    -- References: bud_plan_instances.id 
    value           decimal,
    state           tinyint,

    unique key ( ref_package, ref_instance )
);

-- ------------------------------------------------------------
-- BUD_PACKAGE_ITEMS
--
-- Stores: com.interact.sas.bud.data.BudgetPackageItem
-- ------------------------------------------------------------
create table bud_package_items
(
    id              int,
	ref_package		int,    -- References: bud_package.id
	ref_item        int,    -- References: bud_plan_items.id

    primary key ( id ),
	unique key( ref_package, ref_item )
);

-- ------------------------------------------------------------
-- BUD_PACKAGE_INSTANCES
--
-- Stores: com.interact.sas.bud.data.BudgetPackageInstance
-- ------------------------------------------------------------
create table bud_package_instances
(
	id                  int,
    ref_instance    	int,    -- References: bud_plan_instances.id 
	ref_package_item	int,    -- References: bud_package_items.id
    ref_owner			int,
	state				tinyint,

    unique key( ref_instance, ref_package_item )
);

-- ------------------------------------------------------------
-- BUD_CHILD_REVISIONS
--
-- Stores: N/D
-- ------------------------------------------------------------
create table bud_child_revisions
(
    ref_item  int not null, -- References: bud_plan_items.id
    ref_serie int not null, -- References: bud_packages.ref_serie
    
    unique ( ref_item, ref_serie )
);
create index bud_child_revisions_item  on bud_child_revisions( ref_item );
create index bud_child_revisions_serie on bud_child_revisions( ref_serie );