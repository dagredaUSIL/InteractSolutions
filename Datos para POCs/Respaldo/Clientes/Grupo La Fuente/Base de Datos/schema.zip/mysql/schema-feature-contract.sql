-- ----------------------------------------------------------------------------
--
-- Module:   Contract Manager
--
-- Schema:   80.1
--
-- Revision: $Revision: 104140 $
--
-- Date:     $Date: 2015-05-19 13:49:50 -0300 (Qui, 01 Mar 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-hrm.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------


-- -----------------------------------------------------
-- FTR_CM_RELEVANCES
--
-- Stores: com.interact.sas.feature.contract.data.Relevance
-- -----------------------------------------------------
create table ftr_cm_relevances
(
    id             int            not null,
    period         int            not null,
    state          int            not null,
    seqno          smallint       default 0 not null,
    name           varchar(80)    not null,
    description    text           not null,

    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_SUPPLIERS
--
-- Stores: com.interact.sas.feature.contract.data.Supplier
-- -----------------------------------------------------
create table ftr_cm_suppliers
(
    id                              int             not null,
    type                            int             not null,
    relevance                       int             not null,
    state                           int             not null,
    last_performance_rating         datetime        null,
    next_performance_rating         datetime        null,
    end_date_operation              datetime        null,
    end_date_health_surveillance    datetime        null,
    end_date_art                    datetime        null,
    cep                             varchar(10)     not null,
    cnpj                            varchar(14)     null,
    "options"                       varchar(32)     not null,
    phone1                          varchar(40)     not null,
    phone2                          varchar(40)     not null,
    type_activity                   varchar(45)     not null,
    email                           varchar(80)     not null,
    company_name                    varchar(160)    not null,
    fantasy_name                    varchar(160)    not null,
    owner                           varchar(160)    not null,
    contact                         varchar(160)    not null,
    address                         varchar(200)    not null,
    info                            text            null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_CATEGORIES
--
-- Stores: com.interact.sas.feature.contract.data.ContractCategory
-- -----------------------------------------------------
create table ftr_cm_categories
(
    ref_category     int not null,    -- References: ftr_cm_categories.id
    ref_type         int not null,    -- References: ftr_cm_type_activities.id
        
    primary key (ref_category)
);

-- -----------------------------------------------------
-- FTR_CM_SUPPLIER_SCALES
--
-- Stores: com.interact.sas.feature.contract.data.SupplierScale
-- -----------------------------------------------------
create table ftr_cm_supplier_scales
(
    id                int             not null,
    ref_suppliers     int             not null,    -- References: ftr_cm_suppliers.id
    type              int             not null,
    state             int             not null,
    name              varchar(200)    not null,
    info              text            not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_SUPPLIER_SCALE_OPTIONS
--
-- Stores: com.interact.sas.feature.contract.data.SupplierScaleOption
-- -----------------------------------------------------
create table ftr_cm_supplier_scale_options
(
    id                    int            not null,
    ref_supplier_scale    int            not null,    -- References: ftr_cm_supplier_scales.id
    color                 int            not null,
    score_from            double         not null,
    score_until           double         not null,
    name                  varchar(80)    not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_QUESTIONNAIRE_SCALES
--
-- Stores: com.interact.sas.feature.contract.data.QuestionnaireScale
-- -----------------------------------------------------
create table ftr_cm_questionnaire_scales
(
    id                   int            not null,
    ref_questionnaire    int            not null,    -- References: ftr_cm_questionnaires.id
    type                 int            not null,
    state                int            not null,
    name                 varchar(60)    not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_QUESTIONNAIRES
--
-- Stores: com.interact.sas.feature.contract.data.Questionnaire
-- -----------------------------------------------------
create table  ftr_cm_questionnaires
(
    id              int            not null,
    ref_scale       int            not null,    -- References: ftr_cm_questionnaire_scales.id
    ref_supplier    int            not null,    -- References: ftr_cm_suppliers.id
    state           int            not null,    -- See: com.interact.sas.feature.contract.data.Questionnaire.STATE
    type            int            not null,
    info            varchar(45)    not null,
    name            varchar(60)    not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_QUESTIONNAIRE_TOPICS
--
-- Stores: com.interact.sas.feature.contract.data.QuestionnaireTopic
-- -----------------------------------------------------
create table ftr_cm_questionnaire_topics
(
    id                   int             not null,
    ref_questionnaire    int             not null,    -- References: ftr_cm_questionnaires.id
    type                 int             not null,    -- See: com.interact.sas.feature.contract.data.QuestionnaireTopic.TYPE
    name                 varchar(250)    not null,
    description          text            not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_QUESTIONS_SCALE_OPTIONS
--
-- Stores: com.interact.sas.feature.contract.data.QuestionnaireScaleOption
-- -----------------------------------------------------
create table ftr_cm_questions_scale_options
(
    id                         int             not null,
    ref_questionnaire_scale    int             not null,    -- References: ftr_cm_questionnaire_scales.id
    score                      double          not null,
    name                       varchar(45)     not null,
    info                       text            not null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_CONTRACT_SUMMARY
--
-- Stores: com.interact.sas.feature.contract.data.ContractSummary
-- -----------------------------------------------------
create table ftr_cm_contract_summary
(
    id                       int             not null,
    ref_suppliers            int             not null,    -- References: ftr_cm_suppliers.id
    ref_id_work              int             not null,    -- References: ftr_cm_contract_summary.id
    ref_owner                int             not null,    -- References: cmn_users.id
    ref_technical_manager    int             not null,    -- References: cmn_users.id
    type                     int             not null,    -- See: com.interact.sas.feature.contract.data.ContractSummary.TYPES
    invoice_day              int             not null,
    created_by               int             not null,
    contract_value           double          null,
    negotiation_month        date            null,
    readjustment_date        date            not null ,
    created_at               date            not null,
    signature                date            not null,
    start_date               date            not null,
    end_date                 date,
    index_correction         varchar(200)    not null,
    payment_term             varchar(200)    not null,
    fine                     varchar(255)    not null,
    rescission               text            not null,
    readjustment             text            not null,
    invoice_period           text            not null,
    observations             text            null,
    glosses_term             text            null,
    invoice_delivery         text            not null,
    payment_clause           text            not null,
    
    primary key (id)
);
alter table ftr_cm_contract_summary add unique uk_ftr_cm_contract_summary( ref_suppliers, ref_id_work);

-- -----------------------------------------------------
-- FTR_CM_ACTIONS
--
-- Stores: com.interact.sas.feature.contract.data.NonComplienceAction
-- -----------------------------------------------------
create table ftr_cm_actions
(
    id           int             not null,
    state        int             null,    -- See: com.interact.sas.feature.contract.data.NonComplienceAction.STATE
    type         int             null,
    name         varchar(200)    null,
    info         text            null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_SUPPLIERS_RATINGS
--
-- Stores: com.interact.sas.feature.contract.data.Rating
-- -----------------------------------------------------
create table ftr_cm_suppliers_ratings
(
    id                   int            not null,
    ref_supplier         int            not null,    -- References: ftr_cm_suppliers.id
    ref_questionnaire    int            not null,    -- References: ftr_cm_questionnaires.id
    ref_rater            int            not null,    -- References: cmn_users.id
    ref_approver         int            not null,    -- References: cmn_users.id
    ref_sector           int            not null,    -- References: cmn_sectors.id
    rating_type          int            not null,
    state                int            not null,
    score_final          double         not null,
    dt_rating_start      date           not null,
    dt_rating_end        date           not null,
    dt_start             date           null,
    dt_end               date           null,
    contract_number      varchar(45)    not null,
    info                 text           null,
    documents            text           null,
    feedback             text           null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_RATING_RESULTS
--
-- Stores: com.interact.sas.feature.contract.data.RatingResult
-- -----------------------------------------------------
create table ftr_cm_rating_results
(
    id                      int            not null,
    ref_rating_suppliers    int            not null,    -- References: ftr_cm_suppliers.id
    ref_questionnaire       int            not null,    -- References: ftr_cm_questionnaires.id
    ref_question            int            not null,    -- References: ftr_cm_questionnaire_topics.id
    score_achieved          double         not null,
    score_max               double         not null,
    "option"                varchar(45)    not null,
    actions                 varchar(16)    not null default 0,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_TYPE_ACTIVITIES
--
-- Stores: com.interact.sas.feature.contract.data.TypeActivity
-- -----------------------------------------------------
create table ftr_cm_type_activities
(
    id       int            not null,
    state    int            not null,
    seqno    smallint       not null default 0,
    name     varchar(45)    not null,
    info     text           null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_NOTIFICATIONS
--
-- Stores: com.interact.sas.feature.contract.data.Notification
-- -----------------------------------------------------
create table ftr_cm_notifications
(
    id            int             not null,
    ref_source    int             not null,    -- References: source item id
    ref_owner     int             not null,    -- References: cmn_users.id
    family        int             not null,    -- See: com.interact.sas.feature.contract.data.Notification.FAMILY
    confirmed     smallint        not null,
    start_date    date            not null,
    end_date      date            null,
    title         varchar(150)    not null,
    info          text            null,
    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_CONTRACT_RECIPES
--
-- Stores: com.interact.sas.feature.contract.data.ContractRecipe
-- -----------------------------------------------------
create table ftr_cm_contract_recipes
(
    id                      int            not null,
    ref_contract_summary    int            not null,    -- References: ftr_cm_contract_summary.id
    margin_pf_med           double         not null,
    margin_pfs_med          double         not null,
    margin_pfr_med          double         not null,
    no_indicators_med       double         not null,
    margin_opme             double         not null,
    margin_pfs_mat          double         not null,
    margin_pfr_mat          double         not null,
    indicators_mat          double         not null,
    no_indicators_mat       double         not null,
    dt_end_mat              date,
    dt_end_med              date,
    dt_end_opme             date,
    dt_end_daily            date,
    negotiation_type_mat    varchar(32)    not null,
    negotiation_type_med    varchar(32)    not null,
    negotiation_type_opme   varchar(32)    not null,
    negotiation_type_daily  varchar(32)    not null,
    info_mat                text           not null,
    info_opme               text           not null,
    info_daily              text           not null,
    info_med                text           not null,    
    primary key (id)
);

-- -----------------------------------------------------
-- FTR_CM_CONTRACT_HISTORICALS
--
-- Stores: com.interact.sas.feature.contract.data.ContractHistoric
-- -----------------------------------------------------
create table ftr_cm_contract_historicals
(
    id                      int       not null,
    ref_contract_summary    int       not null,    -- References: ftr_cm_contract_summary.id
    ref_owner               int       not null,
    negotiation             int       not null,
    readjustment_state      int       not null,
    rate_closed             double    not null,
    created_at              date      not null,
    description             text      not null,
    
    primary key (id)
);