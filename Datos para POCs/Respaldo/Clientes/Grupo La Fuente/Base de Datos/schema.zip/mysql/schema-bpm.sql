-- -----------------------------------------------------------------------------
--
-- Module:   BPM
--
-- Schema:   80.1
--
-- Revision: $Revision: 113441 $
--
-- Date:     $Date: 2012-07-04 13:58:38 -0300 (Qua, 04 Jul 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/install/40/mysql/schema-bpm.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br);
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- BPM_PROCESSES
--
-- Stores: com.interact.sas.bpm.data.ProcessDefinition
-- -----------------------------------------------------------------------------
create table bpm_processes
(
    id                       int                 not null,
    id_work                  int                 not null,    -- References: bpm_processes.id
    ref_owner                int                 not null,    -- References: cmn_users.id
    ref_modelling            int                 not null,    -- References: cmn_teams.id
    ref_serial               int                 not null,    -- References: cmn_serials.id
    ref_monitoring           int                 not null,    -- References: cmn_teams.id
    ref_support              int                 not null,    -- References: cmn_users.id
    version                  int                 not null,
    stage                    tinyint             not null,    -- See: com.interact.sas.bpm.data.ProcessDefinition.STAGES
    family                   tinyint             not null,
    time_conclusion          double              not null,
    time_unit                tinyint             not null,
    dt_version               datetime            not null,
    name                     varchar(80)         not null,
    mnemonic                 varchar(40)         not null,
    options                  varchar(32)         not null,
    naming_template          varchar(80)         not null,
    info                     text                not null,

    primary key( id ),
    unique ( id_work, version )
);
create index bpm_processes_owner     on bpm_processes ( ref_owner );
create index bpm_processes_team      on bpm_processes ( ref_modelling );
create index bpm_processes_serial    on bpm_processes ( ref_serial );

-- -----------------------------------------------------------------------------
-- BPM_ROLES
--
-- Stores: com.interact.sas.bpm.data.ProcessRole
-- -----------------------------------------------------------------------------
create table bpm_roles
(
    id                       int                 not null,
    ref_parent               int                 not null,    -- References: bpm_roles.id
    ref_process              int                 not null,    -- References: bpm_processes.id
    ref_original             int                 not null,    -- References: bpm_roles.id
    seqno                    smallint            not null,
    fl_active                tinyint             not null,
    name                     varchar(160)        not null,
    info                     text                not null,
    
    primary key ( id )
);
create index bpm_roles_parent on bpm_roles ( ref_parent );
create index bpm_roles_process on bpm_roles ( ref_process );

-- -----------------------------------------------------------------------------
-- BPM_ROLE_USER_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.RoleUserMapping
-- -----------------------------------------------------------------------------
create table bpm_role_user_mappings
(
    ref_role                 int                 not null,    -- References: bpm_roles.id
    ref_user                 int                 not null,    -- References: cmn_users.id

    unique ( ref_role, ref_user )
);
create index bpm_role_user_mappings_role    on bpm_role_user_mappings ( ref_role );
create index bpm_role_user_mappings_user    on bpm_role_user_mappings ( ref_user );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_LEVELS
--
-- Stores: com.interact.sas.bpm.data.InterfaceLevel
-- -----------------------------------------------------------------------------
create table bpm_interface_levels 
(
    id                       int                 not null,
    seq                      int                 not null,
    ref_parent               int                 not null,    -- References: bpm_interface_levels.id
    ref_interface            int                 not null,    -- References: bpm_interfaces.id
    ref_attribute            int                 not null,    -- References: bpm_attributes.id
    list_height              int                 not null,
    type                     tinyint             not null,    -- See: com.interact.sas.bpm.data.InterfaceLevel.TYPES
    fl_tabbed                tinyint             not null,
    fl_options               varchar(32)         not null,
    mnemonic                 varchar(80)         not null,
    title                    varchar(160)        not null,
    info                     text                not null,
    custom_filter            text                not null,
 

    primary key( id )
);
create index bpm_interface_lev_attribute    on bpm_interface_levels ( ref_attribute );
create index bpm_interface_lev_parent         on bpm_interface_levels ( ref_parent );
create index bpm_interface_lev_interface    on bpm_interface_levels ( ref_interface );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_CONTROLS
--
-- Stores: com.interact.sas.bpm.data.InterfaceControl
-- -----------------------------------------------------------------------------
create table bpm_interface_controls  
(
    id                                 int                 not null,
    ref_attribute                      int                 not null,    -- References: bpm_attributes.id
    ref_control_type                   int                 not null,    -- References: bpm_control_types.id
    ref_interface_level                int                 not null,    -- References: bpm_interface_levels.id
    ref_option                         int                 not null,    -- References: bpm_attribute_options.id
    seq_item                           int                 not null,
    "field_height"                     int                 not null,
    family                             tinyint             not null,
    "column_align"                     tinyint             not null,
    source_type                        tinyint             not null,
    "precision"                        smallint            not null,
    "dimension"                        int                 not null,
    "field_width"                      int                 not null,
    "column_width"                     int                 not null,
    fl_options                         varchar(32)         not null,
    parameter                          varchar(40)         not null,
    mnemonic                           varchar(80)         not null,
    label                              varchar(160)        not null,
    default_value                      varchar(160)        not null,
    link                               varchar(160)        not null,
    mask                               varchar(160)        not null,
    value_list                         varchar(250)        not null,
    label_list                         varchar(250)        not null, 
    info                               text                not null,
    custom_filter                      text                not null,
    
    primary key ( id )
);
create index bpm_interface_ctrl_attribute   on bpm_interface_controls( ref_attribute );
create index bpm_interface_ctrl_type        on bpm_interface_controls( ref_control_type );
create index bpm_interface_ctrl_level       on bpm_interface_controls( ref_interface_level );
create index bpm_interface_controls_option  on bpm_interface_controls( ref_option );
create index bpm_int_controls_source_type   on bpm_interface_controls( source_type );

-- -----------------------------------------------------------------------------
-- BPM_SOLVE_INSTANCES
--
-- Stores: com.interact.sas.bpm.data.SolveInstance
-- -----------------------------------------------------------------------------
create table bpm_solve_instances 
(
    id                       int                not null,
    ref_process_instance     int                not null,    -- References: bpm_process_instances.id
    ref_user                 int                not null,    -- References: cmn_users.id
    ref_from_task_instance   int                not null,    -- References: bpm_task_instance.id
    ref_to_task              int                not null,    -- References: bpm_tasks.id
    
    primary key ( id )
);
create index bpm_solve_instances_proc_inst      on bpm_solve_instances ( ref_process_instance );
create index bpm_solve_instances_user           on bpm_solve_instances ( ref_user );
create index bpm_solve_instances_from_inst      on bpm_solve_instances ( ref_from_task_instance );
create index bpm_solve_instances_to_task        on bpm_solve_instances ( ref_to_task );

-- -----------------------------------------------------------------------------
-- BPM_PROCESS_INSTANCES
--
-- Stores: com.interact.sas.bpm.data.ProcessInstance
-- -----------------------------------------------------------------------------
create table bpm_process_instances
(
    id                       int                not null,    
    ref_parent               int                not null,    -- References: bpm_process_instances.id
    ref_user                 int                not null,    -- References: cmn_users.id
    ref_process              int                not null,    -- References: bpm_process.id
    ref_unit                 int                not null,    -- References cmn_units.id
    stage                    tinyint            not null,    -- See: com.interact.sas.bpm.data.ProcessInstance.STAGES
    state                    tinyint            not null,    -- See: com.interact.sas.bpm.data.ProcessInstance.STATES
    priority                 tinyint            not null,
    estimated_cost           double             not null,
    real_cost                double             not null,
    dt_start                 datetime           not null,
    dt_end                   datetime           null,
    serial                   varchar(40)        not null,
    name                     varchar(320)       not null,

    primary key ( id )                          
);

create index bpm_process_instances_parent       on bpm_process_instances ( ref_parent );
create index bpm_process_instances_user         on bpm_process_instances ( ref_user );
create index bpm_process_instances_process      on bpm_process_instances ( ref_process );
create index bpm_process_instances_unit         on bpm_process_instances ( ref_unit );
-- -----------------------------------------------------------------------------
-- BPM_EMAIL_INSTANCES
--
-- Stores: com.interact.sas.bpm.data.EmailInstance
-- -----------------------------------------------------------------------------
create table bpm_email_instances
(
    id                       int                not null,
    ref_task_intance         int                not null,        -- References: bpm_task_instances.id
    type                     tinyint            not null,        -- See: com.interact.sas.bpm.data.EmailInstance.TYPES
    dt_sent                  datetime           default null,
    subject                  varchar(250)       not null,
    mail_to                  varchar(4000)      not null,
    message                  text               not null,
    
    primary key ( id )
);

create index bpm_email_instances_task_ins  on bpm_email_instances ( ref_task_intance );
-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTE_INSTANCES
--
-- Stores: com.interact.sas.bpm.data.AttributeInstance
-- -----------------------------------------------------------------------------
create table bpm_attribute_instances 
(
    id                       int                 not null,
    ref_process_instance     int                 not null,            -- References: bpm_process_instances.id
    ref_attribute            int                 not null,            -- References: bpm_attributes.id
    ref_parent               int                 not null,            -- References: bpm_attribute_instances.id
    ref_process              int                 not null,            -- References: bpm_processes.id
    ref_task_instance        int                 not null,            -- References: bpm_task_instances.id
    ref_source               int                 not null,            -- References: bpm_attribute_instances.id
    seq                      int                 not null,
    f0                       int                 not null default 0,
    f1                       double precision    not null default 0,
    content                  varchar(250)        not null,

    unique( ref_process, ref_process_instance, ref_task_instance, ref_parent, ref_attribute, seq ),
    primary key ( id )
);
create index bpm_attr_instances_proc_inst      on bpm_attribute_instances ( ref_process_instance );
create index bpm_attr_instances_attribute      on bpm_attribute_instances ( ref_attribute );
create index bpm_interface_inst_parent         on bpm_attribute_instances ( ref_parent );
create index bpm_interface_inst_process        on bpm_attribute_instances ( ref_process );
create index bpm_interface_inst_task_inst      on bpm_attribute_instances ( ref_task_instance );
create index bpm_attribute_instances_f0        on bpm_attribute_instances ( f0 );
create index bpm_attribute_instances_f1        on bpm_attribute_instances ( f1 );
create index bpm_att_inst_seq                  on bpm_attribute_instances ( seq );
create index bpm_attr_inst_content             on bpm_attribute_instances ( content );
create index bpm_attribute_instances_source    on bpm_attribute_instances ( ref_source );

-- -----------------------------------------------------------------------------
-- BPM_TASK_INSTANCES
--
-- Stores: com.interact.sas.bpm.data.TaskInstance
-- -----------------------------------------------------------------------------
create table bpm_task_instances
(
    id                       int                 not null,
    ref_task                 int                 not null,        -- References: bpm_tasks.id
    ref_process_instance     int                 not null,        -- References: bpm_process_instances.id
    ref_user                 int                 not null,        -- References: cmn_users.id
    ref_role                 int                 not null,        -- References: bpm_roles.id
    ref_attribute_instance   int                 not null,        -- References: bpm_attribute_instances.id
    ref_gateway              int                 not null,        -- References: bpm_task_instances.id
    ref_previous             int                 not null,        -- References: bpm_task_instances.id
    estimated_cost           double              not null,
    real_cost                double              not null,
    execution_state          smallint            not null,
    limit_state              smallint            not null,
    priority                 smallint            not null,
    action_state             smallint            not null,
    dt_start                 datetime            not null,
    dt_end                   datetime            default null,
    dt_claim                 datetime            default null,
    dt_limit                 datetime            default null,
    routes                   varchar(40)         not null,
    message_mnemonic         varchar(160)        not null,

    primary key ( id )
);

create index bpm_task_instances_task         on bpm_task_instances ( ref_task );
create index bpm_task_instances_proc_inst    on bpm_task_instances ( ref_process_instance );
create index bpm_task_instances_user         on bpm_task_instances ( ref_user );
create index bpm_task_instances_att_inst     on bpm_task_instances ( ref_attribute_instance );
create index bpm_task_instances_ref_gate     on bpm_task_instances ( ref_gateway );
create index bpm_task_instances_previous     on bpm_task_instances( ref_previous );

-- -----------------------------------------------------------------------------
-- BPM_METRICS
--
-- Stores: com.interact.sas.bpm.data.Metric
-- -----------------------------------------------------------------------------
create table bpm_metrics
(
    id                       int                 not null,    
    ref_process              int                 not null,    -- References: bpm_processes.id
    ref_data_source          int                 not null,    -- References: ext_datasources.id
    ref_bam_role             int                 not null,    -- References: bpm_roles.id
    type                     tinyint             not null,
    fl_enable                tinyint             not null,
    min_value                double              not null,
    max_value                double              not null,
    dt_start                 datetime            not null,
    dt_end                   datetime            not null,
    dt_modified              datetime            not null,
    name                     varchar(160)        not null,
    info                     text                not null,
    command                  text                not null,

    primary key ( id )
);

create index bpm_metrics_processes     on bpm_metrics ( ref_process );
create index bpm_metrics_bam_role      on bpm_metrics ( ref_bam_role );
create index bpm_metrics_data_source   on bpm_metrics ( ref_data_source );

-- -----------------------------------------------------------------------------
-- BPM_METRIC_HISTORICALS
--
-- Stores: com.interact.sas.bpm.data.MetricHistorical
-- -----------------------------------------------------------------------------
create table bpm_metric_historicals
(
    id                       int                 not null,    
    ref_metric               int                 not null,    -- References: bpm_metrics.id
    ref_process_instance     int                 not null,    -- References: bpm_process_instances.id
    ref_task_instance        int                 not null,    -- References: bpm_task_instances.id    
    type                     tinyint             not null,
    min_value                double              not null,
    max_value                double              not null,
    realized                 double              not null,
    dt_collect               datetime            not null,

    primary key ( id )
);

create index bpm_metric_histo_metric            on bpm_metric_historicals ( ref_metric );
create index bpm_metric_histo_proc_inst         on bpm_metric_historicals ( ref_process_instance );
create index bpm_metric_histo_task_inst         on bpm_metric_historicals ( ref_task_instance );

-- -----------------------------------------------------------------------------
-- BPM_TASK_METRIC_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.TaskMetricMapping
-- -----------------------------------------------------------------------------
create table bpm_task_metric_mappings 
(
    ref_metric               int                 not null,    -- References: bpm_metric.id
    ref_task                 int                 not null,    -- References: bpm_tasks.id

    unique ( ref_metric, ref_task )
);

-- -----------------------------------------------------------------------------
-- BPM_DATA_EXPORTS
--
-- Stores: com.interact.sas.bpm.data.TaskDataExport
-- -----------------------------------------------------------------------------
create table bpm_data_exports  
(
    ref_task                 int                 not null,     -- References: bpm_tasks.id
    "file_name"              varchar(64)         not null,
    file_type                varchar(64)         not null,
    directory                varchar(250)        not null,

    unique ( ref_task )
);

-- -----------------------------------------------------------------------------
-- BPM_PROCEDURE_EXECUTIONS
--
-- Stores: com.interact.sas.bpm.data.TaskCallProcedure
-- -----------------------------------------------------------------------------
create table bpm_procedure_executions   
(
    ref_task                 int                 not null,     -- References: bpm_tasks.id
    conclusion_time          float               not null,
    source                   text                not null,

    unique ( ref_task )
);

-- -----------------------------------------------------------------------------
-- BPM_SEND_EMAIL_TASKS
--
-- Stores: com.interact.sas.bpm.data.TaskSendEmail
-- -----------------------------------------------------------------------------
create table bpm_send_email_tasks
(
    ref_task                 int                 not null,     -- References: bpm_tasks.id
    ref_role                 int                 not null,     -- References: bpm_roles.id
    fixed_address            varchar(4000)       not null,
    fixed_cc                 varchar(4000)       not null,
    fixed_cco                varchar(4000)       not null,
    subject                  varchar(4000)       not null,
    body                     text                not null,
    fl_claimer_destinatary   tinyint             not null,

    unique( ref_task )
);
create index bpm_send_email_tasks_role     on bpm_send_email_tasks ( ref_role );

-- -----------------------------------------------------------------------------
-- BPM_SCRIPT_TASKS
--
-- Stores: com.interact.sas.bpm.data.ScriptTask
-- -----------------------------------------------------------------------------
create table bpm_script_tasks
(
    ref_task                int                 not null,      -- References: bpm_tasks.id
    ref_source              int                 not null,      -- References: vfs_files.id

    unique ( ref_task, ref_source )
);

-- -----------------------------------------------------------------------------
-- BPM_TASK_INSTANCE_ERRORS
--
-- Stores: com.interact.sas.bpm.data.TaskInstanceError
-- -----------------------------------------------------------------------------
create table bpm_task_instance_errors
(
    id                      int                 not null,
    ref_process_instance    int                 not null,       -- References: bpm_process_instances.id
    ref_task_instance       int                 not null,       -- References: bpm_task_instances.id 
    executation_state       tinyint             not null,
    dt_created              datetime            not null,
    message                 text                not null,   

    primary key ( id )
);
create index bpm_task_inst_errors_proc_inst         on bpm_task_instance_errors ( ref_process_instance );
create index bpm_task_inst_errors_task_inst         on bpm_task_instance_errors ( ref_task_instance );

-- -----------------------------------------------------------------------------
-- BPM_CONDITION_ITEMS
--
-- Stores: com.interact.sas.bpm.data.TaskBindingConditionItem
-- -----------------------------------------------------------------------------
create table bpm_condition_items
(
    ref_source               int                 not null,    -- References: bpm_task_bindings.id
    ref_value_source         int                 not null,    -- References: bpm_attribute_instances.id or brm_methods.id
    seq_item                 int                 not null,
    value_family             int                 not null,    -- See: com.interact.sas.bpm.data.TaskBindingConditionItem.VALUE_FAMILY
    family                   int                 not null,    -- See: com.interact.sas.bpm.data.TaskBindingConditionItem.FAMILY
    fl_open_parentheses      tinyint             not null,
    fl_close_parentheses     tinyint             not null,
    logical_operator_type    tinyint             not null,
    parameter                varchar(40)         not null,
    conditional_operator     varchar(64)         not null,
    logical_operator         varchar(64)         not null,
    value                    varchar(250)        not null,
    
    unique ( ref_source, family, seq_item )
);
create index bpm_cond_it_source on bpm_condition_items ( ref_value_source );

-- -----------------------------------------------------------------------------
-- BPM_BUSINESS_COMPONENTS
--
-- Stores: com.interact.sas.bpm.data.BusinessComponent
-- -----------------------------------------------------------------------------
create table bpm_business_components 
(
    id                       int                 not null,    
    ref_category             int                 not null,    -- References: cmn_categories.id
    ref_team                 int                 not null,    -- References: cmn_groups.id
    ref_owner                int                 not null,    -- References: cmn_users.id
    fl_active                tinyint             not null,
    dt_modified              datetime            not null,
    name                     varchar(160)        not null,
    info                     text                not null,

    primary key ( id )
);
create index bpm_business_components_cat     on bpm_business_components ( ref_category );
create index bpm_business_components_team    on bpm_business_components ( ref_team );
create index bpm_business_components_owner   on bpm_business_components ( ref_owner );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACES
--
-- Stores: com.interact.sas.bpm.data.BusinessInterface
-- -----------------------------------------------------------------------------
create table bpm_interfaces   
(
    id                       int                 not null,
    ref_task                 int                 not null,    -- References: bpm_tasks.id
    ref_component            int                 not null,    -- References: bpm_business_components.id
    ref_data_source          int                 not null,    -- References: ext_datasources.id
    ref_handler              int                 not null,    -- References: vfs_files.id
    type                     tinyint             not null,    -- See: com.interact.sas.bpm.data.BusinessInterface.TYPES
    info                     text                not null, 

    primary key ( id )
);
create index bpm_interfaces_task         on bpm_interfaces ( ref_task );
create index bpm_interfaces_component    on bpm_interfaces ( ref_component );
create index bpm_interfaces_dt_source    on bpm_interfaces ( ref_data_source );
create index bpm_interfaces_handler      on bpm_interfaces( ref_handler );

-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTES
--
-- Stores: com.interact.sas.bpm.data.AttributeDefinition
-- -----------------------------------------------------------------------------
create table bpm_attributes
(
    id                       int                 not null,    
    ref_process              int                 not null,         -- References: bpm_processes.id
    ref_parent_attribute     int                 not null,         -- References: bpm_attributes.id
    ref_option               int                 not null,         -- References: bpm_attribute_options.id
    seq                      int                 not null,
    doc_type                 int                 not null,
    disposition              tinyint             not null,
    family                   tinyint             not null,
    scope                    tinyint             not null,
    fl_hidden                tinyint             not null,
    "precision"              smallint            not null,
    mnemonic                 varchar(160)        not null,
    label                    varchar(160)        not null,
    link                     varchar(160)        not null,
    family_data              varchar(250)        not null,
    info                     text                not null,

    primary key ( id )
);
create index bpm_attributes_process       on bpm_attributes ( ref_process );
create index bpm_attributes_parent        on bpm_attributes ( ref_parent_attribute );
create index bpm_attributes_option        on bpm_attributes  ( ref_option );
create index bpm_attributes_name          on bpm_attributes ( mnemonic );

-- -----------------------------------------------------------------------------
-- BPM_TASK_BINDINGS
--
-- Stores: com.interact.sas.bpm.data.TaskBinding
-- -----------------------------------------------------------------------------
create table bpm_task_bindings   
(
    id                       int                 not null,
    ref_from_task            int                 not null,     -- References: bpm_tasks.id
    ref_to_task              int                 not null,     -- References: bpm_tasks.id
    ref_attribute            int                 not null,     -- References: bpm_attributes.id
    label_width              int                 not null,
    label_height             int                 not null,
    from_x                   int                 not null,
    from_y                   int                 not null,
    to_x                     int                 not null,
    to_y                     int                 not null,
    from_handle              tinyint             not null,  
    to_handle                tinyint             not null,
    fl_deleted               tinyint             not null,
    message_type             tinyint             not null,
    target_solve_type        smallint            not null,
    text_color               varchar(7)          null,
    anchor                   varchar(40)         not null,
    parameter                varchar(40)         not null,
    label                    varchar(80)         not null,
    font_style               varchar(250)        not null,
    line_segments            varchar(250)        not null,
    
    primary key ( id ),
    unique ( ref_from_task, ref_to_task )
);
create index bpm_task_bindings_attribute      on bpm_task_bindings ( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_TASK_ATTRIBUTES
--
-- Stores: com.interact.sas.bpm.data.TaskAttributeDefinition
-- -----------------------------------------------------------------------------
create table bpm_task_attributes 
(
    ref_task                 int                 not null,     -- References: bpm_tasks.id
    ref_attribute            int                 not null,     -- References: bpm_attributes.id
    position                 int                 not null,  
    fl_modifiable            tinyint             not null,
    fl_required              tinyint             not null,

    unique ( ref_task, ref_attribute )
);

-- -----------------------------------------------------------------------------
-- BPM_TASKS
--
-- Stores: com.interact.sas.bpm.data.TaskDefinition
-- -----------------------------------------------------------------------------
create table bpm_tasks  
( 
    id                                 int                 not null,
    ref_process                        int                 not null,    -- References: bpm_processes.id
    ref_role                           int                 not null,    -- References: bpm_roles.id
    ref_time_attribute                 int                 not null,    -- References: bpm_attributes.id
    ref_pool                           int                 not null,    -- References: bpm_tasks.id
    ref_file                           int                 not null,    -- References: vfs_files.id
    ref_attached_to                    int                 not null,    -- References: bpm_tasks.id
    seq                                int                 not null,
    hierarchy_level                    int                 not null,
    pos_x                              int                 not null,
    pos_y                              int                 not null,
    shape_width                        int                 not null,  
    shape_height                       int                 not null,
    label_pos_x                        int                 not null,
    label_pos_y                        int                 not null,
    label_width                        int                 not null,
    label_height                       int                 not null,
    fl_claimer_role                    tinyint             not null,
    fl_hierarchy_claimer_role          tinyint             not null,
    fl_notify_alert_time               tinyint             not null,
    fl_notify_receiving                tinyint             not null,
    fl_notify_wait_time                tinyint             not null, 
    fl_join                            tinyint             not null,
    conclusion_time_unit               tinyint             not null,
    wait_time_unit                     tinyint             not null,
    alert_time_unit                    tinyint             not null,
    time_control_type                  tinyint             not null,
    priority                           smallint            not null,    -- See: com.interact.sas.bpm.data.TaskDefinition.PRIORITIES
    type                               smallint            not null,    -- See: com.interact.sas.bpm.data.TaskDefinition.TYPES
    conclusion_time                    float               not null,
    wait_time                          float               not null,
    alert_time                         float               not null,
    background_color                   varchar(7)          null,
    border_color                       varchar(7)          null,
    text_color                         varchar(7)          null,
    fl_options                         varchar(32)         not null,
    mnemonic                           varchar(40)         not null,
    name                               varchar(80)         not null,
    command_line                       varchar(250)        not null,
    font_style                         varchar(250)        not null,
    info                               text                not null, 
    pre_condition                      text                not null,
    
    primary key ( id )
);
create index bpm_tasks_process           on bpm_tasks ( ref_process );
create index bpm_tasks_role              on bpm_tasks ( ref_role );
create index bpm_tasks_attribute         on bpm_tasks ( ref_time_attribute );
create index bpm_tasks_attached_to       on bpm_tasks( ref_attached_to );

-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTE_INST_BLOB
--
-- Stores: com.interact.sas.bpm.data.AttributeInstance
-- -----------------------------------------------------------------------------
create table bpm_attribute_inst_blob
(
    id                                 int                 not null,
    content                            blob                not null,
    
    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTE_INST_CLOB
--
-- Stores: com.interact.sas.bpm.data.AttributeInstance
-- -----------------------------------------------------------------------------
create table bpm_attribute_inst_clob
(
    id                                 int                 not null,
    content                            text                not null,
    
    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_COLUMN_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.InterfaceColumnMapping
-- -----------------------------------------------------------------------------
create table bpm_interface_column_mappings
(
    ref_interface_control              int                 not null,    -- References: bpm_interface_controls.id
    ref_source_interface_control       int                 not null,    -- References: bpm_interface_controls.id
    ref_interface_control_return       int                 not null,    -- References: bpm_interface_controls.id
    ref_interface_level                int                 not null,    -- References: bpm_interface_levels.id
    ref_attribute                      int                 not null,    -- References: bpm_attributes.id
    type                               tinyint             not null,    -- See: com.interact.sas.bpm.data.InterfaceColumnMapping.TYPES
    
    unique ( ref_interface_control, ref_interface_level, ref_source_interface_control, type, ref_interface_control_return, ref_attribute )
);
create index bpm_int_col_map_att on bpm_interface_column_mappings( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_CONTROL_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.InterfaceControlMapping
-- -----------------------------------------------------------------------------
create table bpm_interface_control_mappings
(
    ref_interface_control              int                 not null,    -- References: bpm_interface_controls.id
    ref_interface_level                int                 not null,    -- References: bpm_interface_levels.id
    ref_attribute                      int                 not null,    -- References: bpm_attributes.id
    
    unique ( ref_interface_control, ref_attribute )
);
create index bpm_int_ctl_map_level         on bpm_interface_control_mappings ( ref_interface_level );
create index bpm_int_control_map_attribute on bpm_interface_control_mappings( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_LEVEL_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.InterfaceLevelMapping
-- -----------------------------------------------------------------------------
create table bpm_interface_level_mappings
(
    ref_source   int        not null,    -- References: bpm_interface_level.id
    ref_target   int        not null,    -- References: bpm_interface_level.id
    
    unique ( ref_source, ref_target )
);
create index bpm_int_lvl_map_source on bpm_interface_level_mappings ( ref_source );
create index bpm_int_lvl_map_target on bpm_interface_level_mappings ( ref_target );

-- -----------------------------------------------------------------------------
-- BPM_SUBPROCESS_ATTR_MAPPINGS
-- 
-- Stores: com.interact.sas.bpm.data.TaskSubprocessAttributeMapping
-- -----------------------------------------------------------------------------
create table bpm_subprocess_attr_mappings
(
    ref_source_attribute     int                not null,    -- References: bpm_attributes.id
    ref_target_attribute     int                not null,    -- References: bpm_attributes.id
    ref_task                 int                not null,    -- References: bpm_tasks.id
    
    unique ( ref_task, ref_source_attribute, ref_target_attribute )
);

-- -----------------------------------------------------------------------------
-- BPM_TRANSACTION_TASKS
--
-- Stores: com.interact.sas.bpm.data.TaskTransaction
-- -----------------------------------------------------------------------------
create table bpm_transaction_tasks
(
    ref_task         int        not null,    -- References: bpm_tasks.id    
    ref_component    int        not null,    -- References: bpm_business_components.id
    operation        tinyint    not null,    -- See: com.interact.sas.bpm.data.TaskTransaction.OPERATIONS

    unique ( ref_task )
);
create index bpm_trans_tasks_task         on bpm_transaction_tasks ( ref_task );
create index bpm_trans_tasks_component    on bpm_transaction_tasks ( ref_component );

-- -----------------------------------------------------------------------------
-- BPM_TRANSACTION_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.TransactionMapping
-- -----------------------------------------------------------------------------
create table bpm_transaction_mappings  
(
    ref_task                    int    not null,    -- References: bpm_tasks.id    
    ref_interface_level         int    not null,    -- References: bpm_interface_levels.id
    ref_interface_control       int    not null,    -- References: bpm_interface_controls.id
    ref_attribute               int    not null,    -- References: bpm_attributes.id

    unique ( ref_task, ref_interface_level, ref_interface_control, ref_attribute )
);
create index bpm_trans_map_task          on bpm_transaction_mappings ( ref_task );
create index bpm_trans_map_level         on bpm_transaction_mappings ( ref_interface_level );
create index bpm_trans_map_control       on bpm_transaction_mappings ( ref_interface_control );
create index bpm_trans_map_attribute     on bpm_transaction_mappings ( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_INTERFACE_FILTER_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.InterfaceFilterMapping
-- -----------------------------------------------------------------------------
create table bpm_interface_filter_mappings
(
    ref_interface_control         int                 not null,    -- References: bpm_interface_controls.id
    ref_source_interface_control  int                 not null,    -- References: bpm_interface_controls.id
    ref_attribute                 int                 not null,    -- References: bpm_attributes.id
    ref_interface_level           int                 not null,    -- References: bpm_interface_levels.id
    ref_attribute_mapping         int                 not null,
    seq_item                      int                 not null,
    fl_open_parentheses           tinyint             not null,
    fl_close_parentheses          tinyint             not null,
    logical_operator_type         tinyint             not null,
    conditional_operator          varchar(64)         not null,
    logical_operator              varchar(64)         not null,   
    column_value                  varchar(250)        not null,

    unique ( ref_interface_control, ref_interface_level, seq_item, ref_attribute_mapping )
);
create index bpm_int_filter_map_source on bpm_interface_filter_mappings ( ref_source_interface_control );
create index bpm_int_filter_map_att    on bpm_interface_filter_mappings ( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_SUBPROCESS_TASKS
-- 
-- Stores: com.interact.sas.bpm.data.TaskSubprocess
-- -----------------------------------------------------------------------------
create table bpm_subprocess_tasks
(
    ref_task        int         not null,    -- References: bpm_tasks.id
    ref_process     int         not null,    -- References: bpm_processes.id
    fl_synchronous  tinyint     not null,
    instance_name   varchar(80) null,
    
    unique(ref_task, ref_process)
);

-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTE_OPTIONS
--
-- Stores: com.interact.sas.bpm.data.AttributeOption
-- -----------------------------------------------------------------------------
create table bpm_attribute_options
(
    id                       int                 not null,
    ref_process              int                 not null,    -- References: bpm_processes.id
    ref_original             int                 not null,    -- References: bpm_attribute_options.id - 0 = Lista Global
    ref_category             int                 not null,    -- References: cmn_categories.id
    family                   tinyint             not null, 
    name                     varchar(160)        not null,
    info                     text                not null,    
    
    primary key ( id )
);
create index bpm_attribute_opt_process  on bpm_attribute_options ( ref_process );
create index bpm_attribute_opt_original  on bpm_attribute_options ( ref_original );
create index bpm_attribute_opt_category  on bpm_attribute_options ( ref_category );

-- -----------------------------------------------------------------------------
-- BPM_ATTRIBUTE_OPTION_ITEMS
--
-- Stores: com.interact.sas.bpm.data.AttributeOptionItem
-- -----------------------------------------------------------------------------
create table bpm_attribute_option_items
(
    id                       int                 not null,
    ref_option               int                 not null,    -- References: bpm_attribute_options.id
    seq_no                   smallint            not null,
    label                    varchar(160)        not null,
    content                  varchar(250)        not null,

    primary key ( id )
);
create index bpm_attribute_opt_items_option  on bpm_attribute_option_items ( ref_option );
create index bpm_attr_opt_content            on bpm_attribute_option_items ( content );

-- -----------------------------------------------------------------------------
-- BPM_METRIC_QUERIES
--
-- Stores: com.interact.sas.bpm.data.MetricQuery
-- -----------------------------------------------------------------------------
create table bpm_metric_queries
(
    ref_metric                 int         not null,    -- References: bpm_metrics.id
    ref_process_instance       int         not null,    -- References: bpm_process_instances.id
    info                       text        not null,
    dt_start                   datetime    default null,
    dt_end                     datetime    default null
);
create index bpm_metric_queries_metric      on bpm_metric_queries ( ref_metric );
create index bpm_metric_queries_instance    on bpm_metric_queries ( ref_process_instance );

-- -----------------------------------------------------------------------------
-- BPM_EMAIL_ATTACHMENT_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.TaskEmailAttachment
-- -----------------------------------------------------------------------------
create table bpm_email_attachment_mappings
(
    ref_task         int    not null,    -- References: bpm_tasks.id
    ref_attribute    int    not null,    -- References: bpm_attributes.id
   
    unique ( ref_task, ref_attribute )
);
create index bpm_email_attachment_task        on bpm_email_attachment_mappings ( ref_task );
create index bpm_email_attachment_attr        on bpm_email_attachment_mappings ( ref_attribute );

-- -----------------------------------------------------------------------------
-- BPM_FAVOURITE_PROCESSES
--
-- Stores: com.interact.sas.bpm.data.FavouriteProcessDefinition
-- -----------------------------------------------------------------------------
create table bpm_favourite_processes
(
    id             int      not null,
    ref_process    int      not null,    -- References: bpm_processes.id
    ref_user       int      not null,    -- References: cmn_users.id
    seqno          smallint not null,
   
    primary key ( id ),
    unique ( ref_process, ref_user )
);

-- -----------------------------------------------------------------------------
-- BPM_ROLE_ATTRIBUTE_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.RoleAttributeMapping
-- -----------------------------------------------------------------------------
create table bpm_role_attribute_mappings
(   
    ref_role         int    not null,    -- References: bpm_roles.id
    ref_attribute    int    not null,    -- References: bpm_attributes.id
   
    unique ( ref_role, ref_attribute )
);

-- -----------------------------------------------------------------------------
-- BPM_TRANS_FILTER_MAPPINGS
--
-- Stores: com.interact.sas.bpm.data.TransactionFilterMapping
-- -----------------------------------------------------------------------------
create table bpm_trans_filter_mappings
(
    ref_task                     int            not null,    -- References: bpm_tasks.id
    ref_source_interface_control int            not null,    -- References: bpm_interface_controls.id
    ref_attribute                int            not null,    -- References: bpm_attributes.id       
    seq_item                     int            not null,
    fl_open_parentheses          tinyint        not null,
    fl_close_parentheses         tinyint        not null,
    logical_operator_type        tinyint        not null,
    conditional_operator         varchar(64)    not null,
    logical_operator             varchar(64)    not null,
    column_value                 varchar(250)   not null,

    unique ( ref_task, seq_item )
);
create index bpm_trans_filter_map_att    on bpm_trans_filter_mappings ( ref_attribute );
create index bpm_trans_filter_map_source on bpm_trans_filter_mappings ( ref_source_interface_control );

-- -----------------------------------------------------------------------------
-- BPM_TASK_FIELDS
--
-- Stores: com.interact.sas.bpm.data.TaskField
-- -----------------------------------------------------------------------------
create table bpm_task_fields
(
   ref_task int          not null,    -- References: bpm_tasks.id
   seq      int          not null,
   field    tinyint      not null,   -- See: com.interact.sas.bpm.data.TaskField.FIELDS
   family   smallint     not null,
   name     varchar(160) not null,
   content  text         not null,
   
   unique ( ref_task, family, field, seq)
);
create index bpm_task_fields_task on bpm_task_fields ( ref_task );

-- -------------------------------------------------------------------
-- BPM_USER_DELEGATIONS
--
-- Stores: com.interact.sas.bpm.data.UserDelegation
-- -------------------------------------------------------------------
create table bpm_user_delegations
(
    id                      int             not null,
    ref_author              int             not null,    -- References: cmn_users.id
    ref_source              int             not null,    -- References: cmn_users.id
    ref_target              int             not null,    -- References: cmn_users.id
    ref_role                int             not null,    -- References: bpm_process_roles.id
    dt_created              date            not null,
    dt_start                date            not null,
    dt_end                  date            not null,
    info                    text            not null,

    primary key ( id )
);
create index bpm_user_delegations_author      on bpm_user_delegations ( ref_author );
create index bpm_user_delegations_source      on bpm_user_delegations ( ref_source );
create index bpm_user_delegations_dest        on bpm_user_delegations ( ref_target );
create index bpm_user_delegations_role        on bpm_user_delegations ( ref_role );
create index bpm_user_delegations_created     on bpm_user_delegations ( dt_created );
create index bpm_user_delegations_start       on bpm_user_delegations ( dt_start );
create index bpm_user_delegations_end         on bpm_user_delegations ( dt_end );

-- -------------------------------------------------------------------
-- BPM_TASK_NOTIFICATIONS
--
-- Stores: com.interact.sas.bpm.data.TaskNotification
-- -------------------------------------------------------------------
create table bpm_task_notifications
(
    ref_task              int           not null,    -- References: bpm_tasks.id
    ref_attribute         int           not null,    -- References: bpm_attributes.id
    seqno                 smallint      not null,

    unique ( ref_task, ref_attribute )
);
create index bpm_task_notifications_task   on bpm_task_notifications ( ref_task );
create index bpm_task_notifications_attrib on bpm_task_notifications ( ref_attribute );

-- -----------------------------------------------------------------
-- BPM_WS_TASKS
--
-- Stores: com.interact.sas.bpm.data.TaskWebService
-- -----------------------------------------------------------------
create table bpm_ws_tasks
(
    ref_task      int           not null,    -- References: bpm_tasks.id 
    ref_attribute int           not null,    -- References: bpm_business_components.id
    url           varchar(160)  not null,
    response_tag  varchar(160)  not null,
    request       varchar(4000) not null,
    unique ( ref_task )
);
create index bpm_ws_tasks_task      on bpm_ws_tasks ( ref_task );
create index bpm_ws_tasks_attribute on bpm_ws_tasks ( ref_attribute);

-- --------------------------------------------------------------
-- BPM_SCENARIO_BINDINGS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioBinding
-- --------------------------------------------------------------
create table bpm_scenario_bindings
(
    id           int     not null,
    ref_source   int     not null,    -- References: bpm_scenario_tasks.id
    ref_target   int     not null,    -- References: bpm_scenario_tasks.id
    ref_scenario int     not null,    -- References: bpm_scenarios.id
    fl_exception tinyint not null,
    probability  double  not null,   
    
    primary key (id)
);
create index bpm_scenario_bindings_source   on bpm_scenario_bindings( ref_source );
create index bpm_scenario_bindings_targe    on bpm_scenario_bindings( ref_target );
create index bpm_scenario_bindings_scenario on bpm_scenario_bindings( ref_scenario );

-- --------------------------------------------------------------
-- BPM_SCENARIO_TASK_RESOURCES
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioTaskResource
-- --------------------------------------------------------------
create table bpm_scenario_task_resources
(
    ref_scenario_task int not null,    -- References: bpm_scenario_tasks.id
    ref_resource      int not null,    -- References: bpm_simulation_resources.id
    quantity          int not null,

    unique key ref_simulation_task (ref_scenario_task,ref_resource)
);
create index bpm_scen_task_res_scen_task on bpm_scenario_task_resources( ref_scenario_task );
create index bpm_scen_task_res_resource  on bpm_scenario_task_resources( ref_resource );

-- --------------------------------------------------------------
-- BPM_SCENARIO_TASK_RESULTS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioTaskResult
-- --------------------------------------------------------------
create table bpm_scenario_task_results
(
    ref_scenario_task int    not null,    -- References: bpm_scenario_tasks.id
    assumed           int    not null,
    waiting           int    not null,
    completed         int    not null,
    wait_min_time     double not null, 
    wait_max_time     double not null,
    wait_avg_time     double not null, 
    min_time          double not null,
    max_time          double not null,
    avg_time          double not null,
    min_cost          double not null,
    max_cost          double not null,
    avg_cost          double not null,
    total_time        double not null, 
    total_wait_time   double not null, 
    total_cost        double not null
);
create index bpm_scen_task_result_scen_task on bpm_scenario_task_results( ref_scenario_task );

-- --------------------------------------------------------------
-- BPM_SCENARIO_TASKS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioTask
-- --------------------------------------------------------------
create table bpm_scenario_tasks
(
    id                int     not null,
    ref_scenario      int     not null,    -- References: bpm_scenarios.id
    ref_task          int     not null,    -- References: bpm_tasks.id
    ref_sub_scenario  int     not null,    -- References: bpm_scenarios.id    
    time_unit         tinyint not null,
    event_time_unit   tinyint not null,    
    conclusion_time   double  not null,
    event_time        double  not null,
    fixed_cost        double  not null,
    event_probability double not null,

    primary key (id)
);
create index bpm_scenario_tasks_cenario  on bpm_scenario_tasks( ref_scenario );
create index bpm_scenario_tasks_task     on bpm_scenario_tasks( ref_task );
create index bpm_scenario_tasks_sub_scen on bpm_scenario_tasks( ref_sub_scenario );

-- --------------------------------------------------------------
-- BPM_SCENARIOS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenario
-- --------------------------------------------------------------
create table bpm_scenarios
(
    id                 int         not null,
    ref_team           int         not null,    -- References: cmn_groups.id
    ref_simulation     int         not null,    -- References: bpm_simulations.id
    ref_owner          int         not null,    -- References: cmn_users.id
    execution_limit    int         not null,
    time_unit          tinyint     not null,
    fl_calendar        tinyint     not null,
    execution_interval double      not null,
    dt_start           datetime    null,
    dt_end             datetime    null,
    currency           varchar(30) not null,
    name               varchar(80) not null,    
    info               text        not null,

    primary key (id)
);
create index bpm_scenarios_team       on bpm_scenarios( ref_team );
create index bpm_scenarios_simulation on bpm_scenarios( ref_simulation );

-- --------------------------------------------------------------
-- BPM_SIMULATION_RESOURCES
--
-- Stores: com.interact.sas.bpm.data.ProcessSimulationResource
-- --------------------------------------------------------------
create table bpm_simulation_resources
(
    id             int         not null,
    ref_simulation int         not null,    -- References: bpm_simulations.id
    ref_calendar   int         not null,    -- References: cmn_calendars.id
    quantity       int         not null,
    hour_cost      double      not null,
    fixed_cost     double      not null,
    name           varchar(80) not null,
 
    primary key (id)
);
create index bpm_simulation_resour_simul on bpm_simulation_resources( ref_simulation );
create index bpm_simulation_resour_calen on bpm_simulation_resources(ref_calendar);
-- --------------------------------------------------------------
-- BPM_SIMULATIONS
--
-- Stores: com.interact.sas.bpm.data.ProcessSimulation
-- --------------------------------------------------------------
create table bpm_simulations
(
    id           int         not null,
    ref_owner    int         not null,    -- References: cmn_users.id
    ref_team     int         not null,    -- References: cmn_teams.id
    ref_process  int         not null,    -- References: bpm_processes.id
    ref_category int         not null,    -- References: cmn_categories.id
    name         varchar(80) not null,
    dt_created   datetime    not null,
    info         text        not null,

    primary key (id)
);
create index bpm_simulations_owner    on bpm_simulations( ref_owner );
create index bpm_simulations_team     on bpm_simulations( ref_team );
create index bpm_simulations_process  on bpm_simulations( ref_process );
create index bpm_simulations_category on bpm_simulations( ref_category );

-- --------------------------------------------------------------
-- BPM_SCENARIO_RESULTS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioResult
-- --------------------------------------------------------------
create table bpm_scenario_results
(
    ref_scenario    int      not null,    -- References: bpm_scenarios.id
    ref_owner       int      not null,    -- References: cmn_users.id
    assumed         int      not null, 
    completed       int      not null,
    waiting         int      not null,
    wait_min_time   double   not null,
    wait_avg_time   double   not null,
    wait_max_time   double   not null,  
    min_time        double   not null, 
    max_time        double   not null,
    avg_time        double   not null, 
    min_cost        double   not null,
    max_cost        double   not null,
    avg_cost        double   not null,
    total_time      double   not null, 
    total_wait_time double   not null, 
    total_cost      double   not null,
    dt_start        datetime not null,
    dt_end          datetime not null
);
create index bpm_scenario_results_scenario on bpm_scenario_results( ref_scenario );
create index bpm_scenario_results_owner    on bpm_scenario_results( ref_owner );

-- --------------------------------------------------------------
-- BPM_SCENARIO_RESOURCE_RESULTS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioResourceResult
-- -------------------------------------------------------------
create table bpm_scenario_resource_results
(
    ref_scenario int    not null,    -- References: bpm_scenarios.id
    ref_resource int    not null,    -- References: bpm_simulation_resources.id
    "usage"      double not null,

    unique key ref_scenario (ref_scenario,ref_resource)
);
create index bpm_scenario_res_results_scen on bpm_scenario_resource_results ( ref_scenario );
create index bpm_scenario_res_results_res  on bpm_scenario_resource_results ( ref_resource );

-- --------------------------------------------------------------
-- BPM_SCENARIO_BINDING_RESULTS
--
-- Stores: com.interact.sas.bpm.data.ProcessScenarioBindingResult
-- -------------------------------------------------------------
create table bpm_scenario_binding_results
( 
    ref_binding int not null,    -- References: bpm_scenario_bindings.id 
    instances   int not null
);
create index bpm_scenario_bind_res_binding on bpm_scenario_binding_results (ref_binding);

-- --------------------------------------------------------------
-- BPM_TREE_ITEMS
--
-- Stores: com.interact.sas.bpm.data.TreeItem
-- -------------------------------------------------------------
create table bpm_tree_items
(
    id         int not null,
    ref_parent int not null,  -- References: bpm_tree_item.id
    ref_source int not null,
    family     int not null,
  
    primary key(id)
);
create index bpm_tree_items_parent on bpm_tree_items( ref_parent );
create index bpm_tree_items_source on bpm_tree_items( ref_source );
