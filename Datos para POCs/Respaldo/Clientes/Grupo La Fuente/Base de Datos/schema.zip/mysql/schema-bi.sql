-- ----------------------------------------------------------------------------
--
-- Module:   BI
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-bi.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- BI_SERVERS
--
-- Stores: com.interact.sas.bi.data.Server
-- --------------------------------------------------------
create table bi_servers
(
    id                         int               not null,
    "user"                     varchar(40)       not null,
    password                   varchar(40)       not null,
    name                       varchar(80)       not null,
    url                        varchar(250)      not null,
    info                       text              not null,

    primary key ( id ),
    unique ( name )
);

-- --------------------------------------------------------
-- BI_QUERIES
--
-- Stores: 
-- --------------------------------------------------------
create table bi_queries
(
    id                         int               not null,
    ref_server                 int               not null,    -- References: bi_servers.id
    ref_folder                 int               not null,    -- References: bi_folders.id
    ref_owner                  int               not null,    -- References: cmn_users.id
    ref_team                   int               not null,    -- References: cmn_groups.id
    restriction                int               not null,
    options                    int               not null,
    name                       varchar(80)       not null,
    cube                       varchar(250)      not null,
    info                       text              not null,
    mdx                        text              not null,


    primary key ( id )
);
create index bi_queries_user        on bi_queries ( ref_owner );
create index bi_queries_restriction on bi_queries ( restriction );
create index bi_queries_team        on bi_queries ( ref_team );
create index bi_queries_folder      on bi_queries ( ref_folder );

-- --------------------------------------------------------
-- BI_FOLDERS
--
-- Stores: com.interact.sas.bi.data.Folder
-- --------------------------------------------------------
create table bi_folders
(
    id                        int                not null,
    ref_project               int                not null,    -- References: bi_projects.id
    ref_owner                 int                not null,    -- References: cmn_users.id
    ref_parent                int                not null,    -- References: bi_folders.id
    ref_team                  int                not null,    -- References: cmn_groups.id
    restriction               int                not null,
    name                      varchar(250)       not null,
    info                      text               not null,

    primary key ( id )
);
create index bi_folders_project     on bi_folders ( ref_project );
create index bi_folders_owner       on bi_folders ( ref_owner );
create index bi_folders_parent      on bi_folders ( ref_parent );
create index bi_folders_team        on bi_folders ( ref_team );
create index bi_folders_restriction on bi_folders ( restriction );

-- --------------------------------------------------------
-- BI_PROJECTS
--
-- Stores: com.interact.sas.bi.data.Project
-- --------------------------------------------------------
create table bi_projects
(
    id              int             not null,
    ref_user        int             not null,    -- References: cmn_users.id
    ref_team        int             not null,    -- References: cmn_groups.id
    restriction     int             not null,
    name            varchar(80)     not null,
    info            text            not null,
    
    primary key ( id ),
    unique ( name )
);
create index bi_projects_user     on bi_projects ( ref_user );
create index bi_projects_team     on bi_projects ( ref_team );

-- --------------------------------------------------------
-- BI_FOLDER_ROOTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table bi_folder_roots
(
    ref_project     int         not null,    -- References: bi_projects.id
    ref_folder      int         not null,    -- References: bi_folders.id
    ref_source      int         not null,    -- References: item source id
    scope           smallint    not null,
    type            smallint    not null,

    unique ( ref_project, ref_source, scope, type )
);
create index bi_folder_roots_project_scope on bi_folder_roots ( ref_project, scope );
create index bi_folder_roots_folder        on bi_folder_roots ( ref_folder );
create index bi_folder_roots_source        on bi_folder_roots ( ref_source );

-- --------------------------------------------------------
-- BI_QUERY_CHARTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table bi_query_charts
(
    ref_analysis                int             not null,    -- References: bi_artefacts.id
    type                        int             not null,
    options                     int             not null,
    background_color            int             not null,
    axes_tick_rotate            int             not null,
    legend_alignment            int             not null,
    legend_position             int             not null,
    slicer_alignment            int             not null,
    slicer_position             int             not null,
    page_axis                   int             not null,
    chart_axis                  int             not null,
    series_axis                 int             not null,
    plot_axis                   int             not null,
    width                       int             not null,
    height                      int             not null,
    x_axis_angle                int             not null,
    y_axis_angle                int             not null,  
    slicer_font                 varchar(40)     not null,
    axes_tick_font              varchar(40)     not null,
    legend_font                 varchar(40)     not null,
    axes_font                   varchar(40)     not null,
    axes_horizontal_label       varchar(40)     not null,
    axes_vertical_label         varchar(40)     not null,
    font                        varchar(40)     not null,
    title                       varchar(80)     not null,

    unique( ref_analysis )
);
create index bi_query_charts_analysis on bi_query_charts ( ref_analysis );

-- --------------------------------------------------------
-- BI_MAPS
--
-- Stores: com.interact.sas.bi.data.Map
-- --------------------------------------------------------
create table bi_maps
(
    id                         int               not null,
    ref_server                 int               not null,    -- References: bi_servers.id
    ref_folder                 int               not null,    -- References: bi_folders.id
    ref_owner                  int               not null,    -- References: cmn_users.id
    ref_team                   int               not null,    -- References: cmn_groups.id
    restriction                int               not null,
    zoom_initial               smallint          not null,
    type                       smallint          not null,
    position_initial           varchar(40)       not null,
    name                       varchar(80)       not null,
    "sql"                      text              not null,
    info                       text              not null,

    primary key ( id )
);
create index bi_maps_server on bi_maps ( ref_server );
create index bi_maps_folder on bi_maps ( ref_folder );
create index bi_maps_owner  on bi_maps ( ref_owner );
create index bi_maps_team   on bi_maps ( ref_team );

-- --------------------------------------------------------
-- BI_PENDENCIES
--
-- Stores: com.interact.sas.bi.data.AnalysisPending
-- --------------------------------------------------------
create table bi_pendencies
(
    id                         int               not null,
    ref_analysis               int               not null,    -- References: bi_artefacts.id
    dt_published               date              not null,

    primary key ( id )
);
create index bi_pendencies_analysis   on bi_pendencies ( ref_analysis );

-- --------------------------------------------------------
-- BI_CUBE_RESTRICTIONS
--
-- Stores: N/A
-- --------------------------------------------------------
create table bi_cube_restrictions
(
    ref_cube                   int               not null,    -- References: bi_servers.id
    restriction                int               not null,

    unique ( ref_cube )
);

-- --------------------------------------------------------
-- BI_QUERIE_EXPORTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table bi_query_exports
(
    ref_analysis               int               not null,    -- References: bi_artefacts.id
    page_size                  int               not null,
    page_orientation           int               not null,
    chart_split                smallint          not null,
    page_height                double            not null,
    page_width                 double            not null,
    table_width                double            not null,

    unique ( ref_analysis )
);

-- --------------------------------------------------------
-- BI_ARTEFACTS
--
-- Stores: com.interact.sas.bi.data.Artefact
-- --------------------------------------------------------
create table bi_artefacts
(
    id              int          not null,
    ref_server      int          not null,    -- References: bi_servers.id
    ref_folder      int          not null,    -- References: bi_folders.id
    ref_owner       int          not null,    -- References: cmn_users.id
    ref_team        int          not null,    -- References: cmn_groups.id
    type            int          not null,    -- See: com.interact.sas.bi.data.Artefact.TYPE
    restriction     int          not null,
    name            varchar(80)  not null,
    "file"          varchar(80)  not null,
    cube            varchar(250) not null,
    description     text         not null,
    mdx             text         not null,

    primary key     (id)
);
create index ix_bi_artefacts_folder on bi_artefacts(ref_folder);
create index ix_bi_artefacts_owner  on bi_artefacts(ref_owner);
create index ix_bi_artefacts_team   on bi_artefacts(ref_team);
create index ix_bi_artefacts_server on bi_artefacts(ref_server);