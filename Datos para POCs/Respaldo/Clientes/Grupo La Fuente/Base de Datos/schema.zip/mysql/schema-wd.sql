-- ----------------------------------------------------------------------------
--
-- Module:   WD
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-bi.sql $
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------
-- WD_WORKFLOWS
--
-- Stores: com.interact.sas.web.zk.workflow.data.Workflow
-- -----------------------------------------------------------
create table wd_workflows
(
    id                      int                 not null,
    ref_owner               int                 not null,    -- References: cmn_users.id
    ref_team                int                 not null,    -- References: cmn_groups.id
    restriction             int                 not null,
    scope                   tinyint             not null,
    dt_created              date                not null,
    name                    varchar(80)         not null,
    info                    text                not null,

    primary key ( id )
);
create index wd_workflows_owner on wd_workflows( ref_owner );
create index wd_workflows_team  on wd_workflows( ref_team );

-- -----------------------------------------------------------
-- WD_TASKS
--
-- Stores: com.interact.sas.web.zk.workflow.data.WorkflowTask
-- -----------------------------------------------------------
create table wd_tasks
( 
    id                      int                 not null,
    ref_workflow            int                 not null,    -- References: cmn_processes.id
    ref_pool                int                 not null,    -- References: cmn_processes_tasks.id
    ref_subprocess          int                 not null,    -- References: wd_workflows.id
    ref_file                int                 not null,    -- References: vfs_files.id
    ref_attached_to         int                 not null,    -- References: wd_tasks.id
    origin                  int                 not null,
    seq                     int                 not null,
    pos_x                   int                 not null,
    pos_y                   int                 not null,
    shape_width             int                 not null,
    shape_height            int                 not null,
    label_pos_x             int                 not null,
    label_pos_y             int                 not null,
    label_width             int                 not null,
    label_height            int                 not null,
    type                    smallint            not null,
    background_color        varchar(7)          not null,
    border_color            varchar(7)          not null,
    text_color              varchar(7)          not null,
    fl_options              varchar(32)         not null,
    mnemonic                varchar(40)         not null,
    name                    varchar(80)         not null,
    font_style              varchar(250)        not null,
    info                    text                not null, 

    primary key ( id )
);
create index wd_tasks_workflow    on wd_tasks( ref_workflow );
create index wd_tasks_pool        on wd_tasks( ref_pool );
create index wd_tasks_subprocess  on wd_tasks( ref_subprocess );
create index wd_tasks_file        on wd_tasks( ref_file );
create index wd_tasks_attached_to on wd_tasks( ref_attached_to );

-- -----------------------------------------------------------
-- WD_BINDINGS
--
-- Stores: com.interact.sas.
-- -----------------------------------------------------------
create table wd_bindings
(
    id                       int                 not null,
    ref_from_task            int                 not null,     -- References: cmn_workflow_tasks.id
    ref_to_task              int                 not null,     -- References: cmn_workflow_tasks.id
    label_width              int                 not null,
    label_height             int                 not null,
    from_x                   int                 not null,
    from_y                   int                 not null,
    to_x                     int                 not null,
    to_y                     int                 not null,
    from_handle              tinyint             not null,
    to_handle                tinyint             not null,
    fl_deleted               tinyint             not null,
    message_type             tinyint             not null,
    text_color               varchar(7)          null,
    anchor                   varchar(40)         not null,
    label                    varchar(80)         not null,
    font_style               varchar(250)        not null,
    line_segments            varchar(250)        not null,

    primary key ( id ),
    unique ( ref_from_task, ref_to_task )
);
create index wd_bindings_from_task on wd_bindings( ref_from_task );
create index wd_bindings_to_task   on wd_bindings( ref_from_task );