-- -----------------------------------------------------------------------------
--
-- Module:   CMN
--
-- Schema:   80.1
--
-- Revision: $Revision: 103773 $
--
-- Date:     $Date: 2012-02-27 17:02:23 -0300 (Seg, 27 Fev 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-cmn.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- CMN_APPOINTMENTS
--
-- Stores: com.interact.sas.cmn.data.Appointment
-- --------------------------------------------------------
create table cmn_appointments
(
    id              int             not null,
    ref_source      int             not null,    -- References: cmn_subjects.id or cmn_users.id
    ref_author      int             not null,    -- References: cmn_users.id
    ref_original    int             not null,    -- References: cmn_appointments.id
    ref_item        int             not null,    -- References: cmn_subjects.id
    family          int             not null,    -- See: com.interact.sas.cmn.data.Appointment.FAMILY
    recurrence      int             not null,
    notice          tinyint         not null,
    options         varchar(32)     not null,
    title           varchar(160)    not null,
    location        varchar(160)    not null,
    ts_start        datetime        not null,
    ts_end          datetime        not null,
    dt_create       timestamp       not null,
    description     text            not null,
	
    primary key  ( id )
);
create index cmn_appointments_original on cmn_appointments( ref_original );
create index cmn_appointments_item     on cmn_appointments( ref_item );

-- --------------------------------------------------------
-- CMN_DOMAINS
--
-- Stores: com.interact.sas.cmn.data.Domain
-- --------------------------------------------------------
create table cmn_domains
(
    id              int             not null,
    name            varchar(80)     not null,
    
    primary key ( id ),
    unique ( name )
);

-- --------------------------------------------------------
-- CMN_ENTITIES
--
-- Stores: com.interact.sas.cmn.data.Entity
-- --------------------------------------------------------
create table cmn_entities 
(
    id              int             not null,
    ref_parent      int             not null,    -- References: cmn_entities.id
    ref_owner       int             not null,    -- References: cmn_users.id
    members         int             not null,
    status          int             not null,    -- See: com.interact.sas.cmn.data.Entity.STATUS 
    type            varchar(40)     not null,
    mnemonic        varchar(40)     not null,
    name            varchar(80)     not null,
    description     text            not null,
    
    primary key ( id )
);

-- --------------------------------------------------------
-- CMN_ENTITY_TEAM
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_entity_team
(
    ref_entity       int            not null,    -- References: cmn_entities.id
    ref_owner        int            not null,    -- References: cmn_users.id
    
    unique ( ref_entity, ref_owner )
);

-- --------------------------------------------------------
-- CMN_SEQUENCES
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_sequences
(  
    id              int             not null,
    name            varchar(80)     not null,

    primary key (name)
);

-- --------------------------------------------------------
-- CMN_GROUPS
--
-- Stores: com.interact.sas.cmn.data.UserGroup
-- --------------------------------------------------------
create table cmn_groups
(
    id              int            not null,
    ref_unit        int            not null,    -- References: cmn_units.id
    mnemonic        varchar(40)    not null,
    label           varchar(160)   not null,
    info            text           not null,
    
    primary key ( id ),
    unique ( mnemonic )
);

-- --------------------------------------------------------
-- CMN_USERS
--
-- Stores: com.interact.sas.cmn.data.User
-- --------------------------------------------------------
create table cmn_users
(
    id              int             not null,
    ref_unit        int             not null,    -- References: cmn_units.id
    ref_tags        int             not null,    -- References: cmn_tag_kinds.id
    category        int             not null,    -- See: com.interact.sas.cmn.data.User.CATEGORY
    type            int             not null,    -- See: com.interact.sas.cmn.data.User.TYPE
    credential      tinyint         not null,
    certificate     smallint        not null,
    authorizations  smallint        not null,
    confidence      smallint        not null,
    last_login      date            default null,
    dt_creation     timestamp,
    language        varchar(10)     null,
    "number"        varchar(20)     not null,
    options         varchar(32)     not null,
    phone1          varchar(40)     not null,
    phone2          varchar(40)     not null,
    designation     varchar(40)     not null,
    password        varchar(42)     not null,
    last_version    varchar(80)     not null,
    email           varchar(80)     not null,
    login           varchar(80)     not null,
    name            varchar(160)    not null,
    info            text            not null,

    primary key ( id ),
    unique ( login )
);
create index cmn_users_name     on cmn_users( name );
create index cmn_users_tags     on cmn_users( ref_tags );
create index cmn_users_language on cmn_users( language );

-- --------------------------------------------------------
-- CMN_LOGINS
--
-- Stores: com.interact.sas.cmn.util.Login
-- --------------------------------------------------------
create table cmn_logins
(
    ref_user        int            not null,    -- References: cmn_users.id
    "session"       int            not null,
    dt_login        datetime       not null,
    dt_logout       datetime       default null,
    origin          varchar(80)    not null,

    primary key ( "session" )
);
create index cmn_logins_user   on cmn_logins ( ref_user );
create index cmn_logins_login  on cmn_logins ( dt_login );
create index cmn_logins_logout on cmn_logins ( dt_logout );

-- --------------------------------------------------------
-- CMN_PROPERTIES
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_properties
(
    name     varchar(40)     not null,
    value    varchar(250)    not null,

    primary key ( name )
);

-- --------------------------------------------------------
-- CMN_NOTIFICATIONS
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_notifications
(
    id               int             not null,
    ref_source       int             not null,    -- References: qms_occurrences.id
    ref_from         int             not null,    -- References: cmn_users.id
    ref_to           int             not null,    -- References: cmn_users.id
    delivered        tinyint         not null,
    event            smallint        not null,
    type             smallint        not null,
    dt_sent          date            not null,
    message          text            not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- CMN_SERIALS
--
-- Stores: com.interact.sas.cmn.data.SerialNumber
-- --------------------------------------------------------
create table cmn_serials
(
    id            int             not null,
    ref_domain    int             not null,    -- References: cmn_domains.id
    start_value   int             not null,
    current_value int             not null,
    pattern       varchar(24)     not null,
    name          varchar(120)    not null,
    
    primary key  ( id ),
    unique ( ref_domain, pattern )
);

-- --------------------------------------------------------
-- CMN_ROLES
--
-- Stores: com.interact.sas.cmn.data.Role
-- --------------------------------------------------------
create table cmn_roles
(
    id            int            not null,
    ref_user      int            not null,    -- References: cmn_users.id
    permission    tinyint        not null,
    role          varchar(80)    not null,

    primary key( id ),
    unique ( role, ref_user )
);


-- --------------------------------------------------------
-- CMN_MEMBERSHIP
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_membership
(
    ref_group    int    not null,    -- References: cmn_groups.id
    ref_user     int    not null,    -- References: cmn_users.id

    unique ( ref_group, ref_user )
);
create index cmn_membership_group on cmn_membership( ref_group );
create index cmn_membership_user  on cmn_membership( ref_user );

-- --------------------------------------------------------
-- CMN_RESTRICTIONS
--
-- Stores: com.interact.sas.cmn.data.Restriction
-- --------------------------------------------------------
create table cmn_restrictions 
(
  ref_source          int          not null,    -- References: Item id
  restriction         int          not null,
  type                smallint     not null,    -- See: com.interact.sas.cmn.data.Restriction.TYPE

  unique ( restriction, ref_source, type )
);
create index cmn_restrictions_restriction on cmn_restrictions ( restriction );
create index cmn_restrictions_type        on cmn_restrictions ( type );
create index cmn_restrictions_source      on cmn_restrictions ( type, ref_source );

-- --------------------------------------------------------
-- CMN_TEAMS
--
-- Stores: com.interact.sas.cmn.data.Team
-- --------------------------------------------------------
create table cmn_teams
(
    ref_team       int      not null,    -- References: cmn_groups.id
    ref_user       int      not null,    -- References: cmn_users.id

    unique ( ref_team, ref_user )
);
create index cmn_teams_team on cmn_teams ( ref_team );
create index cmn_teams_user on cmn_teams ( ref_user );

-- --------------------------------------------------------
-- CMN_DEFAULTS
--
-- Stores: com.interact.sas.cmn.data.DefaultsFamily
-- --------------------------------------------------------
create table cmn_defaults
(
    id             int            not null,
    name           varchar(80)    not null,
    description    varchar(160)   not null,

    primary key ( id ),
    unique ( name )
);


-- --------------------------------------------------------
-- CMN_DEFAULT_VALUES
--
-- Stores: com.interact.sas.cmn.data.DefaultValue
-- --------------------------------------------------------
create table cmn_default_values
(
    ref_defaults   int            not null,    -- References: cmn_defaults.id
    seq_no         smallint       not null,
    value          varchar(160)   not null,

    unique ( ref_defaults, seq_no )
);

-- --------------------------------------------------------
-- CMN_CATEGORIES
--
-- Stores: com.interact.sas.cmn.data.Category
-- --------------------------------------------------------
create table cmn_categories
(
    id                int             not null,
    ref_owner         int             not null,             -- References: cmn_users.id
    ref_parent        int             not null,             -- References: cmn_categories.id
    ref_team          int             not null,             -- References: cmn_groups.id
    ref_executive     int             not null,             -- References: cmn_users.id
    ref_director      int             not null,             -- References: cmn_users.id
    restriction       int             default 0 not null,
    classification    int             not null,
    family            tinyint         not null,             -- See: com.interact.sas.cmn.data.Category.FAMILY
    icon              tinyint         not null,
    type              varchar(40)     null,
    mnemonic          varchar(40)     not null,
    name              varchar(160)    not null,
    info              text            not null,
    
    primary key ( id )
);
create index cmn_categories_owner on cmn_categories ( ref_owner );
create index cmn_categories_team  on cmn_categories ( ref_team );

-- --------------------------------------------------------
-- CMN_REQUIREMENTS
--
-- Stores: com.interact.sas.cmn.data.Requirement
-- --------------------------------------------------------
create table cmn_requirements
(
    id               int             not null,
    ref_rule         int             not null,    -- References: cmn_rules.id
    classification   varchar(20)     not null,
    name             varchar(80)     not null,
    info             text            not null,

    primary key  ( id )
);
create index cmn_requirements_rule on cmn_requirements( ref_rule );

-- --------------------------------------------------------
-- CMN_RULES
--
-- Stores: com.interact.sas.cmn.data.Rule
-- --------------------------------------------------------
create table cmn_rules
(
    id               int             not null,
    ref_owner        int             not null,    -- References: cmn_users.id
    ref_category     int             not null,    -- References: cmn_categories.id
    state            int             not null,    -- See: com.interact.sas.cmn.data.Rule.STATES 
    mnemonic         varchar(40)     not null,
    name             varchar(80)     not null,
    info             text            not null,

    primary key  ( id )
);
create index cmn_rules_owner    on cmn_rules ( ref_owner );
create index cmn_rules_category on cmn_rules ( ref_category );
create index cmn_rules_name     on cmn_rules ( name );

-- --------------------------------------------------------
-- CMN_RESOURCES
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_resources
(
    id              int            not null,
    ref_category    int            not null,    -- References: cmn_categories.id
    "name"          varchar(80)    not null,
    info            text           not null,

    primary key ( id )
);
create index cmn_resources_category on cmn_resources ( ref_category );

-- --------------------------------------------------------
-- CMN_RESOURCE_USAGES
--
-- Stores: N/A
-- --------------------------------------------------------
create table cmn_resource_usages
(
    id              int            not null,
    ref_resource    int            not null,    -- References: cmn_resources.id
    ref_user        int            not null,    -- References: cmn_users.id
    purpose         varchar(240)   not null,
    dt_from         date           not null,
    dt_until        date           not null,
    tm_from         time           not null,
    tm_until        time           not null,

    primary key ( id )
);
create index cmn_resource_usage_resource on cmn_resource_usages ( ref_resource );
create index cmn_resource_usage_user     on cmn_resource_usages ( ref_user );

-- -----------------------------------------------------------------------------
-- CMN_UNITS
--
-- Stores: com.interact.sas.cmn.data.Unit
-- -----------------------------------------------------------------------------
create table cmn_units
(
    id              int             not null,
    ref_parent      int             default 0,    -- References: cmn_units.id
    ref_tags        int             not null,     -- References: cmn_tag_kinds.id
    type            tinyint         not null,
    state           smallint        not null,
    mnemonic        varchar(64)     null,
    name            varchar(200)    not null,
    info            text            not null,

    primary key ( id )
);
create index cmn_units_type   on cmn_units ( type );
create index cmn_units_parent on cmn_units ( ref_parent );
create index cmn_units_name   on cmn_units ( name );
create index cmn_units_tags   on cmn_units ( ref_tags );
create index cmn_units_state  on cmn_units ( state );

-- -----------------------------------------------------------------------------
-- CMN_DEPARTMENTS
--
-- Stores: com.interact.sas.cmn.data.Department
-- -----------------------------------------------------------------------------
create table cmn_departments
(
    id              int             not null,
    ref_unit        int             not null,    -- References: cmn_units.id
    ref_tags        int             not null,    -- References: cmn_tag_kinds.id
    state           smallint        not null,    -- See: com.interact.sas.cmn.data.Department.STATES 
    mnemonic        varchar(64)     not null,
    name            varchar(200)    not null,
    info            text            not null,

    primary key ( id )
);
create index cmn_departments_unit on cmn_departments ( ref_unit );
create index cmn_departments_name on cmn_departments ( name );
create index cmn_departments_tags on cmn_departments ( ref_tags );

-- -----------------------------------------------------------------------------
-- CMN_SECTORS
--
-- Stores: com.interact.sas.cmn.data.Sector
-- -----------------------------------------------------------------------------
create table cmn_sectors
(
    id              int             not null,
    ref_department  int             not null,    -- References: cmn_departments.id
    ref_tags        int             not null,    -- References: cmn_tag_kinds.id
    state           smallint        not null,    -- See: com.interact.sas.cmn.data.Sector.STATES 
    mnemonic        varchar(64)     not null,
    name            varchar(200)    not null,
    info            text            not null,

    primary key ( id )
);
create index cmn_sectors_department on cmn_sectors ( ref_department );
create index cmn_sectors_name       on cmn_sectors ( name );
create index cmn_sectors_tags       on cmn_sectors ( ref_tags );

-- -----------------------------------------------------------------------------
-- CMN_HISTORY
--
-- Stores: com.interact.sas.cmn.data.History
-- -----------------------------------------------------------------------------
create table cmn_history
(
    id              int             not null,
    ref_source      int             not null,    -- References: source item id
    ref_author      int             not null,    -- References: cmn_users.id
    family          int             not null,    -- See: com.interact.sas.cmn.data.History.FAMILIES
    dt_created      date            not null,
    description     text            not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CMN_ANNOTATIONS
--
-- Stores: com.interact.sas.cmn.data.Annotation
-- -----------------------------------------------------------------------------
create table cmn_annotations 
( 
    id                    int             not null,
    ref_source            int             not null,    -- References: source item id
    ref_user              int             not null,    -- References: cmn_users.id
    ref_classification    int             not null,    -- References: cmn_classifications.id
    family                smallint        not null,    -- See: com.interact.sas.cmn.data.Annotation.FAMILY
    type                  smallint        not null,    -- See: com.interact.sas.cmn.data.Annotation.TYPES
    origin                tinyint         not null,    -- See: com.interact.sas.cmn.data.Annotation.ORIGIN
    dt_start              date            not null,
    dt_end                date            not null,
    info                  text            not null,

    primary key ( id )
);
create index cmn_annotations_source on cmn_annotations ( family, ref_source );
create index cmn_annotations_item   on cmn_annotations ( family, ref_source, dt_start, dt_end );
create index cmn_annotations_class  on cmn_annotations ( ref_classification );

-- --------------------------------------------------------
-- Table CMN_EMPLOYMENTS
--
-- Stores: com.interact.sas.cmn.data.Executive
-- --------------------------------------------------------
create table cmn_employments
(
    id                       int                  not null,
    ref_user                 int                  not null,    -- References: cmn_users.id
    ref_function             int                  not null,    -- References: cmn_functions.id
    ref_category             int                  not null,    -- References: cmn_categories.id
    ref_unit                 int                  not null,    -- References: cmn_units.id
    ref_department           int                  not null,    -- References: cmn_departments.id
    ref_sector               int                  not null,    -- References: cmn_sectors.id
    is_default               tinyint              not null,
    state                    tinyint              not null,
    dt_from                  date                 default null,
    dt_until                 date                 default null,
    info                     text                 not null,

    primary key ( id ),
    unique ( ref_function, ref_user )
);
create index cmn_employments_category   on cmn_employments( ref_category );
create index cmn_employments_unit       on cmn_employments( ref_unit );
create index cmn_employments_department on cmn_employments( ref_department );
create index cmn_employments_sector     on cmn_employments( ref_sector );
create index cmn_employments_user       on cmn_employments( ref_user );
create index cmn_employments_function   on cmn_employments( ref_function );
create index cmn_employments_state      on cmn_employments( state );

-- --------------------------------------------------------
-- CMN_FUNCTIONS
--
-- Stores: com.interact.sas.cmn.data.Function
-- --------------------------------------------------------
create table cmn_functions
(
    id                      int                 not null,
    ref_category            int                 not null,    -- References: cmn_categories.id
    ref_type_function       int                 not null,    -- References: hrm_catergories.id
    state                   int                 not null,    -- See: com.interact.sas.cmn.data.Function.STATES 
    sex                     varchar(40)         not null,
    age                     varchar(40)         not null,
    salary                  varchar(40)         not null,
    name                    varchar(160)        not null,
    experience              text                not null,
    info                    text                not null,

    primary key ( id )
);
create index cmn_functions_category on cmn_functions ( ref_category );
create index cmn_functions_type     on cmn_functions ( ref_type_function );

-- --------------------------------------------------------
-- CMN_EMPLOYEE_HIERARCHY
--
-- Stores: com.interact.sas.cmn.data.EmployeeHierarchy
-- --------------------------------------------------------
create table cmn_employee_hierarchy
(
    id                  int    not null,
    ref_employment      int    not null,    -- References: cmn_employments.id
    ref_parent          int    not null,    -- References: cmn_employee_hierarchy.id
    ref_root            int    not null,    -- References: cmn_employee_hierarchy.id
    ref_substitute      int    not null,    -- References: cmn_users.id
    fl_principal        int    not null,
    
    primary key ( id ),
    unique ( ref_employment, ref_parent )
);
create index cmn_employee_hierarchy_employment on cmn_employee_hierarchy ( ref_employment );
create index cmn_employee_hierarchy_ref_parent on cmn_employee_hierarchy ( ref_parent );
create index cmn_employee_hierarchy_root       on cmn_employee_hierarchy ( ref_root );
create index cmn_employee_hierarchy_substitute on cmn_employee_hierarchy ( ref_substitute );

-- --------------------------------------------------------
-- CMN_TAG_FAMILIES
--
-- Stores: com.interact.sas.cmn.data.TagFamily
-- --------------------------------------------------------
create table cmn_tag_families
(
    id              int             not null,
    ref_category    int             not null,    -- References: cmn_categories.id
    ref_owner       int             not null,    -- References: cmn_users.id
    mnemonic        varchar(80)     not null,
    name            varchar(80)     not null,
    info            text            not null,
    
    primary key ( id )
);
create index cmn_tag_families_owner on cmn_tag_families ( ref_owner );

-- --------------------------------------------------------
-- CMN_TAG_KINDS
--
-- Stores: com.interact.sas.cmn.data.TagKind
-- --------------------------------------------------------
create table cmn_tag_kinds
(
    id              int             not null,
    ref_family      int             not null,    -- References: cmn_tag_families.id
    ref_options     int             not null,    -- References: cmn_tag_options.id
    ref_owner       int             not null,    -- References: cmn_users.id
    restriction     int             not null,    -- References: cmn_restrictions.restriction
    type            smallint        not null,    -- See: com.interact.sas.cmn.data.TagKind.TYPES
    options         varchar(32)     not null,
    mnemonic        varchar(80)     not null,
    name            varchar(80)     not null,
    default_content varchar(240)    not null,
    info            text            not null,
    
    primary key ( id ),
    unique key ( ref_family, mnemonic )
);
create index cmn_tag_kinds_owner   on cmn_tag_kinds ( ref_owner );
create index cmn_tag_kinds_family  on cmn_tag_kinds( ref_family );
create index cmn_tag_kinds_options on cmn_tag_kinds( ref_options );

-- --------------------------------------------------------
-- CMN_TAG_MAPPINGS
--
-- Stores: com.interact.sas.cmn.data.TagMapping
-- --------------------------------------------------------
create table cmn_tag_mappings
(
    ref_source      int             not null,    -- References: source item id
    ref_kind        int             not null,    -- References: cmn_tag_kinds.id
    ref_template    int             not null,    -- References: cmn_tag_templates.id
    type            int             not null,
    position        int             not null,
    content         varchar(4000)   not null    
);
create index cmn_tag_maps_source       on cmn_tag_mappings ( ref_source );
create index cmn_tag_maps_kind         on cmn_tag_mappings ( ref_kind );
create index cmn_tag_mappings_template on cmn_tag_mappings ( ref_template );
create index cmn_tag_mappings_kind     on cmn_tag_mappings ( ref_kind );
create index cmn_tag_mappings_source   on cmn_tag_mappings ( ref_source );
create index cmn_tag_mappings_type     on cmn_tag_mappings ( type );

-- --------------------------------------------------------
-- CMN_TAG_OPTIONS
--
-- Stores: com.interact.sas.cmn.data.TagOption
-- --------------------------------------------------------
create table cmn_tag_options
(
    id              int            not null,
    ref_category    int            not null,    -- References: cmn_categories.id
    ref_owner       int            not null,    -- References: cmn_users.id
    name            varchar(80)    not null,
    info            text           not null,
    
    primary key ( id )
);
create index cmn_tag_options_owner on cmn_tag_options ( ref_owner );

-- --------------------------------------------------------
-- CMN_TAG_OPTION_ITEMS
--
-- Stores: com.interact.sas.cmn.data.TagOptionItem
-- --------------------------------------------------------
create table cmn_tag_option_items
(
    id              int             not null,
    ref_option      int             not null,    -- References: cmn_tag_options.id
    position        smallint        not null,
    obsolete        tinyint         not null,
    name            varchar(80)     not null,
    content         varchar(240)    not null,
    
    primary key ( id ),
    unique key ( ref_option, content )
);

-- -------------------------------------------
-- CMN_TAG_TEMPLATES
--
-- Stores: com.interact.sas.cmn.data.TagTemplate
-- -------------------------------------------
create table cmn_tag_templates
(
    id              int          not null,
    ref_category    int          not null,    -- References: cmn_categories.id
    ref_owner       int          not null,    -- References: cmn_users.id
    ref_rule        int          not null,    -- References: cmn_rules.id
    mnemonic        varchar(80)  not null,
    name            varchar(160) not null,
    info            text         not null,

    primary key ( id )
);
create index cmn_tag_templates_owner on cmn_tag_templates( ref_owner );
create index cmn_tag_templates_rule  on cmn_tag_templates( ref_rule );

-- -------------------------------------------
-- CMN_TAG_TEMPLATE_KINDS
--
-- Stores: N/A
-- -------------------------------------------
create table cmn_tag_template_kinds
(
    ref_template int         not null,    -- References: cmn_tag_templates.id
    ref_kind     int         not null,    -- References: cmn_tag_kinds.id
    position     int         not null,

    unique ( ref_template, ref_kind )
);

-- -------------------------------------------
-- CMN_CONTACTS
--
-- Stores: com.interact.sas.cmn.data.Contact
-- -------------------------------------------
create table cmn_contacts
(
    id       int             not null,
    name     varchar(160)    not null,
    email    varchar(80)     not null,
    info     text            not null,
    
    unique key  (id, name, email)
);

-- -------------------------------------------
-- CMN_CLASSIFICATIONS
--
-- Stores: com.interact.sas.cmn.data.Classification
-- -------------------------------------------
create table cmn_classifications 
( 
    id                  int             not null,
    family              smallint        not null,    -- See: com.interact.sas.cmn.data.Classification.FAMILIES
    state               smallint        not null,    -- See: com.interact.sas.cmn.data.Classification.STATES
    name                varchar(80)     not null,    

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CMN_LOCKS
--
-- Stores: com.interact.sas.cmn.data.Lock
-- -----------------------------------------------------------------------------
create table cmn_locks
(
    ref_source              int             not null,    -- References: source item id
    ref_login               int             not null,    -- References: cmn_logins.session
    family                  smallint        not null,    -- See: com.interact.sas.cmn.data.Lock.FAMILY
    dt_created              timestamp       not null default current_timestamp,

    unique ( family, ref_source )
);
create index cmn_locks_login on cmn_locks ( ref_login );

-- --------------------------------------------------------
-- CMN_TOPICS
--
-- Stores: com.interact.sas.cmn.data.Topic
-- --------------------------------------------------------
create table cmn_topics
(
    id              int            not null,
    ref_source      int            not null,    -- References: source item id
    family          smallint       not null,    -- See: com.interact.sas.cmn.data.Topic.FAMILY
    sequence        smallint       not null,
    name            varchar(80)    not null,
    info            text           not null,

    primary key ( id ),
    unique ( family, ref_source, name  )
);

-- --------------------------------------------------------
-- CMN_CALENDARS
--
-- Stores: com.interact.sas.cmn.data.Calendar
-- --------------------------------------------------------
create table cmn_calendars
(
    id                      int             not null,
    ref_project             int             not null,    -- References: prj_projects.id
    ref_calendar            int             not null,    -- References: cmn_calendars.id
    begin_tolerance         int             not null,
    end_tolerance           int             not null,
    login_control           tinyint         not null,
    is_default              tinyint         not null,
    name                    varchar(80)     not null,
    
    primary key ( id )
);
create index cmn_calendars_cal      on cmn_calendars ( ref_calendar );
create index cmn_calendars_ref_proj on cmn_calendars ( ref_project );

-- --------------------------------------------------------
-- CMN_CALENDAR_SCHEDULES
--
-- Stores: com.interact.sas.cmn.data.CalendarSchedule
-- --------------------------------------------------------
create table cmn_calendar_schedules
(
    id                      int             not null,
    ref_calendar            int             not null,    -- References: cmn_calendars.id
    week_day                smallint        not null,
    tm_begin                time            null,
    tm_end                  time            null,

    primary key ( id )
);
create index cmn_calendar_schedules_cal on cmn_calendar_schedules ( ref_calendar );

-- --------------------------------------------------------
-- CMN_CALENDAR_EXCEPTIONS
--
-- Stores: com.interact.sas.cmn.data.CalendarException
-- --------------------------------------------------------
create table cmn_calendar_exceptions
(
    id                      int             not null,
    ref_calendar            int             not null,    -- References: cmn_calendars.id
    dt_start                date            null,
    dt_end                  date            null,
    name                    varchar(80)     not null,

    primary key ( id )
);
create index cmn_calendar_exceptions_cal on cmn_calendar_exceptions ( ref_calendar );

-- --------------------------------------------------------
-- CMN_LIFECYCLE
--
-- Stores: com.interact.sas.cmn.data.LifeCycleEvent
-- --------------------------------------------------------
create table cmn_lifecycle
(
    id                    int                 not null,
    ref_user              int                 not null,    -- References: cmn_users.id
    ref_source            int                 not null,    -- References: source item id
    from_user             int                 not null,    -- References: cmn_users.id
    to_user               int                 not null,    -- References: cmn_users.id
    family                smallint            not null,    -- See: com.interact.sas.cmn.data.LifeCycleEvent.FAMILY
    origin                smallint            not null,    -- See: com.interact.sas.cmn.data.LifeCycleEvent.ORIGIN
    action                smallint            not null, 
    from_state            smallint            not null,   
    to_state              smallint            not null, 
    dt_created            timestamp           null,
    info                  text                not null,

    primary key ( id )
);
create index cmn_lifecycle_user         on cmn_lifecycle ( ref_user );
create index cmn_lifecycle_family       on cmn_lifecycle ( family );
create index cmn_lifecycle_source       on cmn_lifecycle ( ref_source );
create index cmn_lifecycle_created      on cmn_lifecycle ( dt_created );
create index cmn_lifecycle_origin       on cmn_lifecycle ( origin );
create index cmn_lifecycle_action       on cmn_lifecycle ( action );
create index cmn_lifecycle_from_state   on cmn_lifecycle ( from_state );
create index cmn_lifecycle_from_user    on cmn_lifecycle ( from_user );
create index cmn_lifecycle_to_state     on cmn_lifecycle ( to_state );
create index cmn_lifecycle_to_user      on cmn_lifecycle ( to_user );

-- --------------------------------------------------------
-- CMN_CALENDAR_USERS
--
-- Stores: com.interact.sas.cmn.data.CalendarUser
-- --------------------------------------------------------

create table cmn_calendar_users
(
    ref_calendar            int             not null,    -- References: cmn_calendars.id
    ref_user                int             not null,    -- References: cmn_users.id
    begin_tolerance         int             not null,
    end_tolerance           int             not null,
    control_type            tinyint         not null,

    unique ( ref_calendar, ref_user )
);

-- ----------------------------------------------------------------------------------------
-- CMN_WORKAROUND
--
-- Stores: com.interact.sas.cmn.data.Workaround
-- ----------------------------------------------------------------------------------------
create table cmn_workaround
(
    ref_source    int             not null,    -- References: source item id
    family        smallint        not null,    -- See: com.interact.sas.cmn.data.Workaround.FAMILY
    type          smallint        not null,    -- See: com.interact.sas.cmn.data.Workaround.TYPE
    content       varchar(240)    not null
);
create index ix_cmn_work_family     on cmn_workaround(family);
create index ix_cmn_work_type       on cmn_workaround(type);
create index ix_cmn_work_ref_source on cmn_workaround(ref_source);

-- --------------------------------------------------------
-- CMN_DATA
--
-- Stores: com.interact.sas.cmn.data.DataRecord
-- --------------------------------------------------------
create table cmn_data
(
    value            double          not null,
    competence       date            not null,
    created          timestamp       not null,
    origin           varchar(40)     not null,
    mnemonic         varchar(60)     not null
);
create index ix_cmn_data_mnemonic   on cmn_data(mnemonic);
create index ix_cmn_data_competence on cmn_data(competence);
create index ix_cmn_data_origin     on cmn_data(origin);

-- --------------------------------------------------------
-- CMN_PRINTSOURCES
--
-- Stores: com.interact.sas.cmn.data.PrintSource
-- --------------------------------------------------------
create table cmn_printsources
(
    id                          int                not null,
    type                        smallint           not null,
    name                        varchar(80)        not null,
    "user"                      varchar(80)        not null,
    password                    varchar(80)        not null,
    url                         varchar(160)       not null,
    
    primary key ( id ),
    unique ( name )
);

-- --------------------------------------------------------
-- CMN_SNAPS
--
-- Stores: com.interact.sas.cmn.data.Snap
-- --------------------------------------------------------
create table cmn_snaps
(
    ref_source    int         not null,    -- References: source item id
    ref_user      int         not null,    -- References: cmn_users.id
    family        smallint    not null,    -- See: com.interact.sas.cmn.data.Snap.FAMILY
    
    unique( ref_source, ref_user, family )
);
create index cmn_snaps_user   on cmn_snaps( ref_user );
create index cmn_snaps_source on cmn_snaps( family, ref_source );

-- --------------------------------------------------------
-- CMN_INDEXATIONS
--
-- Stores: com.interact.sas.cmn.data.Indexation
-- --------------------------------------------------------
create table cmn_indexations
(
    id             int          not null, 
    family         int          not null,    -- See: com.interact.sas.cmn.data.Indexation.FAMILY
    source         int          not null,    -- See: com.interact.sas.cmn.data.Indexation.STATE
    size           int          not null,
    state          tinyint      not null,
    duration       double,
    rate           double,
    dt_started     timestamp    not null,
    dt_finished    timestamp,

    primary key(id)
);

-- ------------------------------------------------------------
-- CMN_INFO
--
-- Stores: N/A
-- ------------------------------------------------------------
create table cmn_info
(
    id              int             not null,
    family          tinyint         not null,
    info            text            not null,
    
    primary key ( id )
);

-- --------------------------------------------------------
-- CMN_CHECKLISTS
--
-- Stores: com.interact.sas.cmn.data.Checklist
-- --------------------------------------------------------
create table cmn_checklists
(
    id                int                   not null,
    ref_owner         int                   not null,    -- References: cmn_users.id
    ref_category      int                   not null,    -- References: cmn_categories.id
    type              int                   not null,    -- See: com.interact.sas.cmn.data.Checklist.TYPE
    family            tinyint               not null,    -- See: com.interact.sas.cmn.data.Checklist.FAMILY
    state             tinyint               not null,    -- See: com.interact.sas.cmn.data.Checklist.STATES
    max_result        double                not null,
    limit_match       double                not null,
    limit_lower       double                not null,
    name              varchar(160)          not null,
    info              text                  not null, 
    
    primary key ( id )
);
create index ix_cmn_checklists_owner on cmn_checklists( ref_owner );

-- --------------------------------------------------------
-- CMN_CHECKLIST_TOPICS
--
-- Stores: com.interact.sas.cmn.data.ChecklistTopic
-- --------------------------------------------------------
create table cmn_checklist_topics
(
    id                  int                    not null,
    ref_checklist       int                    not null,    -- References: cmn_checklists.id
    ref_scale           int                    not null,    -- References: cmn_scales.id
    ref_appraiser       int                    not null,    -- References: cmn_users.id
    weight              double                 not null,
    classification      varchar(30)            not null,
    mnemonic            varchar(64)            not null,
    name                varchar(160)           not null,
    info                text                   not null,
    
    primary key ( id )
);
create index ix_cmn_check_topics_checklist on cmn_checklist_topics( ref_checklist );
create index ix_cmn_check_topics_scale     on cmn_checklist_topics( ref_scale );
create index ix_cmn_check_topics_appraiser on cmn_checklist_topics( ref_appraiser );

-- --------------------------------------------------------
-- CMN_SCALES
--
-- Stores: com.interact.sas.cmn.data.Scale
-- --------------------------------------------------------
create table cmn_scales
(
    id                int                    not null,
    state             int                    not null,    -- See: com.interact.sas.cmn.data.Scale.STATES
    name              varchar(160)           not null,
    info              text                   not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- CMN_SCALE_ITEMS
--
-- Stores: com.interact.sas.cmn.data.ScaleItem
-- --------------------------------------------------------
create table cmn_scale_items
(
    id                int                    not null,
    ref_scale         int                    not null,    -- References: cmn_scales.id
    position          int                    not null,
    weight            double                 not null,
    name              varchar(160)           not null,
    info              text                   not null,
    
    primary key ( id )
);
create index ix_cmn_scale_items_scale    on cmn_scale_items( ref_scale );
create index ix_cmn_scale_items_position on cmn_scale_items(position);
-- ------------------------------------------------------------------------------
-- CMN_CONTEXT
--
-- Stores: com.interact.sas.cmn.data.Context
-- ------------------------------------------------------------------------------
create table cmn_context
(
    id              int            not null,
    ref_model       int            not null,    -- References: bsc_models.id
    ref_source      int            not null,    -- References: source item id
    ref_owner       int            not null,    -- References: cmn_users.id
    item_size       int            not null,
    family          smallint       not null,
    ts_created      timestamp      null,
    name            varchar(160)   not null,
    url             varchar(250)   not null,
    info            text           not null,

    primary key ( id )
);
create index cmn_context_model  on cmn_context ( ref_model );
create index cmn_context_source on cmn_context ( ref_source );
create index cmn_context_owner  on cmn_context ( ref_owner );


-- --------------------------------------------------------
-- CMN_APPOINTMENT_ITEMS
--
-- Stores: com.interact.sas.cmn.data.AppointmentItem
-- --------------------------------------------------------
create table cmn_appointment_items
(
    id          int             not null,
    restriction int             not null,
    name        varchar(160)    not null,
    info        text            not null,

    primary key ( id )
);

-- ----------------------------------------------------
-- CMN_ITEM_CONTROLLERS
--
-- Stores: N/A
-- ----------------------------------------------------
create table cmn_item_controllers
(
    ref_owner     int             not null,    -- References: cmn_users.id
    ref_source    int             not null,    -- References: cmn_users.id or cmn_subjects.id 
    type          tinyint         not null,
    
    unique ( type, ref_owner, ref_source )
);
create index ix_cmn_item_controllers_type   on cmn_item_controllers ( type );
create index ix_cmn_item_controllers_owner  on cmn_item_controllers ( ref_owner );
create index ix_cmn_item_controllers_source on cmn_item_controllers ( ref_source );

-- --------------------------------------------------------
-- CMN_APPOINTMENT_PARTICIPANTS
--
-- Stores: com.interact.sas.cmn.data.AppointmentParticipant
-- --------------------------------------------------------
create table cmn_appointment_participants
(
    ref_appointment int           not null,    -- References: cmn_appointments.id
    ref_user        int           not null,    -- References: cmn_users.id
    state           int           not null,    -- See: com.interact.sas.cmn.data.AppointmentParticipant.STATE
    info            text          not null
);
create index cmn_appoin_part_appointment on cmn_appointment_participants( ref_appointment );
create index cmn_appoin_part_user        on cmn_appointment_participants( ref_user );

-- -------------------------------------------------------------------------------------
-- CMN_SPOTLIGHT_TOPICS
--
-- Stores: com.interact.sas.cmn.data.SpotlightTopic
-- -------------------------------------------------------------------------------------
create table cmn_spotlight_topics
(
    id              int             not null,
    language        char(2)         not null,
    ts_published    timestamp       not null,
    topic           varchar(80)     not null,
    title           varchar(80)     not null,
    author          varchar(80)     not null,
    contact         varchar(80)     not null,
    item            varchar(80),
    banner          varchar(160),
    category        varchar(160),
    uuid            varchar(250)    not null,
    info            text            not null,
  
    primary key ( id ),
    unique ( topic ),
    unique ( uuid )
);

-- -------------------------------------------------------------------------------------
-- CMN_SPOTLIGHT_READERS
--
-- Stores: com.interact.sas.cmn.data.SpotlightReader
-- -------------------------------------------------------------------------------------
create table cmn_spotlight_readers
(
    id              int             not null,
    ref_topic       int             not null,    -- References: cmn_spotlight_topics.id
    ref_user        int             not null,    -- References: cmn_users.id
    stars           tinyint,
    bookmark        tinyint,
    ts_read         datetime,
    feedback        text,
    
    primary key ( id ),
    unique ( ref_topic, ref_user )
);
create index cmn_spot_readers_topic on cmn_spotlight_readers( ref_topic );
create index cmn_spot_readers_user  on cmn_spotlight_readers( ref_user );

-- --------------------------------------------------------
-- CMN_APPLICATIONS
--
-- Stores: com.interact.sas.cmn.data.FavouriteApplication
-- --------------------------------------------------------
create table cmn_applications
(
    ref_owner      int          not null,    -- References: cmn_users.id
    position       int          not null, 
    application    varchar(100) not null,

    unique ( application, ref_owner )
);

-- --------------------------------------------------------
-- CMN_DIGITAL_SIGNATURES
--
-- Stores: com.interact.sas.cmn.data.DigitalSignature
-- --------------------------------------------------------
create table cmn_digital_signatures
(
    id           int            not null,
    ref_file     int            not null,    -- References: vfs_files.id
    ref_user     int            not null,
    "size"       int            not null,
    family       int            not null,
    dt_signature datetime,
    name         varchar( 255 ) not null,
    uuid         varchar( 255 ) not null,
    signature    text,
    stamps       text,

    primary key( id )
);
create index cmn_digital_signatures_file on cmn_digital_signatures ( ref_file );
create index cmn_digital_signatures_user on cmn_digital_signatures ( ref_user );
create index cmn_digital_signatures_date on cmn_digital_signatures ( dt_signature );
create index cmn_digital_signatures_name on cmn_digital_signatures ( name );
create index cmn_digital_signatures_uuid on cmn_digital_signatures ( uuid );

-- --------------------------------------------------------
-- CMN_TEMPFILES
--
-- Stores: com.interact.sas.cmn.data.TempFile
-- --------------------------------------------------------
create table cmn_tempfiles
(
    ts   timestamp not null default current_timestamp,
    path text      not null
);
create index cmn_tempfiles_ts on cmn_tempfiles ( ts );

-- --------------------------------------------------------
-- CMN_USER_PROPERTIES
--
-- Stores: com.interact.sas.web.zk.cmn.data.UserProperty
-- --------------------------------------------------------
create table cmn_user_properties
(
    ref_user   int          not null, -- References: cmn_users.id
    name       varchar(255) not null,
    content    text         not null,
    ts_created timestamp    not null,
    
    unique (name,ref_user)
);
create index cmn_user_properties_user on cmn_user_properties( ref_user );

-- --------------------------------------------------------
-- CMN_FEEDS
--
-- Stores: com.interact.sas.cmn.data.Feed
-- --------------------------------------------------------
create table cmn_feeds
(
    id          int          not null,
    ref_owner   int          not null,
    family      varchar(80)  not null,
    protocol    varchar(250) not null,
    subcaption  varchar(50)  not null,
    ts_executed datetime     not null,

    primary key (id)
);
create index cmn_feeds_family on cmn_feeds( family );
create index cmn_feeds_owner  on cmn_feeds( ref_owner );

-- --------------------------------------------------------
-- CMN_FEED_FIELDS
--
-- Stores: com.interact.sas.cmn.data.FeedField
-- --------------------------------------------------------
create table cmn_feed_fields
(
    ref_feed int         not null,
    sequence smallint    not null,
    label    varchar(80) not null,
    value    varchar(80) not null,

    unique (ref_feed, label)
);
create index cmn_feed_fields_feed on cmn_feed_fields( ref_feed );

-- --------------------------------------------------------
-- CMN_LOGBOOKS
--
-- Stores: com.interact.sas.cmn.data.Logbook
-- --------------------------------------------------------
create table cmn_logbooks
(     
    id                    int             not null,
    ref_author            int             not null,    -- References: cmn_users.id
    ref_user              int             not null,    -- References: cmn_users.id
    ref_classification    int             not null,    -- References: cmn_classifications.id
    restriction           int             not null,
    type                  smallint        not null,
    dt_start              date            not null,
    dt_end                date            not null,
    info                  text            not null,

    primary key ( id )
);
create index cmn_logbook_author on cmn_logbooks ( ref_author );
create index cmn_logbook_user   on cmn_logbooks ( ref_user );
create index cmn_logbook_class  on cmn_logbooks ( ref_classification );

-- --------------------------------------------------------
-- CMN_TIPS
--
-- Stores: com.interact.sas.cmn.data.Tip
-- --------------------------------------------------------
create table cmn_tips
(
    name varchar(80) not null,
    ref_user int not null
);
create index cmn_tips_user on cmn_tips( ref_user );