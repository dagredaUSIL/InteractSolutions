-- -----------------------------------------------------------------------------
--
-- Module:   ORM
--
-- Schema:   80.1
--
-- Revision: $Revision: 100691 $
--
-- Date:     $Date: 2011-12-21 14:04:37 -0200 (Qua, 21 Dez 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-orm.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- ORM_BUSINESS_UNITS
--
-- Stores: com.interact.sas.orm.data.BusinessUnit
-- --------------------------------------------------------
create table orm_business_units
(
    id             int            not null,
    ref_owner      int            not null,    -- References: cmn_users.id
    ref_team       int            not null,    -- References: cmn_groups.id
    ref_risk_rule  int            not null,    -- References: brm_methods.id
    ref_category   int            not null,    -- References: orm_structure_categories.id
    ref_model      int            not null,    -- References: bsc_models.id
    ref_riskmap    int            null,        -- References: orm_riskmaps.id
    restriction    int            not null,
    state          tinyint        not null,
    category       varchar(80)    not null,
    location       varchar(80)    not null,
    mnemonic       varchar(80)    default null,
    rule_params    varchar (80),
    name           varchar(160)   not null,
    options        varchar(250)   not null,
    info           text           not null,

    primary key ( id )
);
create index orm_business_units_team      on orm_business_units( ref_team );
create index orm_business_units_risk_rule on orm_business_units( ref_risk_rule );
create index orm_business_units_category  on orm_business_units( ref_category );
create index orm_business_units_model     on orm_business_units( ref_model );
create index orm_business_units_riskmap   on orm_business_units( ref_riskmap );

-- --------------------------------------------------------
-- ORM_RISKS
--
-- Stores: com.interact.sas.orm.data.OperationalRisk
-- --------------------------------------------------------
create table orm_risks
(
    id             int            not null,
    ref_tags       int            not null,    -- References: cmn_tag_kinds.id
    icon           int            not null,
    state          tinyint        not null,
    code           varchar(20)    not null,
    name           varchar(160)   not null,
    info           text           not null,

    primary key ( id )
);
create index orm_risks_code        on orm_risks( code );
create index orm_risks_tags        on orm_risks( ref_tags );

-- --------------------------------------------------------
-- ORM_RISKFACTORS
--
-- Stores: com.interact.sas.orm.data.RiskFactor
-- --------------------------------------------------------
create table orm_riskfactors
(
    id             int            not null,
    state          tinyint        not null,
    code           varchar(20)    not null,
    name           varchar(160)   not null,
    info           text           not null,

    primary key ( id )
);
create index orm_riskfactors_code on orm_riskfactors( code );

-- --------------------------------------------------------
-- ORM_CONTROLS
--
-- Stores: com.interact.sas.orm.data.ControlTechnique
-- --------------------------------------------------------
create table orm_controls
(
    id               int            not null,
    state            tinyint        not null,
    code             varchar(20)    not null,
    name             varchar(160)   not null,
    description      text           not null,
    instructions     text           not null,
    mnemonic         varchar(40)    not null,
    classification   varchar(80)    not null,
    frequency        varchar(80)    not null,

    primary key ( id )
);
create index orm_controls_code        on orm_controls( code );

-- --------------------------------------------------------
-- ORM_CONTROL_ITEMS
--
-- Stores: com.interact.sas.orm.data.ControlTechniqueItem
-- --------------------------------------------------------
create table orm_control_items
(
    id             int             not null,
    ref_process    int             not null,    -- References: orm_processes.id
    ref_control    int             not null,    -- References: orm_controls.id
    seqnum         smallint        not null,
    name           varchar(160)    not null,
    info           text            not null,

    primary key ( id )
);
create index orm_control_items_process  on orm_control_items( ref_process );
create index orm_control_items_control  on orm_control_items( ref_control );

-- --------------------------------------------------------
-- ORM_CYCLES
--
-- Stores: com.interact.sas.orm.data.Cycle
-- --------------------------------------------------------
create table orm_cycles
(
    id             int            not null,
    ref_owner      int            not null,    -- References: cmn_users.id
    state          int            not null,    -- See: com.interact.sas.orm.data.Cycle.STATES
    dt_from        date           default null,
    dt_until       date           default null,
    name           varchar(160)   not null,
    info           text           not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- ORM_AUDITS
--
-- Stores: com.interact.sas.orm.data.AuditPlan
-- --------------------------------------------------------
create table orm_audits
(
    id                   int             not null,
    ref_cycle            int             not null,    -- References: orm_cycles.id
    ref_owner            int             not null,    -- References: cmn_users.id
    ref_team             int             not null,    -- References: cmn_groups.id
    ref_actionplan       int             not null,    -- References: bsc_actionplans.id
    fl_verify_aspects    tinyint         not null,
    state                smallint        not null,    -- See: com.interact.sas.orm.data.AuditPlan.STATES 
    dt_from              date            default null,
    dt_until             date            default null,
    dt_execute           date            default null,
    dt_finished          date            default null,
    name                 varchar(160)    not null,
    info                 text            not null,

    primary key ( id )
);
create index orm_audits_cycle       on orm_audits( ref_cycle );
create index orm_audits_owner       on orm_audits( ref_owner );
create index orm_audits_actionplan  on orm_audits( ref_actionplan );

-- --------------------------------------------------------
-- ORM_CONTROL_RESULTS
--
-- Stores: com.interact.sas.orm.data.ControlTechniqueResult
-- --------------------------------------------------------
create table orm_control_results
(
    id              int            not null,
    rev             int            not null,
    ref_audit       int            not null,    -- References: orm_audits.id
    ref_process     int            not null,    -- References: orm_processes.id
    ref_control     int            not null,    -- References: orm_controls.id
    ref_owner       int            not null,    -- References: cmn_users.id
    dt_registered   date,
    state           int            not null,    -- See: com.interact.sas.orm.data.ControlTechniqueResult.STATES
    score           double         not null,
    justification   text,

    unique key ( id, rev )
);
create index orm_control_results_audit   on orm_control_results( ref_audit );
create index orm_control_results_process on orm_control_results( ref_process );
create index orm_control_results_control on orm_control_results( ref_control );
create index orm_control_results_owner   on orm_control_results( ref_owner);

-- --------------------------------------------------------
-- ORM_RESULTS
--
-- Stores: com.interact.sas.orm.data.RiskResult
-- --------------------------------------------------------
create table orm_results
(
    rev                 int            not null,
    ref_audit           int            not null,    -- References: orm_audits.id
    ref_process         int            not null,    -- References: orm_processes.id
    ref_control         int            not null,    -- References: orm_controls.id
    ref_probability     int            not null,    -- References: orm_probabilities.id
    ref_option          int            not null,    -- References: orm_probability_options.id
    ref_control_results int            not null,    -- References: orm_control_results.id
    competence          int            not null,
    state               smallint       not null,
    impact              double         not null,
    probability         double         not null,
    score               double         not null
);
create index orm_results_competence      on orm_results( competence );
create index orm_results_audit           on orm_results( ref_audit );
create index orm_results_process         on orm_results( ref_process );
create index orm_results_control         on orm_results( ref_control );
create index orm_results_control_results on orm_results (ref_control_results);

-- --------------------------------------------------------
-- ORM_ASPECTS
--
-- Stores: com.interact.sas.orm.data.AuditAspect
-- --------------------------------------------------------
create table orm_aspects
(
    id              int            not null,
    ref_cycle       int            not null,    -- References: orm_cycles.id
    ref_audit       int            not null,    -- References: orm_audits.id
    ref_process     int            not null,    -- References: orm_processes.id
    ref_control     int            not null,    -- References: orm_controls.id
    ref_item        int            not null,    -- References: orm_control_items.id
    ref_owner       int            not null,    -- References: cmn_users.id
    state           tinyint        not null,    -- See: com.interact.sas.orm.data.AuditAspect.STATE
    dt_registered   date           default null,
    name            varchar(160)   not null,
    info            text           not null,

    primary key ( id )
);
create index orm_aspects_cycle    on orm_aspects( ref_cycle );
create index orm_aspects_audit    on orm_aspects( ref_audit );
create index orm_aspects_process  on orm_aspects( ref_process );
create index orm_aspects_control  on orm_aspects( ref_control );
create index orm_aspects_owner    on orm_aspects( ref_owner );

-- --------------------------------------------------------
-- ORM_MAPPINGS
--
-- Stores: com.interact.sas.orm.data.Mapping
-- --------------------------------------------------------
create table orm_mappings
(
    r1               int              not null,
    r2               int              not null,
    r3               int              not null,
    r4               int              not null,
    family           smallint         not null,    -- See: com.interact.sas.orm.data.Mapping.FAMILY
    c0               double           not null,

    unique ( family, r1, r2, r3, r4 )
);
create index orm_mappings_r1 on orm_mappings ( r1 );
create index orm_mappings_r2 on orm_mappings ( r2 );
create index orm_mappings_r3 on orm_mappings ( r3 );
create index orm_mappings_r4 on orm_mappings ( r4 );

-- --------------------------------------------------------
-- ORM_ASPECT_REVISION
--
-- Stores: com.interact.sas.orm.data.AuditAspectRevision
-- --------------------------------------------------------
create table orm_aspect_revision
(
    id             int       not null,
    ref_aspect     int       not null,    -- References: orm_aspects.id
    ref_owner      int       not null,    -- References: cmn_users.id
    dt_registered  date      not null,
    info           text      not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- ORM_RISC_IMPACT_REVISION
--
-- Stores: com.interact.sas.orm.data.RiskImpactRevision
-- --------------------------------------------------------
create table orm_risk_impact_revision
( 
    id               int            not null,
    rev              int            not null,
    ref_audit        int            not null,    -- References: orm_audits.id
    ref_process      int            not null,    -- References: orm_processes.id
    ref_risk         int            not null,    -- References: orm_risks.id
    ref_owner        int            not null,    -- References: cmn_users.id
    workflow         int            not null,
    dt_registered    datetime       not null,
    last_impact      double         not null,
    impact           double         not null,
    info             text           not null,

    unique key ( id, rev )
);
create index orm_risk_imp_rev_ref_aud on orm_risk_impact_revision( ref_audit );
create index orm_risk_imp_rev_ref_pro on orm_risk_impact_revision( ref_process );
create index orm_risk_imp_rev_ref_ris on orm_risk_impact_revision( ref_risk );

-- ----------------------------------------------------------
-- ORM_RISC_PROBABILITY_REVISION
--
-- Stores: com.interact.sas.orm.data.RiskProbabilityRevision
-- ----------------------------------------------------------
create table orm_risk_probability_revision
(
    id               int            not null,
    rev              int            not null,
    ref_audit        int            not null,    -- References: orm_audits.id
    ref_process      int            not null,    -- References: orm_processes.id
    ref_risk         int            not null,    -- References: orm_risks.id
    ref_owner        int            not null,    -- References: cmn_users.id
    workflow         int            not null,
    probability      double         not null,
    dt_registered    datetime       not null,
    info             text           not null,

    unique key ( id, rev )
);
create index orm_risk_pr_rev_ref_aud on orm_risk_probability_revision( ref_audit );
create index orm_risk_pr_rev_ref_pro on orm_risk_probability_revision( ref_process );
create index orm_risk_pr_rev_ref_ris on orm_risk_probability_revision( ref_risk );

-- ----------------------------------------------------------
-- ORM_AUDIT_CONTROLS
--
-- Stores: com.interact.sas.orm.data.ControlTechnique
-- ----------------------------------------------------------
create table orm_audit_controls
(
    ref_audit      int    not null,    -- References: orm_audits.id
    ref_control    int    not null,    -- References: orm_controls.id

    unique ( ref_audit, ref_control )
);

-- ----------------------------------------------------------
-- ORM_CATEGORIES
--
-- Stores: com.interact.sas.orm.data.ImpactCategory
-- ----------------------------------------------------------
create table orm_categories
(
    id          int             not null,
    ref_riskmap int             null,       -- References: orm_riskmaps.id
    "level"     int             not null,
    name        varchar(160)    not null,
    info        text            not null,

    primary key ( id )
);
create index orm_categories_riskmap on orm_categories( ref_riskmap );

-- ----------------------------------------------------------
-- ORM_IMPACT_LEVELS
--
-- Stores: com.interact.sas.orm.data.ImpactLevel
-- ----------------------------------------------------------
create table orm_impact_levels
(
    id                 int             not null,
    ref_riskmap        int             null,       -- References: orm_riskmaps.id
    name               varchar(160)    not null,
    "level"            smallint        not null,
    info               text            not null,

    primary key ( id )
);
create index orm_impact_levels_riskmap on orm_impact_levels( ref_riskmap );

-- ----------------------------------------------------------
-- ORM_IMPACT_OPTIONS
--
-- Stores: com.interact.sas.orm.data.ImpactOption
-- ----------------------------------------------------------
create table orm_impact_options
(
    id                 int            not null,
    ref_impact         int            not null,    -- References: orm_impact_classifications.id
    ref_level          int            not null,    -- References: orm_impact_levels.id
    info               text           not null,

    primary key ( id )
);

create index orm_impact_options_impact on orm_impact_options ( ref_impact );
create index orm_impact_options_level  on orm_impact_options ( ref_level );

-- ----------------------------------------------------------
-- ORM_PROBABILITIES
--
-- Stores: com.interact.sas.orm.data.ProbabilityCategory
-- ----------------------------------------------------------
create table orm_probabilities
(
    id                 int            not null,
    score              double         not null,
    state              smallint       not null,
    name               varchar(160)   not null,
    info               text           not null,

    primary key ( id )
);

-- ----------------------------------------------------------
-- ORM_PROBABILITY_OPTIONS
--
-- Stores: com.interact.sas.orm.data.ProbabilityOption
-- ----------------------------------------------------------
create table orm_probability_options
(
    id                 int             not null,
    ref_probability    int             not null,    -- References: orm_probabilities.id
    position           smallint        not null,
    state              smallint        not null,
    score              double          not null,
    name               varchar(160)    not null,
    info               text            not null,


    primary key ( id )
);
create index orm_probability_options_prob on orm_probability_options( ref_probability );

-- ----------------------------------------------------------
-- ORM_PROBABILITY_RANGES
--
-- Stores: com.interact.sas.orm.data.ProbabilityRange
-- ----------------------------------------------------------
create table orm_probability_ranges
(
    id                 int             not null,
    ref_riskmap        int             null,        -- References: orm_riskmaps.id
    color              int             not null,
    "level"            smallint        not null,
    score_from         double          not null,
    score_until        double          not null,
    name               varchar(160)    not null,

    primary key ( id )
);
create index orm_probability_ranges_riskmap on orm_probability_ranges( ref_riskmap );

-- ----------------------------------------------------------
-- ORM_RISK_COLORS
--
-- Stores: com.interact.sas.orm.data.RiskColor
-- ----------------------------------------------------------
create table orm_risk_colors
(
    id                 int            not null,
    ref_riskmap        int            null,       -- References: orm_riskmaps.id
    probability_level  int            not null,
    impact_level       int            not null,
    colors             int            not null,

    primary key ( id )
);
create index orm_risk_colors_riskmap on orm_risk_colors( ref_riskmap );

-- ----------------------------------------------------------
-- ORM_RISK_RESULTS
--
-- Stores: com.interact.sas.orm.data.RiskResult
-- ----------------------------------------------------------
create table orm_risk_results
(
    rev                      int            not null,
    ref_audit                int            not null,    -- References: orm_audits.id
    ref_process              int            not null,    -- References: orm_processes.id
    ref_risk                 int            not null,    -- References: orm_risks.id
    ref_owner                int            not null,    -- References: cmn_users.id
    impact                   double         not null,
    probability              double         not null,

    unique ( ref_audit, ref_process, ref_risk, rev )
);
create index orm_risk_results_audit on orm_risk_results ( ref_audit );
create index orm_risk_results_process on orm_risk_results ( ref_process );
create index orm_risk_results_risk on orm_risk_results ( ref_risk );

-- ----------------------------------------------------------
-- ORM_IMPACT_CLASSIFICATIONS
--
-- Stores: com.interact.sas.orm.data.ImpactClassification
-- ----------------------------------------------------------
create table orm_impact_classifications
(
    id                  int             not null,
    ref_audit           int             not null,    -- References: orm_audits.id
    ref_process         int             not null,    -- References: orm_processes.id
    ref_risk            int             not null,    -- References: orm_risks.id
    ref_impact_level    int             not null,    -- References: orm_impact_levels.id
    ref_category        int             not null,    -- References: orm_categories.id
    ref_revision        int             not null,    -- References: orm_risk_impact_revision.id
    rev                 int             not null,
    impact              double          not null,
    loss                double          not null,
    weight              double          not null,
    title               varchar(160)    not null,
    info                text            not null,

    unique ( id, rev )
);
create index orm_impact_class_audit    on orm_impact_classifications ( ref_audit );
create index orm_impact_class_process  on orm_impact_classifications ( ref_process );
create index orm_impact_class_risk     on orm_impact_classifications ( ref_risk );
create index orm_impact_class_impact   on orm_impact_classifications ( ref_impact_level );
create index orm_impact_class_category on orm_impact_classifications ( ref_category );
create index orm_impact_class_revision on orm_impact_classifications ( ref_revision );

-- ----------------------------------------------------------
-- ORM_RISK_INSTANCES
--
-- Stores: com.interact.sas.orm.data.OperationalRiskInstance
-- ----------------------------------------------------------
create table orm_risk_instances
(
    id                  int          not null,
    ref_owner           int          not null,    -- References: cmn_users.id
    ref_team            int          null,        -- References: cmn_groups.id
    ref_checklist       int          null,        -- References: aud_checklists.id
    ref_original        int          null,
    ref_checklist_state int          null,
    mit_owner           int          null,
    ver_owner           int          null,
    ver_period          tinyint      null,
    mit_period          tinyint      null,
    dt_last_mit         datetime     null,
    dt_next_mit         datetime     null,
    dt_last_ver         datetime     null,
    dt_next_ver         datetime     null,
    mit_other           varchar(250) null,
    ver_other           varchar(250) null,
    mit_info            text         null,
    ver_info            text         null,
    info                text         null,
        
    primary key (id)
);
create index orm_risk_instances_owner     on orm_risk_instances(ref_owner);
create index orm_risk_instances_team      on orm_risk_instances(ref_team);
create index orm_risk_instances_checklist on orm_risk_instances(ref_checklist);
create index orm_risk_instances_original  on orm_risk_instances(ref_original);

-- --------------------------------------------------------
-- ORM_ALERTS
--
-- Stores: com.interact.sas.orm.data.RiskAlert
-- --------------------------------------------------------
create table orm_alerts
(
    id                int       not null,
    ref_risk_instance int       not null,    -- References: orm_risk_instances.id
    treatment         smallint  not null,
    dt_next_alert     date      null,
    dt_created        timestamp not null,
    info              text      not null,

    primary key( id )
);
create index orm_alerts_risk_instance on orm_alerts( ref_risk_instance );

-- --------------------------------------------------------
-- ORM_STRUCTURE_CATEGORIES
--
-- Stores: com.interact.sas.orm.data.StructureCategory
-- --------------------------------------------------------
create table orm_structure_categories
(
    id                 int          not null,
    rev                int          not null,
    ref_owner          int          not null,    -- References: cmn_users.id
    ref_parent         int          not null,    -- References: orm_structure_categories.id
    ref_team           int          not null,    -- References: cmn_groups.id
    ref_unit           int          not null,    -- References: cmn_units.id
    ref_process_model  int          not null,    -- References: bpm_process.id.id
    restriction        int          not null,
    process_model_type tinyint      not null,
    icon               tinyint      not null,
    state              tinyint      not null,
    dt_registered      date         null,
    classification     varchar(32)  not null,
    code               varchar(40)  not null,
    mnemonic           varchar(40)  not null,
    type               varchar(80)  not null,
    name               varchar(160) not null,
    info               text         not null,

    primary key ( id, rev )
);
create index orm_structure_categories_owner on orm_structure_categories( ref_owner );
create index orm_structure_cat_team         on orm_structure_categories( ref_team );
create index orm_structure_cat_type         on orm_structure_categories( type );
create index orm_structure_cat_restriction  on orm_structure_categories( restriction );
create index orm_structure_cat_mnemonic     on orm_structure_categories( mnemonic );
create index orm_structure_cat_proc_model   on orm_structure_categories( ref_process_model );
create index orm_structure_cat_parent       on orm_structure_categories( ref_parent );

-- --------------------------------------------------------
-- ORM_SC_CONTROLS
--
-- Stores: com.interact.sas.orm.data.mappings.StructureCategoryToControl
-- --------------------------------------------------------
create table orm_sc_controls
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_control           int      not null, -- References: orm_controls.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_sc_controls_id      on orm_sc_controls( id ); 
create index orm_sc_controls_sc      on orm_sc_controls( ref_sc ); 
create index orm_sc_controls_control on orm_sc_controls( ref_control ); 
create index orm_sc_controls_rev     on orm_sc_controls( rev ); 

-- --------------------------------------------------------
-- ORM_SC_RISKS
--
-- Stores: com.interact.sas.orm.data.mappings.StructureCategoryToRisk
-- --------------------------------------------------------
create table orm_sc_risks
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_risk              int      not null, -- References: orm_risks.id
    ref_risk_instance     int      not null, -- References: orm_risk_instances.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_sc_risks_id            on orm_sc_risks( id ); 
create index orm_sc_risks_sc            on orm_sc_risks( ref_sc ); 
create index orm_sc_risks_risk          on orm_sc_risks( ref_risk ); 
create index orm_sc_risks_risk_instance on orm_sc_risks( ref_risk_instance ); 
create index orm_sc_risks_rev           on orm_sc_risks( rev ); 

-- --------------------------------------------------------
-- ORM_RISKS_CONTROLS
--
-- Stores: com.interact.sas.orm.data.mappings.RiskToControl
-- --------------------------------------------------------
create table orm_risks_controls
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_risk              int      not null, -- References: orm_risks.id
    ref_control           int      not null, -- References: orm_controls.id
    rev                   int      not null,
    weight                double   not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_risks_controls_id      on orm_risks_controls( id ); 
create index orm_risks_controls_sc      on orm_risks_controls( ref_sc ); 
create index orm_risks_controls_risk    on orm_risks_controls( ref_risk ); 
create index orm_risks_controls_control on orm_risks_controls( ref_control ); 
create index orm_risks_controls_rev     on orm_risks_controls( rev ); 

-- --------------------------------------------------------
-- ORM_SC_FACTORS
--
-- Stores: com.interact.sas.orm.data.mappings.StructureCategoryToFactor
-- --------------------------------------------------------
create table orm_sc_factors
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_risk              int      not null, -- References: orm_risks.id
    ref_factor            int      not null, -- References: orm_riskfactors.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_sc_factors_id     on orm_sc_factors( id ); 
create index orm_sc_factors_sc     on orm_sc_factors( ref_sc ); 
create index orm_sc_factors_risk   on orm_sc_factors( ref_risk ); 
create index orm_sc_factors_factor on orm_sc_factors( ref_factor ); 
create index orm_sc_factors_rev    on orm_sc_factors( rev ); 

-- --------------------------------------------------------
-- ORM_RISKFACTORS_CONTROLS
--
-- Stores: com.interact.sas.orm.data.mappings.RiskFactorToControl
-- --------------------------------------------------------
create table orm_riskfactors_controls
(
    id                    int       not null,
    ref_sc                int       not null, -- References: orm_structure_categories.id
    ref_factor            int       not null, -- References: orm_riskfactors.id
    ref_control           int       not null, -- References: orm_controls.id
    ref_risk              int       not null, -- References: orm_risks.id
    rev                   int       not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_riskfactors_contr_id      on orm_riskfactors_controls( id ); 
create index orm_riskfactors_contr_sc      on orm_riskfactors_controls( ref_sc ); 
create index orm_riskfactors_contr_factor  on orm_riskfactors_controls( ref_factor ); 
create index orm_riskfactors_contr_control on orm_riskfactors_controls( ref_control ); 
create index orm_riskfactors_contr_risk    on orm_riskfactors_controls( ref_risk ); 
create index orm_riskfactors_contr_rev     on orm_riskfactors_controls( rev ); 

-- --------------------------------------------------------
-- ORM_SC_QUANTIFICATIONS
--
-- Stores: com.interact.sas.orm.data.mappings.StructureCategoryToQuantification
-- --------------------------------------------------------
create table orm_sc_quantifications
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_risk              int      not null, -- References: orm_risks.id
    ref_filter            int      not null, -- References: qms_filters.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_sc_quantifications_id     on orm_sc_quantifications( id ); 
create index orm_sc_quantifications_sc     on orm_sc_quantifications( ref_sc ); 
create index orm_sc_quantifications_risk   on orm_sc_quantifications( ref_risk ); 
create index orm_sc_quantifications_filter on orm_sc_quantifications( ref_filter ); 
create index orm_sc_quantifications_rev    on orm_sc_quantifications( rev ); 

-- --------------------------------------------------------
-- ORM_RISKS_ACTIONPLANS
--
-- Stores: com.interact.sas.orm.data.mappings.RiskToActionplan
-- --------------------------------------------------------
create table orm_risks_actionplans
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_risk              int      not null, -- References: orm_risks.id
    ref_actionplan        int      not null, -- References: bsc_actionplans.id 
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_risks_actionplans_id      on orm_risks_actionplans( id ); 
create index orm_risks_actionplans_sc      on orm_risks_actionplans( ref_sc ); 
create index orm_risks_actionplans_risk    on orm_risks_actionplans( ref_risk ); 
create index orm_risks_actionplans_actionp on orm_risks_actionplans( ref_actionplan );
create index orm_risks_actionplans_rev     on orm_risks_actionplans( rev ); 

-- --------------------------------------------------------
-- ORM_CONTROLS_CONTEXTS
--
-- Stores: com.interact.sas.orm.data.mappings.ControlTechniqueToContext
-- --------------------------------------------------------
create table orm_controls_contexts
(
    id                    int      not null,
    ref_control           int      not null, -- References: orm_controls.id
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_context           int      not null, -- References: cmn_context.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_controls_contexts_id      on orm_controls_contexts( id ); 
create index orm_controls_contexts_control on orm_controls_contexts( ref_control ); 
create index orm_controls_contexts_sc      on orm_controls_contexts( ref_sc ); 
create index orm_controls_contexts_context on orm_controls_contexts( ref_context ); 
create index orm_controls_contexts_rev     on orm_controls_contexts( rev ); 

-- --------------------------------------------------------
-- ORM_AUDITS_CONTROLS
--
-- Stores: com.interact.sas.orm.data.mappings.AuditToControl
-- --------------------------------------------------------
create table orm_audits_controls
(
    id                    int      not null,
    ref_audit             int      not null, -- References: orm_audits.id
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_control           int      not null, -- References: orm_controls.id
    ref_risk              int      not null, -- References: orm_risks.id
    rev                   int      not null,
    weight                double   not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_audits_controls_id      on orm_audits_controls( id ); 
create index orm_audits_controls_audit   on orm_audits_controls( ref_audit ); 
create index orm_audits_controls_sc      on orm_audits_controls( ref_sc ); 
create index orm_audits_controls_control on orm_audits_controls( ref_control ); 
create index orm_audits_controls_risk    on orm_audits_controls( ref_risk ); 
create index orm_audits_controls_rev     on orm_audits_controls( rev ); 

-- --------------------------------------------------------
-- ORM_AUDITS_CONTEXTS
--
-- Stores: com.interact.sas.orm.data.mappings.AuditToContext
-- --------------------------------------------------------
create table orm_audits_contexts
(
    id                    int      not null,
    ref_audit             int      not null, -- References: orm_audits.id
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_control           int      not null, -- References: orm_controls.id
    ref_context           int      not null, -- References: cmn_context.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_audits_contexts_id      on orm_audits_contexts( id ); 
create index orm_audits_contexts_audit   on orm_audits_contexts( ref_audit ); 
create index orm_audits_contexts_sc      on orm_audits_contexts( ref_sc ); 
create index orm_audits_contexts_control on orm_audits_contexts( ref_control ); 
create index orm_audits_contexts_context on orm_audits_contexts( ref_context ); 
create index orm_audits_contexts_rev     on orm_audits_contexts( rev ); 

-- --------------------------------------------------------
-- ORM_ASPECTS_INITIATIVES
--
-- Stores: com.interact.sas.orm.data.mappings.AspectToInitiative
-- --------------------------------------------------------
create table orm_aspects_initiatives
(
    id                    int      not null,
    ref_aspect            int      not null, -- References: orm_aspects.id
    ref_initiative        int      not null, -- References: bsc_initiatives.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_aspects_initiatives_id      on orm_aspects_initiatives( id ); 
create index orm_aspects_initiatives_aspect  on orm_aspects_initiatives( ref_aspect );

-- --------------------------------------------------------
-- ORM_INITIATIVES_DIRECTORS
--
-- Stores: com.interact.sas.orm.data.mappings.InitiativeToDirector
-- --------------------------------------------------------
create table orm_initiatives_directors
(
    id                    int      not null,
    ref_initiative        int      not null, -- References: bsc_initiatives.id
    ref_user              int      not null, -- References: cmn_users.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_initiatives_directors_id   on orm_initiatives_directors( id ); 
create index orm_initiatives_directors_init on orm_initiatives_directors( ref_initiative ); 
create index orm_initiatives_directors_user on orm_initiatives_directors( ref_user ); 
create index orm_initiatives_directors_rev  on orm_initiatives_directors( rev ); 

-- --------------------------------------------------------
-- ORM_AUDITS_FACTORS
--
-- Stores: com.interact.sas.orm.data.mappings.AuditToFactor
-- --------------------------------------------------------
create table orm_audits_factors
(
    id                    int      not null,
    ref_auditplan         int      not null, -- References: orm_audits.id
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_factor            int      not null, -- References: orm_riskfactors.id
    ref_risk              int      not null, -- References: orm_risks.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_audits_factors_id        on orm_audits_factors( id ); 
create index orm_audits_factors_auditplan on orm_audits_factors( ref_auditplan ); 
create index orm_audits_factors_sc        on orm_audits_factors( ref_sc );
create index orm_audits_factors_factor    on orm_audits_factors( ref_factor ); 
create index orm_audits_factors_risk      on orm_audits_factors( ref_risk ); 
create index orm_audits_factors_rev       on orm_audits_factors( rev ); 

-- --------------------------------------------------------
-- ORM_CONTROLS_ANNOTATIONS
--
-- Stores: com.interact.sas.orm.data.mappings.ControlTechniqueToAnnotation
-- --------------------------------------------------------
create table orm_controls_annotations
(
    id                    int      not null,
    ref_sc                int      not null, -- References: orm_structure_categories.id
    ref_control           int      not null, -- References: orm_controls.id
    ref_annotation        int      not null, -- References: cmn_annotations.id
    rev                   int      not null,
    dt_registered         datetime,

    unique key ( id, rev )
);
create index orm_controls_annot_id         on orm_controls_annotations( id ); 
create index orm_controls_annot_sc         on orm_controls_annotations( ref_sc ); 
create index orm_controls_annot_control    on orm_controls_annotations( ref_control ); 
create index orm_controls_annot_annotation on orm_controls_annotations( ref_annotation ); 
create index orm_controls_annot_rev        on orm_controls_annotations( rev ); 

-- --------------------------------------------------------
-- ORM_BASELINES
--
-- Stores: com.interact.sas.orm.data.Baseline
-- --------------------------------------------------------
create table orm_baselines
(
    id            int          not null,
    rev           int          not null, 
    ref_unit      int          not null,    -- References: orm_business_units.id
    ref_owner     int          not null,    -- References: cmn_users.id
    dt_registered datetime     not null,
    name          varchar(160) not null,
    justification text,

    unique key( id, rev )
);
create index orm_baselines_id     on orm_baselines( id ); 
create index orm_baselines_unit   on orm_baselines( ref_unit ); 
create index orm_baselines_owner  on orm_baselines( ref_owner ); 
create index orm_baselines_rev    on orm_baselines( rev ); 

-- --------------------------------------------------------
-- ORM_RISKMAPS
--
-- Stores: com.interact.sas.orm.data.RiskMap
-- --------------------------------------------------------
create table orm_riskmaps
(
    id        int          not null,
    ref_owner int          not null,    -- References: cmn_users.id
    ref_team  int,                      -- References: cmn_teams.id
    name      varchar(160) not null,
    state     tinyint not  null,
    info      text,
    
    primary key( id )
);
create index orm_riskmaps_owner on orm_riskmaps( ref_owner );
create index orm_riskmaps_team  on orm_riskmaps( ref_team );

-- --------------------------------------------------------
-- ORM_CONTROLS_ACTIONPLANS
--
-- Stores: com.interact.sas.orm.data.ControlToActionplan
-- --------------------------------------------------------
create table orm_controls_actionplans
(
    id             int      not null,
    ref_sc         int      not null,    -- References: orm_structure_categories.id
    ref_risk       int      not null,    -- References: orm_risks.id
    ref_control    int      not null,    -- References: orm_risks_controls.id
    ref_actionplan int      not null,    -- References: bsc_actionplans.id
    rev            int      not null,
    dt_registered  datetime,

    unique ( id, rev )
);
create index orm_controls_actionplans_sc    on orm_controls_actionplans( ref_sc );
create index orm_controls_actionplans_risk  on orm_controls_actionplans( ref_risk );
create index orm_controls_actionplans_contr on orm_controls_actionplans( ref_control );
create index orm_controls_actionplans_actpl on orm_controls_actionplans( ref_actionplan );