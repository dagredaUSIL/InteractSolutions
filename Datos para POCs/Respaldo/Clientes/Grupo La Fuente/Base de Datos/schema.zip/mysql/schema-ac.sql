-- --------------------------------------------------------
--
-- Module:   AC
--
-- Schema:   80.1
--
-- Revision: $Revision: 100701 $
--
-- Date:     $Date: 2011-12-21 15:01:03 -0200 (Qua, 21 Dez 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-ac.sql $
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- --------------------------------------------------------

-- --------------------------------------------------------
-- AC_EVENTS
--
-- Stores: com.interact.sas.bsc.data.AnalysisEvent
-- --------------------------------------------------------
create table ac_events
(
    id              int            not null,
    ref_model       int            not null,    -- References: bsc_models.id
    ref_parent      int            not null,    -- References: ac_events.id
    ref_team        int            not null,    -- References: cmn_groups.id
    ref_owner       int            not null,    -- References: cmn_users.id
    curr_ocurrency  int            not null,
    last_ocurrency  int            not null,
    title           varchar(160)   not null,
    reason          text           not null,

    primary key ( id )
);
create index ac_events_ref_owner on ac_events ( ref_owner );
create index ac_events_model on ac_events (ref_model);
create index ac_events_parent on ac_events (ref_parent);
create index ac_events_team on ac_events (ref_team);

-- --------------------------------------------------------
-- AC_OCURRENCIES
--
-- Stores: com.interact.sas.bsc.data.AnalysisOccurrence
-- --------------------------------------------------------
create table ac_ocurrencies
(
    id                int            not null,
    ref_model         int            not null,    -- References: bsc_models.id
    ref_acevent       int            not null,    -- References: ac_events.id
    dt_period_start   date           not null,
    dt_period_end     date           not null,
    dt_planned_start  date           not null,
    dt_planned_end    date           not null,
    dt_ocurred_start  date,
    dt_ocurred_end    date,
    feedback          text           not null,

    primary key ( id )
);
create index ac_ocurrencies_model on ac_ocurrencies (ref_model);
create index ac_ocurrencies_acevent on ac_ocurrencies (ref_acevent);

-- -----------------------------------------------------------------------------
-- AC_INPUTS
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table ac_inputs
(
    ref_model       int          not null,    -- References: bsc_models.id
    ref_target      int          not null,    -- References: item target id
    ref_source      int          not null,    -- References: item source id
    family_target   smallint     not null,
    family_source   smallint     not null,

    unique ( ref_model, family_target, ref_target, family_source, ref_source )
);
create index ac_inputs_model on ac_inputs (ref_model);
create index ac_inputs_target on ac_inputs (ref_target);
create index ac_inputs_source on ac_inputs (ref_source);

-- -----------------------------------------------------------------------------
-- AC_HISTORY
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table ac_history
(
    ref_model       int          not null,    -- References: bsc_models.id
    ref_source      int          not null,    -- References: source item id
    competence      int          not null,
    family          smallint     not null,

    unique ( family, ref_model, ref_source, competence )
);
create index ac_history_model on ac_history ( ref_model );
create index ac_history_source on ac_history ( ref_source );

-- --------------------------------------------------------
-- AC_RECORDS
--
-- Stores: com.interact.sas.bsc.data.Analysis
-- --------------------------------------------------------
create table ac_records
(
    id              int            not null,
    ref_model       int            not null,    -- References: bsc_models.id
    ref_previous    int            not null,    -- References: ac_events.id
    ref_source      int            not null,    -- References: source item id
    ref_indicator   int            not null,    -- References: bsc_indicators.id
    ref_actionplan  int            not null,    -- References: bsc_actionplans.id
    ref_ocurrency   int            not null,    -- References: ac_ocurrencies.id
    ref_owner       int            not null,    -- References: cmn_users.id
    competence      int            not null,
    classification  tinyint        not null,
    family          smallint       not null,    -- See: com.interact.sas.bsc.data.Analysis.FAMILY
    origin          smallint       not null,
    dt_start        date           not null,
    dt_end          date           not null,
    dt_finished     date,
    title           varchar(200)   not null,
    info_current    text           not null,
    info_tendence   text           not null,
    info_impact     text           not null,
    info_reasons    text           not null,

    primary key ( id )
);
create index ac_records_ref_owner on ac_records (ref_owner );
create index ac_records_ref_actionplan on ac_records (ref_actionplan); 
create index ac_records_ref_indicator on ac_records (ref_indicator);
create index ac_records_ref_model on ac_records (ref_model);
create index ac_records_ref_ocurrency on ac_records (ref_ocurrency); 
create index ac_records_ref_previous on ac_records (ref_previous); 
create index ac_records_ref_source on ac_records (ref_source);
create index ac_records_classification on ac_records (classification); 
create index ac_records_competence on ac_records (competence);
create index ac_records_dt_end on ac_records (dt_end); 
create index ac_records_finished on ac_records (dt_finished); 
create index ac_records_dt_start on ac_records (dt_start);
create index ac_records_family on ac_records (family);
create index ac_records_origin on ac_records (origin); 
create index ac_records_title on ac_records (title);