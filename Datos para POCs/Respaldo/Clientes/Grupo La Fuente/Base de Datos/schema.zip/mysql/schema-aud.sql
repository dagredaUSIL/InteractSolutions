-- -----------------------------------------------------------------------------
--
-- Module:   AUD
--
-- Schema:   80.1
--
-- Revision: $Revision: 102901 $
--
-- Date:     $Date: 2012-02-03 15:06:56 -0200 (Sex, 03 Fev 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-aud.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- AUD_PROGRAMS
--
-- Stores: com.interact.sas.aud.data.Program
-- -----------------------------------------------------------------------------
create table aud_programs
(
    id                  int             not null,
    ref_category        int             not null,    -- References: cmn_categories.id
    ref_owner           int             not null,    -- References: cmn_users.id
    ref_team            int             not null,    -- References: cmn_groups.id
    ref_serial          int             not null,    -- References: cmn_serials.id
    state               tinyint         not null,    -- See: com.interact.sas.aud.data.Program.STATES 
    dt_start            date            default null,
    dt_end              date            default null,
    name                varchar(160)    not null,
    objective           text            not null,
    scope               text            not null,
    resources           text            not null,


    primary key ( id )
);
create index aud_programs_category on aud_programs ( ref_category );
create index aud_programs_owner    on aud_programs ( ref_owner );
create index aud_programs_team     on aud_programs ( ref_team );
create index aud_programs_serial   on aud_programs( ref_serial );

-- -----------------------------------------------------------------------------
-- AUD_AUDITS
--
-- Stores: com.interact.sas.aud.data.Audit
-- -----------------------------------------------------------------------------
create table aud_audits
(
    id                  int             not null,
    ref_entity          int             not null,    -- References: cmn_entities.id
    ref_program         int             not null,    -- References: aud_programs.id
    ref_owner_team      int             not null,    -- References: cmn_groups.id
    ref_audit_team      int             not null,    -- References: cmn_groups.id
    type                int             not null,    -- See: com.interact.sas.aud.data.Audit.TYPES
    approved            int             not null,
    released            int             not null,
    options             int             not null,
    state               tinyint         not null,    -- See: com.interact.sas.aud.data.Audit.STATE
    template            tinyint         not null,
    score               double          not null,
    result              double          not null,
    dt_start            date,
    dt_end              date,
    serial              varchar(24)     not null,
    name                varchar(160)    not null,
    contact             varchar(160)    not null,
    objective           text            not null,
    scope               text            not null,
    "resource"          text            not null,
    conclusion          text            not null,
    justification       text            not null,
    observation         text            not null,


    primary key ( id )
);
create index aud_audits_entity  on aud_audits ( ref_entity );
create index aud_audits_program on aud_audits ( ref_program );
create index aud_audits_owner   on aud_audits ( ref_owner_team );
create index aud_audits_audit   on aud_audits ( ref_audit_team );

-- -----------------------------------------------------------------------------
-- AUD_ACTIVITIES
--
-- Stores: com.interact.sas.aud.data.Activity
-- -----------------------------------------------------------------------------
create table aud_activities
(
    id                    int             not null,
    ref_audit             int             not null,    -- References: aud_programs.id
    ref_participant_team  int             not null,    -- References: cmn_groups.id
    ref_involved_team     int             not null,    -- References: cmn_groups.id
    ref_owner_audit       int             not null,    -- References: cmn_users.id
    dt_day                date            not null,
    tm_start              time            not null,
    duration              time            not null,
    name                  varchar(160)    not null,
    local                 varchar(80)     not null,
    description           text            not null,
    participation         text            not null,
    scope                 text            not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- AUD_ACTIVITY_RULES
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table aud_activity_rules
(
    ref_activity          int             not null,    -- References: aud_activities.id
    ref_requirement       int             not null,    -- References: cmn_requirements.id

    unique ( ref_activity, ref_requirement )
);

-- -----------------------------------------------------------------------------
-- AUD_ACTORS
--
-- Stores: com.interact.sas.aud.data.Actor
-- -----------------------------------------------------------------------------
create table aud_actors
(
    id                    int             not null,
    type                  int             not null,    -- See: com.interact.sas.aud.data.Actor.TYPES 
    name                  varchar(80)     not null,
    description           text            not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- AUD_CHECKLISTS
--
-- Stores: com.interact.sas.aud.data.Checklist
-- -----------------------------------------------------------------------------
create table aud_checklists
(
    id                    int             not null,
    ref_category          int             not null,    -- References: cmn_categories.id
    ref_source             int             not null,    -- References: aud_programs.id
    ref_owner             int             not null,    -- References: cmn_users.id
    ref_team              int             not null,    -- References: cmn_groups.id
    public_check          int             not null,
    family                int             not null,
    score                 double          not null,
    score_result          double          not null,
    score_max             double          not null,
    mnemonic              varchar(40)     not null,
    name                  varchar(160)    not null,
    
    primary key ( id )
);
create index aud_checklists_category on aud_checklists ( ref_category );
create index aud_checklists_source   on aud_checklists ( ref_source );
create index aud_checklists_owner    on aud_checklists ( ref_owner );

-- -----------------------------------------------------------------------------
-- AUD_CONSTATATION
--
-- Stores: com.interact.sas.aud.data.Constatation
-- -----------------------------------------------------------------------------
create table aud_constatation
(
    id                     int           not null,
    ref_audit              int           not null,    -- References: aud_programs.id
    ref_author             int           not null,    -- References: cmn_users.id
    ref_owner              int           not null,    -- References: cmn_users.id
    ref_checkitem          int           not null,    -- References: aud_checklist_items.id
    type                   int           not null,
    score                  double        not null,
    dt_created             date          not null,
    sector                 varchar(80)   not null,
    origem                 varchar(80)   not null,
    description            text          not null,
    evidence               text          not null,
    recommendations        text          null,        

    primary key ( id )
);
create index aud_const_checkitem on aud_constatation ( ref_checkitem );

-- -----------------------------------------------------------------------------
-- AUD_CHECKLIST_ITEMS
--
-- Stores: com.interact.sas.aud.data.ChecklistItem
-- -----------------------------------------------------------------------------
create table aud_checklist_items
(
    id                     int           not null,
    ref_checklist          int           not null,              -- References: aud_checklists.id
    ref_original           int           not null,              -- References: aud_checklists.id
    ref_owner              int           default 0 not null,    -- References: cmn_users.id
    ref_scale              int           not null,              -- References: cmn_scales.id
    ref_parent             int           not null,              -- References: aud_checklist_items.id
    conformity             int           not null,
    status                 tinyint       not null,
    seqno                  smallint      null,
    score                  double        not null,
    scale_result           double        not null,
    scale_max              double        not null,
    wbs                    varchar(30)   not null,
    scale_label            varchar(160)  null,
    documents              text          not null,
    instructions           text          not null,
    scale_info             text          not null,
    
    primary key ( id )
);
create index aud_checklist_items_scale  on aud_checklist_items( ref_scale );
create index aud_checklist_items_parent on aud_checklist_items( ref_parent );

-- -----------------------------------------------------------------------------
-- AUD_CHECKLIST_RULES
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table aud_checklist_rules
(
    ref_checkitem          int           not null,    -- References: aud_checklist_items.id
    ref_requirement        int           not null,    -- References: cmn_requirements.id

    unique ( ref_checkitem, ref_requirement )
);

create index aud_checklist_rules_checkitem on aud_checklist_rules ( ref_checkitem );
create index aud_checklist_rules_req       on aud_checklist_rules ( ref_requirement );

-- -----------------------------------------------------------------------------
-- AUD_CONSTATATION_OCURRENCES
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table aud_constatation_ocurrences
(
    ref_constatation       int           not null,    -- References: aud_constatation.id
    ref_ocurrence          int           not null,    -- References: qms_occurrences.id

    unique ( ref_constatation, ref_ocurrence )
);

-- -----------------------------------------------------------------------------
-- AUD_CONSTATATION_RULES
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table aud_constatation_rules
(
    ref_constatation       int           not null,    -- References: aud_constatation
    ref_requirement        int           not null,    -- References: cmn_requirements.id

    unique ( ref_constatation, ref_requirement )
);

-- -----------------------------------------------------------------------------
-- AUD_CONSTATATION_TYPES
--
-- Stores: com.interact.sas.aud.data.ConstatationType
-- -----------------------------------------------------------------------------
create table aud_constatation_types
(
    id                      int           not null,
    ref_ocurrence_type      int           not null,    -- References: qms_types.id
    state                   int           not null,    -- See: com.interact.sas.aud.data.ConstatationType.STATES 
    name                    varchar(160)  not null,
    description             text          not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- AUD_PARTICIPANT_ABILITY
--
-- Stores: com.interact.sas.aud.data.ParticipantAbility
-- -----------------------------------------------------------------------------
create table aud_participant_ability
(
    id                      int           not null,
    ref_participant         int           not null,    -- References: cmn_users.id
    ref_rule                int           not null,    -- References: cmn_rules.id
    ref_actor               int           not null,    -- References: aud_actors.id
    active                  int           not null,
    type                    int           not null,
    dt_end                  date          not null,
    description             text          not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- AUD_PARTICIPANT_HISTORY
--
-- Stores: com.interact.sas.aud.data.ParticipantHistory
-- -----------------------------------------------------------------------------
create table aud_participant_history
(
    id                      int           not null,
    ref_participant         int           not null,    -- References: aud_participants.id
    ref_rule                int           not null,    -- References: cmn_rules.id
    ref_actor               int           not null,    -- References: aud_actors.id
    dt_verified             date          not null,
    location                varchar(80)   not null,
    description             text          not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- AUD_PARTICIPANTS
--
-- Stores: com.interact.sas.aud.data.Participant
-- -----------------------------------------------------------------------------
create table aud_participants
(
    id                        int           not null,
    ref_user                  int           not null,    -- References: cmn_users.id
    ref_entity                int           not null,    -- References: cmn_entities.id
    type                      int           not null,
    mnemonic                  varchar(40)   not null,
    description               text          not null,
    formation                 text          not null,
    training                  text          not null,
    particularity             text          not null,

    primary key ( id )
);

create index aud_participants_user on aud_participants ( ref_user );

-- -----------------------------------------------------------------------------
-- AUD_PROGRAMS_RULES
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table aud_programs_rules
(
    ref_program             int         not null,    -- References: aud_programs.id
    ref_rule                int         not null,    -- References: cmn_rules.id

    unique ( ref_program, ref_rule )
);

-- -----------------------------------------------------------------------------
-- AUD_RULES_ACTORS
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table aud_rules_actors
(
    ref_rule                int         not null,    -- References: cmn_rules.id
    ref_actor               int         not null,    -- References: aud_actors.id

    unique ( ref_rule, ref_actor )
);

-- -----------------------------------------------------------------------------
-- AUD_RULES_PARTICIPANTS
--
-- Stores: com.interact.sas.aud.data.ParticipantRule
-- -----------------------------------------------------------------------------
create table aud_rules_participants
(
    ref_participant         int         not null,    -- References: aud_participants.id
    ref_rule                int         not null,    -- References: cmn_rules.id
    ref_audit               int         not null,    -- References: aud_audits.id
    type                    int         not null,

    unique ( type, ref_audit, ref_rule, ref_participant )
);
