-- -----------------------------------------------------------------------------
--
-- Module:   BRM
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL$
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- BRM_METHODS
--
-- Stores: com.interact.sas.brm.data.Method
-- -----------------------------------------------------------------------------
create table brm_methods
(
    id                      int                     not null,
    ref_owner               int                     not null,    -- References: cmn_users.id
    ref_script              int                     not null,    -- References: vfs_files.id
    ref_category            int                     not null,    -- References: cmn_categories.id
	ref_team				int						not null,	 -- References: cmn_groups.id
    flavour                 tinyint                 not null,
    fl_notification         tinyint                 not null,
    name                    varchar(250)            not null,
    uuid                    varchar(36)             not null,
    info                    text                    not null,
	stage					tinyint					not null,
	        
    primary key ( id ),
    unique ( name )
);
create index brm_methods_owner  on brm_methods ( ref_owner );
create index brm_methods_script on brm_methods ( ref_script );
create index brm_methods_team on brm_methods ( ref_team );

-- -----------------------------------------------------------------------------
-- BRM_ARGUMENTS
--
-- Stores: com.interact.sas.brm.data.ArgumentDefinition
-- -----------------------------------------------------------------------------
create table brm_arguments
(
    id                      int                     not null,
    ref_method              int                     not null,    -- References: brm_methods.id
    family                  tinyint                 not null,    -- See: com.interact.sas.brm.data.ArgumentDefinition.FAMILY
    label                   varchar(250)            not null,
    name                    varchar(250)            not null,
    default_value           varchar(250)            not null,
    
    primary key ( id ),
    unique ( ref_method, name )
);

-- -----------------------------------------------------------------------------
-- BRM_EXECUTIONS
--
-- Stores: com.interact.sas.brm.data.Execution
-- -----------------------------------------------------------------------------
create table brm_executions
(
    id                      int                     not null,
    ref_user                int                     not null,    -- References: cmn_users.id
    ref_method              int                     not null,    -- References: brm_methods.id
    ref_error               int                     not null,    -- References: brm_errors.id
    result                  int                     not null,
    ts_enter                timestamp               null,
    ts_exit                 timestamp               null,
    duration                long                    not null,

    primary key ( id )
);
create index brm_executions_method on brm_executions ( ref_method );
create index brm_executions_user   on brm_executions ( ref_user );
create index brm_executions_error  on brm_executions ( ref_error );

-- -----------------------------------------------------------------------------
-- BRM_ERRORS
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table brm_errors
(
    id                      int                     not null,
    status                  int                     not null,
    message                 varchar(250)            not null,
    info                    text                    not null,
    
    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- BRM_CONSUMERS
--
-- Stores: com.interact.sas.brm.data.BusinessRuleConsumer
-- -----------------------------------------------------------------------------
create table brm_consumers
(
    id                      int                     not null,
    ref_method              int                     not null,    -- References: brm_methods.id
    ref_context             int                     not null,    -- References: context item id
    ref_owner               int                     not null,    -- References: cmn_users.id
    operation               tinyint                 not null,    -- See: com.interact.sas.brm.data.BusinessRuleConsumer.OPERATION_PERSISTENCE
    family                  smallint                not null,    -- See: com.interact.sas.brm.data.BusinessRuleConsumer.FAMILIES
    ts_created              timestamp,
    url                     varchar(250)            not null,
    info                    text                    not null,

    primary key ( id )
);
create index brm_consumers_method  on brm_consumers ( ref_method );
create index brm_consumers_context on brm_consumers ( ref_context );
create index brm_consumers_owner   on brm_consumers( ref_owner);

-- -----------------------------------------------------------------------------
-- BRM_PARAMETER_MAPPINGS
--
-- Stores: com.interact.sas.brm.data.BusinessRuleParameterMapping
-- -----------------------------------------------------------------------------
create table brm_parameter_mappings
(
    ref_consumer            int                     not null,    -- References: brm_consumers.id
    ref_argument            int                     not null,    -- References: brm_arguments.id
    value                   varchar(250)            not null,
    
    unique ( ref_consumer, ref_argument )
);

-- --------------------------------------------------------------
-- BRM_REMOTE_ACCESSES
--
-- Stores: N/A
-- --------------------------------------------------------------
create table brm_remote_accesses
(
    id           int            not null,
    ref_rule     int            not null,    -- References: brm_rules.id
    state        tinyint        not null,
    application  varchar(160)   not null,
    origin       varchar(160)   not null,
    credential   varchar(128)   not null,

    primary key ( id ),
    unique ( ref_rule, application, origin )
);
create index brm_remote_accesses_rule        on brm_remote_accesses( ref_rule );
create index brm_remote_accesses_application on brm_remote_accesses( application );
create index brm_remote_accesses_origin      on brm_remote_accesses( origin );
create index brm_remote_accesses_state       on brm_remote_accesses( state );


-- --------------------------------------------------------------
-- BRM_REMOTE_CALLS
--
-- Stores: N/A
-- --------------------------------------------------------------
create table brm_remote_calls
(
    id           int            not null,
    ref_rule     int            not null,    -- References: brm_rules.id
    ref_access   int            not null,    -- References: brm_remote_access.id
    duration     int            not null,
    state        tinyint        not null,
    dt_call      timestamp      not null,
    dt_finish    timestamp      null,
    origin       varchar(160)   not null,
  
    primary key ( id )
);
create index brm_remote_calls_rule   on brm_remote_calls( ref_rule );
create index brm_remote_calls_access on brm_remote_calls( ref_access );
create index brm_remote_calls_origin on brm_remote_calls( origin );
create index brm_remote_calls_state  on brm_remote_calls( state );