-- --------------------------------------------------------
--
-- Module:   PRJ
--
-- Schema:   80.1
--
-- Revision: $Revision: 161759 $
--
-- Date:     $Date: 2014-11-24 11:42:30 -0200 (seg, 24 nov 2014) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/product/SA-7.0.6.1/runtime/schema/db/install/40/mysql/schema-prj.sql $
--
-- Author:   Matheus Netto (mn@interact.com.br)
--
-- --------------------------------------------------------

-- --------------------------------------------------------
-- PRJ_PROJECTS
--
-- Stores: com.interact.sas.prj.data.Project
-- --------------------------------------------------------
create table prj_projects
(
    id                       int             not null,
    ref_executive            int             not null,    -- References: cmn_users.id
    ref_director             int             not null,    -- References: cmn_users.id
    ref_owner                int             not null,    -- References: cmn_users.id
    ref_team                 int             not null,    -- References: cmn_groups.id
    ref_folder               int             not null,    -- References: dms_folders.id
    ref_category             int             not null,    -- References: cmn_category.id
    ref_calendar             int             not null,    -- References: cmn_calendar.id
    ref_serial               int             null,        -- References: cmn_serials.id
    ref_approver             int             not null,    -- References: cmn_users.id
    rev                      int             not null,
    restriction              int             not null,
    task_duration            int             not null,
    total_weight             int             not null,
    phase                    int             not null,
    fl_template              tinyint         null,
    budget                   double          null,
    estim_investment         double          not null,
    real_investment          double          not null,
    percent_finished         smallint        not null,
    "state"                  smallint        not null,    -- See: com.interact.sas.prj.data.Project.STATE
    progress_calculator_type smallint        not null,
    dt_estimated_start       date            null,
    dt_estimated_end         date            null,
    dt_real_start            date            null,
    dt_real_end              date            null,
    dt_limit                 date            null,
    code                     varchar(24)     null,
    currency                 varchar(30)     not null,
    mnemonic                 varchar(64)     not null,
    options                  varchar(128)    not null,
    "name"                   varchar(160)    not null,
    info                     text            not null,
    
    unique ( id, rev )
);
alter table prj_projects add constraint mnemonic unique ( mnemonic );
create index ix_prj_projects_rev            on prj_projects( rev );
create index ix_prj_projects_executive      on prj_projects( ref_executive );
create index ix_prj_projects_director       on prj_projects( ref_director );
create index ix_prj_projects_owner          on prj_projects( ref_owner );
create index ix_prj_projects_team           on prj_projects( ref_team );
create index ix_prj_projects_folder         on prj_projects( ref_folder );
create index ix_prj_projects_category       on prj_projects( ref_category );
create index ix_prj_projects_calendar       on prj_projects( ref_calendar );
create index ix_prj_projects_serial         on prj_projects( ref_serial );
create index ix_prj_projects_dt_estim_start on prj_projects( dt_estimated_start );
create index ix_prj_projects_dt_estim_end   on prj_projects( dt_estimated_end );
create index ix_prj_projects_dt_limit       on prj_projects( dt_limit );
create index ix_prj_projects_approver       on prj_projects( ref_approver );

-- --------------------------------------------------------
-- PRJ_TASKS
--
-- Stores: com.interact.sas.prj.data.Task
-- --------------------------------------------------------
create table prj_tasks 
(
    id                  int             not null,
    ref_project         int             not null,    -- References: prj_projects.id
    ref_parent          int             not null,    -- References: prj_tasks.id
    ref_tags            int             not null,    -- References: cmn_tag_kinds.id
    ref_owner           int             null,        -- References: cmn_users.id
    rev                 int             not null,
    sucessor_offset     int             null,
    weight              int             not null,
    estim_investment    double          not null,
    real_investment     double          not null,
    duration            double          not null,
    state               tinyint         not null,    -- See: com.interact.sas.prj.data.Task.STATES
    monitor             tinyint         not null,    -- See: com.interact.sas.prj.data.Task.MONITORS
    unit                tinyint         not null,
    fl_eap              tinyint         null,
    percent_finished    smallint        not null,
    dt_estimated_start  date            null,
    dt_estimated_end    date            null,
    dt_real_start       date            null,
    dt_real_end         date            null,
    wbs                 varchar(30)     not null,
    "name"              varchar(160)    not null,
    info                text            not null,

    unique ( id, rev )
);
create index ix_prj_tasks_ref_parent         on prj_tasks( ref_parent );
create index ix_prj_tasks_ref_owner          on prj_tasks( ref_owner );
create index ix_prj_tasks_ref_project        on prj_tasks(ref_project);
create index ix_prj_tasks_rev                on prj_tasks( rev );
create index ix_prj_tasks_dt_estimated_start on prj_tasks( dt_estimated_start );
create index ix_prj_tasks_dt_estimated_end   on prj_tasks( dt_estimated_end );
create index ix_prj_tasks_state              on prj_tasks( state );
create index prj_tasks_tags                  on prj_tasks( ref_tags );
    
-- --------------------------------------------------------
-- PRJ_RESOURCES
--
-- Stores: com.interact.sas.prj.data.Resource
-- --------------------------------------------------------
create table prj_resources 
(
    id                  int             not null,
    ref_user            int             null,        -- References: cmn_users.id
    ref_project         int             not null,    -- References: prj_projects.id
    ref_calendar        int             null,        -- References: cmn_calendars.id
    rev                 int             not null,
    type                smallint        not null,    -- See: com.interact.sas.prj.data.Resource.TYPES
    cost                double          not null,
    initials            varchar(5)      not null,
    "group"             varchar(80)     not null,
    name                varchar(80)     null,
    
    unique ( id, rev )
);
create index ix_prj_resources_ref_project  on prj_resources(ref_project);
create index ix_prj_resources_ref_user     on prj_resources(ref_user);
create index ix_prj_resources_ref_calendar on prj_resources(ref_calendar);
create index ix_prj_resources_rev          on prj_resources( rev );
create index ix_prj_resources_type         on prj_resources( type );

-- --------------------------------------------------------
-- PRJ_TASK_RESOURCES
--
-- Stores: com.interact.sas.prj.data.TaskResource
-- --------------------------------------------------------
create table prj_task_resources
(
    id                  int             not null,
    ref_task            int             not null,   -- References: prj_task.id
    ref_resource        int             not null,   -- References: prj_resources.id
    rev                 int             not null,
    realized_duration   int             not null,
    progress            int             default 0 not null,
    percent_usage       smallint        not null,
    estimated_total     double          null,
    realized_total      double          null,
    estimated_quantity  double          null,
    realized_quantity   double          null,
    realized_cost       double          null,
    estimated_cost      double          null,
    dt_estimated_start  timestamp       null,
    dt_estimated_end    timestamp       null,
    dt_realized_start   timestamp       null,
    dt_realized_end     timestamp       null,
    
    unique key ( id, rev )
);
create index ix_prj_task_resources_ref_resource on prj_task_resources(ref_resource);
create index ix_prj_task_resources_ref_task     on prj_task_resources(ref_task);
create index ix_prj_task_res_rev                on prj_task_resources( rev );
create index ix_prj_task_res_dt_est_start       on prj_task_resources( dt_estimated_start );
create index ix_prj_task_res_dt_est_end         on prj_task_resources( dt_estimated_end );
create index ix_prj_task_res_dt_rea_start       on prj_task_resources( dt_realized_start );
create index ix_prj_task_res_dt_rea_end         on prj_task_resources( dt_realized_end  );

-- --------------------------------------------------------
-- PRJ_PREDECESSORS
--
-- Stores: N/A
-- --------------------------------------------------------
create table prj_predecessors 
(
    ref_task_source          int             not null,    -- References: prj_tasks.id
    ref_task_predecessor     int             not null,    -- References: prj_tasks.id
    rev                      int             not null,
    
    unique ( ref_task_source, ref_task_predecessor, rev )
);
create index ix_prj_predecessors_ref_ta_sou on prj_predecessors(ref_task_source);
create index ix_prj_predecessors_ref_ta_pr  on prj_predecessors(ref_task_predecessor);

-- --------------------------------------------------------
-- PRJ_BASELINES
--
-- Stores: com.interact.sas.prj.data.Baseline
-- --------------------------------------------------------
create table prj_baselines 
(
    id                  int             not null,
    ref_project_id      int             not null,    -- References: prj_project.id
    ref_project_rev     int             not null,    -- References: prj_projects.rev
    "name"              varchar(160)    not null,
    "date"              date            not null,
    
    unique ( ref_project_id, ref_project_rev )
  
);
create index ix_prj_baselines_proj_id  on prj_baselines( ref_project_id );
create index ix_prj_baselines_proj_rev on prj_baselines( ref_project_rev );

-- --------------------------------------------------------
-- PRJ_STATUS_REPORTS
--
-- Stores: com.interact.sas.prj.data.StatusReport
-- --------------------------------------------------------
create table prj_status_reports
(
    id                  int                 not null,
    ref_project         int                 not null,    -- References: prj_project.id
    ref_owner           int                 not null,    -- References: cmn_users.id
    ref_project_rev     int                 not null,    -- References: prj_project.rev
    classification      int                 not null,
    dt_created          date                not null,
    dt_next             date                null,
    info                text                not null,
	state				tinyint				not null,

    primary key ( id )
);
create index prj_status_reports_proj_rev on prj_status_reports (ref_project_rev);

-- --------------------------------------------------------
-- PRJ_RISKS
--
-- Stores: N/A
-- --------------------------------------------------------
create table prj_risks
(
    ref_project       int not null,    -- References: prj_projects.id
    ref_file          int not null,    -- References: vsf_files.id
  
    unique ( ref_project, ref_file )
);

-- --------------------------------------------------------
-- PRJ_PROPOSALS
--
-- Stores: com.interact.sas.prj.data.Proposal
-- --------------------------------------------------------
create table prj_proposals
(
    id                int            not null,
    ref_author        int            not null,
    ref_analysed_by   int            null,        -- References: cmn_users.id
    ref_sponsor       int            not null,    -- References: cmn_users.id
    ref_manager       int            not null,    -- References: cmn_users.id
    ref_project       int            not null,    -- References: prj_projects.id
    ref_office        int            not null,    -- References: cmn_users.id
    ref_form          int            not null,    -- References: prj_forms.id
    state             smallint       not null,    -- See: com.interact.sas.prj.data.Proposal.STATES
    investment        double         null,
    return_rate       double         null,
    resource_usage    double         null,
    dt_analysed       date           null,
    dt_created        date           not null,
    name              varchar(80)    not null,
    info              text           null,

    primary key( id )
);
create index ix_prj_proposals_ref_approved on prj_proposals( ref_analysed_by );
create index ix_prj_proposals_ref_author   on prj_proposals( ref_author );
create index ix_prj_proposals_sponsor      on prj_proposals( ref_sponsor );
create index ix_prj_proposals_manager      on prj_proposals( ref_manager );
create index ix_prj_proposals_office       on prj_proposals( ref_office );
create index prj_proposals_project         on prj_proposals( ref_project );
create index ix_prj_proposals_form         on prj_proposals( ref_form );

-- --------------------------------------------------------
-- PRJ_CASHFLOWS
--
-- Stores: com.interact.sas.prj.data.Cashflow
-- --------------------------------------------------------
create table prj_cashflows
(
    id              int          not null,
    ref_project     int          not null,
    ref_source      int          not null,    -- References: Source item ID
    ref_owner       int          not null,    -- References: cmn_users.id
    ref_tags        int          not null,    -- References: cmn_tag_kinds.id
    rev             int          not null,
    origin          tinyint      not null,
    type            tinyint      not null,
    estimated_value double       not null,
    amount          double       not null,
    real_value      double       not null,
    dt_estimated    date         not null,
    dt_real         date         null,
    "grouping"      varchar(160) not null,
    info            text         not null,

    unique key( id, ref_project, rev )
);
create index ix_prj_cashflows_project on prj_cashflows( ref_project );
create index ix_prj_cashflows_task    on prj_cashflows( ref_source );
create index ix_prj_cashflows_owner   on prj_cashflows( ref_owner );
create index ix_prj_cashflows_tags    on prj_cashflows( ref_tags );
create index ix_prj_cashflows_rev     on prj_cashflows( rev );
-- --------------------------------------------------------
-- PRJ_LESSONS
--
-- Stores: com.interact.sas.prj.data.Lesson
-- --------------------------------------------------------
create table prj_lessons
(
    id          int      not null,
    ref_project int      not null,    -- References: prj_projects.id
    ref_user    int      not null,    -- References: cmn_users.id
    rev         int      not null,    -- References: prj_psrojects.rev
    type        smallint not null,
    item        smallint not null,
    dt_created  date     not null,
    info        text     not null,

    unique key( id, rev )
);
create index prj_lessons_project on prj_lessons( ref_project );
create index prj_lessons_user    on prj_lessons( ref_user );
create index prj_lessons_rev     on prj_lessons( rev );

-- --------------------------------------------------------
-- PRJ_LESSONS
--
-- Stores: com.interact.sas.prj.data.TaskChecklist
-- --------------------------------------------------------
create table prj_task_checklists
(
    id       int          not null,
    ref_task int          not null,    -- References: prj_tasks.id
    state    int          not null,
    content  varchar(320) not null,

    primary key ( id )
);
create index ix_prj_task_checklists_task on prj_task_checklists( ref_task );

-- --------------------------------------------------------
-- PRJ_KANBAN_ITEMS
--
-- Stores: com.interact.sas.prj.data.KanbanItem
-- --------------------------------------------------------
create table prj_kanban_items
(
    id          int         not null,
    ref_project int         not null,    -- References: prj_projects.id
    position    int         not null,
    title       varchar(80) not null,

    primary key ( id )
);
create index prj_kanban_items_project on prj_kanban_items ( ref_project );

-- --------------------------------------------------------
-- PRJ_KANBAN_CARDS
--
-- Stores: com.interact.sas.prj.data.KanbanCard
-- --------------------------------------------------------
create table prj_kanban_cards
(
    id       int not null,
    ref_task int not null,    -- References: prj_tasks.id
    ref_item int not null,    -- References: prj_kanban_items.id
    position int not null,

    primary key ( id )
);
create index prj_kanban_cards_task on prj_kanban_cards ( ref_task );
create index prj_kanban_cards_item on prj_kanban_cards ( ref_item );

-- --------------------------------------------------------
-- PRJ_MATRICES
--
-- Stores: N/A
-- --------------------------------------------------------
create table prj_matrices
(
    id                      int             not null,
    ref_project             int             not null,
    rev                     int             not null,
    type                    int             not null,
    font_color              varchar(7)      not null,
    header_background_color varchar(7)      not null,
    font_style              varchar(250)    not null,
    content                 text            not null,
    info                    text            null,
    
    unique key ( id, rev )
);
create index ix_prj_matrices_project on prj_matrices( ref_project );
create index ix_prj_matrices_rev     on prj_matrices( rev );

-- --------------------------------------------------------
-- PRJ_FORMS
--
-- Stores: com.interact.sas.prj.data.ProposalForm
-- --------------------------------------------------------
create table prj_forms
(
    id              int            not null,
    ref_owner       int            not null,    -- References: cmn_users.id
    ref_team        int            not null,    -- References: cmn_groups.id
    ref_category    int            not null,    -- References: cmn_category.id
    "state"         int            not null,
    fl_default      int            not null,
    "name"          varchar(80)    not null,
    info            text           not null,

    primary key ( id )
);
create index ix_prj_forms_owner    on prj_forms( ref_owner );
create index ix_prj_forms_team     on prj_forms( ref_team );
create index ix_prj_forms_category on prj_forms( ref_category );

-- --------------------------------------------------------
-- PRJ_TOPICS
--
-- Stores: com.interact.sas.prj.data.ProposalFormTopic
-- --------------------------------------------------------
create table prj_topics
(
    id              int     not null,
    ref_form        int     not null,    -- References: prj_forms.id
    type            int     not null,
    relevance       int     not null,
    fl_mandatory    int     not null,
    sequence        int     not null,
    "name"          text    not null,
    info            text    not null,

    primary key ( id )
);
create index ix_prj_topics_ref_form on prj_topics( ref_form );

-- --------------------------------------------------------
-- PRJ_OPTIONS
--
-- Stores: com.interact.sas.prj.data.ProposalFormTopicOption
-- --------------------------------------------------------
create table prj_options 
(
    id           int            not null,
    ref_topic    int            not null,    -- References: prj_topics.id
    relevance    int            not null,
    sequence     int            not null,
    "name"       varchar(80)    not null,

    primary key ( id )
);
create index ix_prj_options_topic on prj_options( ref_topic );

-- --------------------------------------------------------
-- PRJ_ANSWERS
--
-- Stores: com.interact.sas.prj.data.ProposalFormAnswer
-- --------------------------------------------------------
create table prj_answers
(
    id              int    not null,
    ref_proposal    int    not null,    -- References: prj_proposals.id
    ref_form        int    not null,    -- References: prj_forms.id
    "state"         int    not null,

    primary key ( id ),
    unique ( ref_proposal )
);
create index ix_prj_answers_proposal on prj_answers( ref_proposal );
create index ix_prj_answers_form     on prj_answers( ref_form );

-- --------------------------------------------------------
-- PRJ_TOPIC_ANSWERS
--
-- Stores: com.interact.sas.prj.data.ProposalFormTopicAnswer
-- --------------------------------------------------------
create table prj_topic_answers
(
    id            int       not null,
    ref_answer    int       not null,
    ref_topic     int       not null,
    score         double    not null,
    feedback      text      not null,

    primary key ( id ),
    unique ( ref_answer, ref_topic )
);
create index ix_prj_topic_answers_answer on prj_topic_answers( ref_answer );
create index ix_prj_topic_answers_topic  on prj_topic_answers( ref_topic );