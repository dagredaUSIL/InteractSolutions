-- -----------------------------------------------------------------------------
--
-- Module:   CRT
--
-- Schema:   80.1
--
-- Revision: $Revision: 99236 $
--
-- Date:     $Date: 2011-11-22 17:38:46 -0200 (Ter, 22 Nov 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-crt.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- CRT_ANSWERS
--
-- Stores: com.interact.sas.crt.data.CertificationAnswer
-- -----------------------------------------------------------------------------
create table crt_answers
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    ref_application       int                 not null,    -- References: crt_applications.id
    ref_topic             int                 not null,    -- References: crt_topics.id
    ref_option            int                 not null,    -- References: crt_options.id
    result                double              not null,
    score                 double              not null,
    feedback              varchar(250)        not null,

    primary key ( id )
);
create index crt_answers_certification      on crt_answers ( ref_certification );
create index crt_answers_application        on crt_answers ( ref_application );
create index crt_answers_topic              on crt_answers ( ref_topic );
create index crt_answers_option             on crt_answers ( ref_option );

-- --------------------------------------------------------
-- CRT_APPLICATIONS
--
-- Stores: com.interact.sas.crt.data.CertificationApplication
-- --------------------------------------------------------
create table crt_applications
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    ref_occurrence        int                 not null,    -- References: crt_occurrences.id
    ref_participant       int                 not null,    -- References: cmn_users.id
    ref_owner             int                 not null,    -- References: cmn_users.id
    competence            int                 not null,
    anonymous             smallint            not null,
    score                 double              not null,
    dt_occurrence         date                default null,
    author                varchar(80)         not null,
    feedback              text                not null,
  
    primary key ( id )
  
);
create index crt_applications_certification on crt_applications ( ref_certification );
create index crt_applications_occurrence    on crt_applications ( ref_occurrence );
create index crt_applications_participant   on crt_applications ( ref_participant );
create index crt_applications_owner         on crt_applications ( ref_owner );

-- --------------------------------------------------------
-- CRT_CERTIFICATIONS
--
-- Stores: com.interact.sas.crt.data.Certification
-- --------------------------------------------------------
create table crt_certifications
(
    id                    int                 not null,
    ref_owner             int                 not null,    -- References: cmn_users.id
    ref_last_occurrence   int                 not null,    -- References: crt_occurrences.id
    ref_active_occurrence int                 not null,    -- References: crt_occurrences.id
    ref_entity            int                 not null,    -- References: cmn_entities.id
    ref_tags              int                 not null,    -- References: cmn_entities.id
    ref_category          int                 not null,    -- References: cmn_categories.id
    score_max             int                 not null,
    min_participants      int                 not null,
    restriction           int                 not null,
    is_public_collector   int                 not null,
    period                smallint            not null,    -- See: com.interact.sas.crt.data.Certification.PERIODS
    score_lower           smallint            not null,
    score_upper           smallint            not null,
    score_method          smallint            not null,
    is_anonymous          smallint            not null,
    obsolete              smallint            not null,
    family                smallint            not null,
    score_avg             double              not null,
    dt_occurred           date                default null,
    mnemonic              varchar(40)         default null,
    name                  varchar(80)         not null,
    info                  text                not null,
    instructions          text                not null,

    primary key ( id )
);
create index crt_certification_owner        on crt_certifications ( ref_owner );
create index crt_certifications_restriction on crt_certifications ( restriction );
create index crt_certifications_tags        on crt_certifications( ref_tags );
create index crt_certifications_category    on crt_certifications( ref_category );

-- --------------------------------------------------------
-- CRT_FEEDBACK
--
-- Stores: com.interact.sas.crt.data.CertificationFeedback
-- --------------------------------------------------------
create table crt_feedback
(  
    ref_answer  int     not null,    -- References: crt_answers.id
    info        text    not null,

    unique (ref_answer)
);

-- --------------------------------------------------------
-- CRT_HINT
--
-- Stores: com.interact.sas.crt.data.CertificationHint
-- --------------------------------------------------------
create table crt_hint
(
    id                   int                  not null,
    ref_option           int                  not null,    -- References: crt_options.id
    type                 int                  not null,    -- See: com.interact.sas.crt.data.CertificationHint.TYPE
    position             int                  not null,
    info                 text                 not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- CRT_OCCURRENCES
--
-- Stores: com.interact.sas.crt.data.CertificationOccurrence
-- --------------------------------------------------------
create table crt_occurrences
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    competence            int                 not null,
    dt_planned            date                default null,
    dt_period_start       date                default null,
    dt_period_end         date                default null,
    dt_opened             date                default null,
    dt_closed             date                default null,
    name                  varchar(240)        not null,
    feedback              text                not null,

    primary key ( id )
);
create index crt_occurrence_certification   on crt_occurrences ( ref_certification );

-- --------------------------------------------------------
-- CRT_OPTION_GROUPS
--
-- Stores: com.interact.sas.crt.data.CertificationOptionGroup
-- --------------------------------------------------------
create table crt_option_groups
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    ref_topic             int                 not null,    -- References: crt_topics.id
    fl_diagram            tinyint             not null,
    mnemonic              varchar(40)         not null,
    label                 varchar(80)         not null,
    options               varchar(240)        not null,

    primary key ( id )
);
create index crt_option_group_certification on crt_option_groups ( ref_certification );
create index crt_option_group_topic         on crt_option_groups ( ref_topic );

-- --------------------------------------------------------
-- CRT_OPTION_ITEMS
--
-- Stores: com.interact.sas.crt.data.CertificationOptionItem
-- --------------------------------------------------------
create table crt_option_items
(
    id                    int                 not null,
    ref_option            int                 not null,    -- References: crt_options.id
    position              int                 not null,
    fl_comment            smallint            not null,
    fl_percent            smallint            not null,
    score                 double              not null,
    name                  varchar(240)        not null,

    primary key ( id )
);
create index crt_option_item_option         on crt_option_items ( ref_option );

-- --------------------------------------------------------
-- CRT_OPTIONS
--
-- Stores: com.interact.sas.crt.data.CertificationOption
-- --------------------------------------------------------
create table crt_options
(
    id                    int                 not null,
    ref_category          int                 not null,    -- References: cmn_categories.id
    type                  int                 not null,    -- See: com.interact.sas.crt.data.CertificationOption.TYPE
    "rows"                int                 not null,
    cols                  int                 not null,
    obsolete              smallint            not null,
    smiles                smallint            null,
    name                  varchar(240)        not null,
	
    primary key ( id )
);

-- --------------------------------------------------------
-- CRT_PARTICIPANTS
--
-- Stores: com.interact.sas.crt.data.CertificationParticipant
-- --------------------------------------------------------
create table crt_participants
(
    ref_entity            int                 not null,    -- References: cmn_entities.id
    ref_certification     int                 not null,    -- References: crt_certifications.id
    fl_team               smallint            not null,
    fl_owner              smallint            not null,

    unique ( ref_entity, ref_certification, fl_team )
);

create index crt_participants_entity        on crt_participants ( ref_entity );
create index crt_participants_certification on crt_participants ( ref_certification );

-- --------------------------------------------------------
-- CRT_TOKENS
--
-- Stores: com.interact.sas.crt.data.CertificationToken
-- --------------------------------------------------------
create table crt_tokens
(
    id                    int                 not null,
    ref_sector            int                 not null,    -- References: cmn_sectors.id
    ref_certification     int                 not null,    -- References: crt_certifications.id
    ref_application       int                 not null,    -- References: crt_applications.id
    ref_occurrency        int                 not null,    -- References: crt_occurrences.id
    competence            int                 not null,
    is_published          tinyint             not null,
    is_valid              smallint            not null,
    token                 varchar(10)         not null,
    to_address            varchar(50)         not null,
    to_name               varchar(80)         not null,

    primary key ( id )
);
create index crt_token_certification        on crt_tokens ( ref_certification );
create index crt_token_application          on crt_tokens ( ref_application );
create index crt_token_occurrency           on crt_tokens ( ref_occurrency );

-- --------------------------------------------------------
-- CRT_TOPIC_GROUPS
--
-- Stores: com.interact.sas.crt.data.CertificationTopicGroup
-- --------------------------------------------------------
create table crt_topic_groups
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    label                 varchar(80)         not null,
    topics                varchar(240)        not null,

    primary key ( id )
);

create index crt_topics_groups_cert on crt_topic_groups ( ref_certification );

-- --------------------------------------------------------
-- CRT_TOPICS
--
-- Stores: com.interact.sas.crt.data.CertificationTopic
-- --------------------------------------------------------
create table crt_topics
(
    id                    int                 not null,
    ref_certification     int                 not null,    -- References: crt_certifications.id
    ref_options           int                 not null,    -- References: crt_options.id
    type                  int                 not null,    -- See: com.interact.sas.crt.data.CertificationTopic.TYPE
    fl_hidden             tinyint             not null,
    required              tinyint             not null,
    fl_report             smallint            not null,
    score                 double              not null,
    classification        varchar(20)         not null,
    mnemonic              varchar(40),
    name                  varchar(240)        not null,
    info                  text                not null,

    primary key ( id )
);

create index crt_topics_certification       on crt_topics ( ref_certification );
create index crt_topics_option              on crt_topics ( ref_options );
create index crt_topics_mnemonic            on crt_topics ( mnemonic );

-- --------------------------------------------------------
-- CRT_WORDS
--
-- Stores: com.interact.sas.crt.data.CertificationKeyword
-- --------------------------------------------------------
create table crt_words
(
    id                    int                 not null,
    word                  varchar(40)         not null,
    related               varchar(240)        not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- CRT_DEFAULTS
--
-- Stores: com.interact.sas.crt.data.CertificationDefault
-- --------------------------------------------------------
create table crt_defaults
(
    ref_topic            int                  not null,    -- References: crt_topics.id
    token                varchar(10)          not null,
    value                varchar(250)         not null,

    unique ( token, ref_topic )
);

-- --------------------------------------------------------
-- CRT_INDICATORS
--
-- Stores: com.interact.sas.crt.data.
-- --------------------------------------------------------
create table crt_indicators
(
    ref_certification  int       not null,    -- References: crt_certifications.id
    ref_participant    int       not null,    -- References: cmn_users.id
    ref_indicator      int       not null,    -- References: bsc_indicators.id
    ref_grouping       int       not null,    -- References: cmn_groups.id

    unique ( ref_participant, ref_indicator, ref_grouping )
);
create index crt_indicators_certification 	   on crt_indicators ( ref_certification );
create index crt_indicators_participant   	   on crt_indicators ( ref_participant );
create index crt_indicators_indicator    	   on crt_indicators ( ref_indicator );
create index crt_indicators_grouping     	   on crt_indicators ( ref_grouping );

-- --------------------------------------------------------
-- CRT_CONSTRAINTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table crt_constraints
(
    ref_certification       int     not null,    -- References: crt_certifications.id
    ref_topic               int     not null,    -- References: crt_topics.id
    ref_condition           int     not null,    -- References: crt_topics.id
    "action"                int     not null,

    unique ( ref_topic )
);

-- --------------------------------------------------------
-- CRT_CONSTRAINT_OPTIONS
--
-- Stores: com.interact.sas.crt.data.ConstraintOption
-- --------------------------------------------------------
create table crt_constraint_options
(
    ref_topic           int     not null,    -- References: crt_topics.id
    ref_option          int     not null,    -- References: crt_options.id

    unique ( ref_topic, ref_option )
);