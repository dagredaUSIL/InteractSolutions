-- -----------------------------------------------------------------------------
--
-- Module:   MED
--
-- Schema:   80.1
--
-- Revision: $Revision: 103773 $
--
-- Date:     $Date: 2012-02-27 17:02:23 -0300 (Seg, 27 Fev 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-cmn.sql $
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------


-- -----------------------------------------------------------------------
-- MED_TELECONFERENCE_ROOMS
--
-- Stores: com.interact.sas.web.zk.teleconference.data.TeleconferenceRoom
-- -----------------------------------------------------------------------
create table med_teleconference_rooms
(
    id                   int          not null,
    ref_participant_team int          not null,    -- References: cmn_users.id
    ref_moderator_team   int          not null,    -- References: cmn_users.id
    ref_banned_team      int          not null,    -- References: cmn_users.id
    ref_appointment      int          not null,    -- References: cmn_appointments.id
    type                 int          not null,
    state                int          not null,
    private              tinyint      not null,
    dt_start             datetime     null,
    dt_end               datetime         null,
    name                 varchar(120) not null,
    description          text         not null,

    primary key (id)
);
create index med_teleconf_rooms_part_team   on med_teleconference_rooms(ref_participant_team);
create index med_teleconf_rooms_mod_team    on med_teleconference_rooms(ref_moderator_team);
create index med_teleconf_rooms_bann_team   on med_teleconference_rooms(ref_banned_team);
create index med_teleconf_rooms_appointment on med_teleconference_rooms(ref_appointment);

-- --------------------------------------------------------------------------
-- MED_TELECONFERENCE_MESSAGES
--
-- Stores: com.interact.sas.web.zk.teleconference.data.TeleconferenceMessage
-- --------------------------------------------------------------------------
create table med_teleconference_messages
(
    id       int      not null,
    ref_room int      not null,    -- References: med_teleconference_rooms.id
    ref_user int      not null,    -- References: cmn_users.id
    dt_send  datetime not null,
    content  text     not null,

    primary key (id)
);
create index med_teleconf_messages_room on med_teleconference_messages(ref_room);
create index med_teleconf_messages_user on med_teleconference_messages(ref_user);

-- --------------------------------------------------------------------------------
-- MED_TELECONFERENCE_READINGS
--
-- Stores: com.interact.sas.web.zk.teleconference.data.TeleconferenceMessageReading
-- --------------------------------------------------------------------------------
create table med_teleconference_readings
(
    ref_message int      not null,    -- References: med_teleconference_messages
    ref_user    int      not null,    -- References: cmn_users.id
    dt_read     datetime not null,

    unique (ref_message, ref_user)
);
create index med_teleconf_readings_message on med_teleconference_readings (ref_message);