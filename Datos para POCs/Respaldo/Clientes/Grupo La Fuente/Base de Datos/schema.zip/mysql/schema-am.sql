-- ----------------------------------------------------------------------------
--
-- Module:   AM
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-bi.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- AM_ANALYTICS
--
-- Stores: com.interact.sas.am.data.Analytics
-- --------------------------------------------------------
create table am_analytics
(
    id            int          not null,
    ref_folder    int          not null,    -- References: am_analytics_folders.id
    ref_owner     int          not null,    -- References: cmn_users.id
    ref_team      int          not null,    -- References: cmn_groups.id
    ref_workspace int          not null,    -- References: am_workspaces.id
    ref_model     int          not null,    -- References: am_models.id
    ref_rule      int          null,        -- References: brm_methods.id
    type          int          not null,    -- See: com.interact.sas.am.data.Analytics.TYPES
    state         int          not null,    -- See: com.interact.sas.am.data.Analytics.STATES
	restriction   int          not null,
    name          varchar(250) not null,
    source        varchar(250) not null,
    info          text         not null,
    
	primary key (id)
);
create index am_analytics_folder    on am_analytics( ref_folder );
create index am_analytics_owner     on am_analytics( ref_owner );
create index am_analytics_team      on am_analytics( ref_team );
create index am_analytics_workspace on am_analytics( ref_workspace );
create index am_analytics_model     on am_analytics( ref_model );
create index am_analytics_rule      on am_analytics( ref_rule );

-- --------------------------------------------------------
-- AM_ANALYTICS_FOLDERS
--
-- Stores: com.interact.sas.am.data.AnalyticsFolder
-- --------------------------------------------------------
create table am_analytics_folders
(
    id          int          not null,
    ref_parent  int          not null,    -- References: am_analytics_folders.id
    ref_owner   int          not null,    -- References: cmn_users.id
    ref_team    int          not null,    -- References: cmn_groups.id
    ref_model   int          not null,    -- References: am_models.id
    restriction int          not null,
    name        varchar(250) not null,
    info        text         not null,
    
	primary key (id)
);
create index am_analytics_folders_parent on am_analytics_folders( ref_parent );
create index am_analytics_folders_owner  on am_analytics_folders( ref_owner );
create index am_analytics_folders_team   on am_analytics_folders( ref_team );
create index am_analytics_folders_model  on am_analytics_folders( ref_model );

-- --------------------------------------------------------
-- AM_WORKSPACES
--
-- Stores: com.interact.sas.am.data.Workspace
-- --------------------------------------------------------
create table am_workspaces
(
    id           int          not null,
    ref_owner    int          not null,    -- References: cmn_users.id
    name         varchar(250) not null,
    client_id    varchar(250) not null,
    workspace_id varchar(250) not null,
    username     varchar(250) not null,
    password     varchar(250) not null,

    primary key (id)
);
create index am_workspaces_owner on am_workspaces( ref_owner );


-- --------------------------------------------------------
-- AM_MODELS
--
-- Stores: com.interact.sas.am.data.Model
-- --------------------------------------------------------
create table am_models 
(
    id          int         not null,
    ref_owner   int         not null,
    ref_team    int         not null,
    restriction int         not null,
    name        varchar(80) not null,    
    info        text        not null,

    primary key (id)
);
create index am_models_owner on am_models( ref_owner );
create index am_models_team  on am_models( ref_team );