-- ----------------------------------------------------------------------------
--
-- Module:   VFS
--
-- Schema:   80.1
--
-- Revision: $Revision: 96540 $
--
-- Date:     $Date: 2011-09-27 09:26:18 -0300 (Ter, 27 Set 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-vfs.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- VFS_FOLDERS
--
-- Stores: com.interact.sas.cmn.fm.FolderItem
-- --------------------------------------------------------
create table vfs_folders
(
    id                           int              not null,
    ref_parent                   int              not null,    -- References: vfs_folders.id
    ref_owner                    int              not null,    -- References: cmn_users.id
    ref_team                     int              not null,    -- References: cmn_groups.id
    restriction                  int              not null,
    ts_created                   timestamp        null,
    name                         varchar(250)     not null,
    info                         text             not null,
    
    primary key  ( id )
);

create index vfs_folders_restriction on vfs_folders ( restriction );
create index vfs_folders_team        on vfs_folders ( ref_team );

-- --------------------------------------------------------
-- VFS_FILES
--
-- Stores: com.interact.sas.cmn.fm.FileItem
-- --------------------------------------------------------
create table vfs_files 
(
    id                          int                 not null,
    ref_folder                  int                 not null,    -- References: vfs_folders.id
    ref_owner                   int                 not null,    -- References: cmn_users.id
    ref_model                   int                 not null,    -- References: bsc_models.id
    ref_team                    int                 not null,    -- References: cmn_groups.id
    restriction                 int                 not null,
    family                      smallint            not null,
    dt_created                  date                not null,
    name                        varchar(250)        not null,
    info                        text                not null,
    
    primary key  ( id )
);

create index vfs_files_restriction on vfs_files ( restriction );

-- --------------------------------------------------------
-- VFS_PREVIEWS
--
-- Stores: N/A
-- --------------------------------------------------------
create table vfs_previews 
(
    id     int     not null,
    data   text    not null,

    primary key  ( id )
);

-- --------------------------------------------------------
-- VFS_ROOTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table vfs_roots
(
   id            int         not null,
   ref_source    int         not null,    -- References: source item id
   family        smallint    not null,
   scope         smallint    not null,

   primary key  ( id ),
   unique ( ref_source, family, scope )
);

-- --------------------------------------------------------
-- VFS_RECENT_FILES
--
-- Stores: N/A
-- --------------------------------------------------------
create table vfs_recent_files
(
    ref_user     int          not null,    -- References: cmn_users.id
    ref_file     int          not null,    -- References: vfs_files.id
    dt_access    timestamp    not null,

    unique ( ref_user, ref_file )
);
