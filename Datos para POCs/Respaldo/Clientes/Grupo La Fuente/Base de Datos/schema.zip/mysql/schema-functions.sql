

-- --------------------------------------------------------
-- Procedure sa_import
-- --------------------------------------------------------
-- RODAR NO CONSOLE DO MYSQL

delimiter $$
create procedure sa_import( mnemonic_arg varchar(40),
                            competence_arg datetime,
                            value_arg double,
                            origin_arg varchar(20) )
begin
    delete from dat_imports where mnemonic = mnemonic_arg and competence = competence_arg;
    insert into dat_imports ( mnemonic, competence, value, origin ) values ( mnemonic_arg, competence_arg, value_arg, origin_arg );
end
$$
delimiter ;