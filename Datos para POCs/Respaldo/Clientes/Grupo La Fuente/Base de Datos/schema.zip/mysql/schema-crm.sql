-- ----------------------------------------------------------------------------
--
-- Module:   CRM
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-crm.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- CRM_COUNTRIES
--
-- Stores: com.interact.sas.crm.data.Country
-- -----------------------------------------------------------------------------
create table crm_countries
(
    id                   int             not null,
    acronym              varchar(2)      not null,
    currency             varchar(3)      not null,
    language             varchar(80)     not null,
    name                 varchar(160)    not null,
    
    primary key ( id )
);
create index ix_crm_countries_name on crm_countries ( name );

-- -----------------------------------------------------------------------------
-- CRM_STATES
--
-- Stores: com.interact.sas.crm.data.State
-- -----------------------------------------------------------------------------
create table crm_states 
(
    id                   int             not null,
    ref_country          int             not null,    -- References: crm_countries.id
    acronym              varchar(8)      not null,
    name                 varchar(160)    not null,
    
    primary key ( id )
);
create index ix_crm_state_name on crm_states ( name );

-- -----------------------------------------------------------------------------
-- CRM_CITIES
--
-- Stores: com.interact.sas.crm.data.City
-- -----------------------------------------------------------------------------
create table crm_cities
(
    id                   int             not null,
    ref_state            int             not null,    -- References: crm_states.id
    name                 varchar(160)    not null,
    
    primary key ( id ),
    unique ( ref_state, name )
 );
create index ix_crm_cities_name on crm_cities ( name );

-- -----------------------------------------------------------------------------
-- CRM_REGIONS
--
-- Stores: com.interact.sas.crm.data.Region
-- -----------------------------------------------------------------------------
create table crm_regions
(
    id                   int           not null,
    ref_state            int           not null,    -- References: crm_states.id
    name                 varchar(80)   not null,
    
    primary key ( id )
 );

-- -----------------------------------------------------------------------------
-- CRM_ADDRESSES
--
-- Stores: com.interact.sas.crm.data.Address
-- -----------------------------------------------------------------------------
create table crm_addresses
(
    id                   int             not null,
    ref_account          int             not null,    -- References: crm_accounts.id
    ref_city             int             not null,    -- References: crm_cities.id
    ref_region           int             not null,    -- References: crm_regions.id
    zip                  varchar(10)     not null,
    label                varchar(40)     not null,
    domain               varchar(64)     not null,
    address              varchar(160)    not null,
    complement           varchar(160)    not null,
    neighbourhood        varchar(160)    not null,

    primary key ( id ),
    unique ( ref_account, label )
 );
create index crm_addresses_address on crm_addresses ( address );
create index crm_addresses_account on crm_addresses ( ref_account );

-- -----------------------------------------------------------------------------
-- CRM_PHONES
--
-- Stores: com.interact.sas.crm.data.Phone
-- -----------------------------------------------------------------------------
create table crm_phones
(
    id                   int             not null,
    ref_source           int             not null,    -- References: item source id
    family               int             not null,    -- See: com.interact.sas.crm.data.Phone.FAMILY
    type                 smallint        not null,
    "number"             varchar(40)     not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_IDENTITIES
--
-- Stores: com.interact.sas.crm.data.Identity
-- -----------------------------------------------------------------------------
create table crm_identities
(
    id                   int             not null,
    ref_country          int             not null,    -- References: crm_countries.id
    name                 varchar(160)    not null,
    mask                 varchar(40)     not null,

    primary key ( id )
);
create index ix_crm_identities_name on crm_identities ( name );

-- -----------------------------------------------------------------------------
-- CRM_IDENTITY_ITEMS
--
-- Stores: com.interact.sas.crm.data.IdentityItem
-- -----------------------------------------------------------------------------
create table crm_identity_items
(
    id                   int             not null,
    ref_identity         int             not null,    -- References: crm_identities.id
    ref_source           int             not null,    -- References: item source id
    family               int             not null,
    "number"             varchar(40)     not null,

    primary key ( id ),
    unique ( ref_identity, "number" )
);
create index crm_identity_items_source on crm_identity_items ( ref_source );
create index crm_identity_items_family on crm_identity_items ( family );

-- -----------------------------------------------------------------------------
-- CRM_NETWORKS
--
-- Stores: com.interact.sas.crm.data.Network
-- -----------------------------------------------------------------------------
create table crm_networks
(
    id                   int             not null,
    name                 varchar(80)     not null,
    domain               varchar(64)     not null,
    
    primary key ( id ),
    unique ( name )
);

-- -----------------------------------------------------------------------------
-- CRM_NETWORK_ITEMS
--
-- Stores: com.interact.sas.crm.data.NetworkItem
-- -----------------------------------------------------------------------------
create table crm_network_items
(
    id                   int             not null,
    ref_source           int             not null,    -- References: item source id
    ref_network          int             not null,    -- References: crm_networks.id
    family               int             not null,
    value                varchar(250)    not null,

    primary key ( id )
);
create index crm_network_items_source on crm_network_items ( ref_source );
create index crm_network_items_family on crm_network_items ( family );

-- -----------------------------------------------------------------------------
-- CRM_STATUS
--
-- Stores: N/A
-- -----------------------------------------------------------------------------
create table crm_status
(
    id                   int             not null,
    seqno                int             not null,
    is_closed            smallint        not null,
    name                 varchar(80)     not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_ACCOUNTS
--
-- Stores: com.interact.sas.crm.data.Account
-- -----------------------------------------------------------------------------
create table crm_accounts
(
    id                   int              not null,
    ref_creator          int              not null,    -- References: cmn_users.id
    ref_owner            int              not null,    -- References: cmn_users.id
    ref_unit             int              not null,    -- References: cmn_units.id
    ref_origin           int              not null,    -- References: crm_classifications.id
    ref_rating           int              not null,    -- References: crm_classifications.id
    ref_segment          int              not null,    -- References: crm_classifications.id
    ref_tags             int              not null,    -- References: cmn_tag_kinds.id
    category             int              not null,
    num_employees        int              not null,
    state                smallint         not null,    -- See: com.interact.sas.crm.data.Account.STATE
    revenue_amount       double precision not null,
    dt_created           date             not null,
    currency             varchar(3)       not null,
    revenue_source       varchar(160)     not null,
    company_name         varchar(160)     not null,
    trading_name         varchar(160)     not null,
    group_name           varchar(160)     not null,
    info                 text             not null,

    primary key ( id )
);
create index ix_crm_accounts_company_name on crm_accounts ( company_name );
create index ix_crm_accounts_trading_name on crm_accounts ( trading_name );
create index crm_accounts_tags            on crm_accounts ( ref_tags );
create index crm_accounts_unit            on crm_accounts ( ref_unit );
create index crm_accounts_state           on crm_accounts ( state );

-- -----------------------------------------------------------------------------
-- CRM_ACCOUNT_CERTIFICATIONS
--
-- Stores: com.interact.sas.crm.data.Certification
-- -----------------------------------------------------------------------------
create table crm_account_certifications
(
    id                   int             not null,
    ref_account          int             not null,    -- References: crm_accounts.id
    name                 varchar(160)    not null,
    info                 text   not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_OPPORTUNITY_ATTACHMENTS
--
-- Stores: com.interact.sas.crm.data.OpportunityAttachment
-- -----------------------------------------------------------------------------
create table crm_opportunity_attachments
(
    id                   int             not null,
    ref_opportunity      int             not null,    -- References: crm_opportunities.id
    ref_classification   int             not null,    -- References: cmn_classifications.id
    fileid               int             not null,
    revision             int             not null,
    file_name            varchar(160)    not null,
    dt_created           date            not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_ITEM_TYPE
--
-- Stores: com.interact.sas.crm.data.ItemType
-- -----------------------------------------------------------------------------
create table crm_item_types
(
    id                   int             not null,
    ref_classification   int             not null,    -- References: cmn_classifications
    name                 varchar(160)    not null,
    unit                 varchar(40)     not null,

    primary key ( id )
);
create index ix_crm_item_types_name on crm_item_types ( name );
-- -----------------------------------------------------------------------------
-- CRM_OPPORTUNITY_ITEMS
--
-- Stores: com.interact.sas.crm.data.OpportunityItem
-- -----------------------------------------------------------------------------
create table crm_opportunity_items
(
    id                   int              not null,
    ref_opportunity      int              not null,    -- References: crm_opportunities.id
    ref_type             int              not null,    -- References: crm_classifications.id
    quantity             double precision not null,
    value_unit           double precision not null,
    value_total          double precision not null,
    unit                 varchar(40)      not null,
    name                 varchar(160)     not null,
    remark               varchar(160)     not null,
    
    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_OPPORTUNITY_ITEMS
--
-- Stores: com.interact.sas.crm.data.Network
-- -----------------------------------------------------------------------------
create table crm_opportunities
(
    id                       int             not null,
    ref_account              int             not null,    -- References: crm_accounts.id
    ref_contact              int             not null,    -- References: crm_contacts.id
    ref_unit                 int             not null,    -- References: cmn_units.id
    ref_owner                int             not null,    -- References: cmn_users.id
    ref_origin               int             not null,    -- References: crm_classifications.id
    ref_status               int             not null,    -- References: crm_status.id
    ref_result_reason        int             not null,    -- References: crm_classifications.id
    ref_accept_attachment    int             not null,    -- References: crm_opportunity_attachments.id
    ref_validate_by          int             not null,    -- References: cmn_users.id
    probability              int             not null,
    value_total              double          not null,
    value_discount           double          not null,
    dt_estimated             date            null,
    dt_closed                date            null,
    dt_accepted              date            null,
    dt_validated             date            null,
    dt_created               date            not null,
    name                     varchar(160)    not null,
    info                     text            not null,

    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_STATUS_REPORTS
--
-- Stores: com.interact.sas.crm.data.StatusReport
-- -----------------------------------------------------------------------------
create table crm_status_reports
(
    id                   int                 not null,
    ref_account          int                 not null,    -- References: crm_accounts.id
    ref_opportunity      int                 not null,    -- References: crm_opportunities.id
    ref_state            int                 not null,    -- References: crm_status.id
    ref_acknowledged_by  int                 not null,    -- References: cmn_users.id
    ref_author           int                 not null,    -- References: cmn_users.id
    classification       int                 not null,
    probability          int                 not null,
    value_total          double              not null,
    value_discount       double              not null,
    dt_created           date                not null,
    dt_acknowledged      date                null,
    dt_estimated         date                null,
    info                 text                not null,

    primary key ( id )
 );

-- -----------------------------------------------------------------------------
-- CRM_OPPORTUNITY_MAPPINGS
--
-- Stores: com.interact.sas.crm.data.OpportunityMapping
-- -----------------------------------------------------------------------------
create table crm_opportunity_mappings
(
    ref_opportunity      int             not null,    -- References: crm_opportunities.id
    ref_classification   int             not null,    -- References: crm_classifications.id
    
    unique ( ref_opportunity, ref_classification )
);

-- -----------------------------------------------------------------------------
-- CRM_SUBSCRIBERS
--
-- Stores: com.interact.sas.crm.data.Subscriber
-- -----------------------------------------------------------------------------
create table crm_subscribers
(
    id                   int             not null,
    ref_source           int             not null,    -- References: item source id
    family               smallint        not null,    -- See: com.interact.sas.crm.data.Subscriber.FAMILY
    state                tinyint         not null,    -- See: com.interact.sas.crm.data.Subscriber.STATE
    token                varchar(60)     not null,
    name                 varchar(160)    not null,
    email                varchar(160)    not null,

    primary key ( id ),
    unique ( email )
);

-- -----------------------------------------------------------------------------
-- CRM_CHANNELS
--
-- Stores: com.interact.sas.crm.data.Channel
-- -----------------------------------------------------------------------------
create table crm_channels
(
    id                   int             not null,
    mnemonic             varchar(40)     not null,
    domain               varchar(40)     not null,
    token                varchar(60)     not null,
    name                 varchar(160)    not null,
    
    primary key ( id )
);

-- -----------------------------------------------------------------------------
-- CRM_SUBSCRIPTIONS
--
-- Stores: com.interact.sas.crm.data.Subscription
-- -----------------------------------------------------------------------------
create table crm_subscriptions
(
    ref_subscriber       int             not null,    -- References: crm_subscribers.id
    ref_channel          int             not null,    -- References: crm_channels.id
    state                smallint        not null,    -- See: com.interact.sas.crm.data.Subscription.STATE
    
    unique ( ref_subscriber, ref_channel )
);

-- -----------------------------------------------------------------------------
-- CRM_PUBLICATIONS
--
-- Stores: com.interact.sas.crm.data.Publication
-- -----------------------------------------------------------------------------
create table crm_publications
(
    id                   int             not null,
    ref_owner            int             not null,    -- References: cmn_users.id
    ref_team             int             null,        -- References: cmn_groups.id
    ref_approver         int             null,        -- References: cmn_users.id
    num_attempts         int             not null,
    num_interval         int             null,
    num_published        int             not null,
    num_tracked          int             not null,
    num_recipients       int             not null,
    state                tinyint         not null,    -- See: com.interact.sas.crm.data.Publication.STATES 
    stage                tinyint         not null,
    batch                smallint        not null,
    ts_published         timestamp       null,
    ts_next              timestamp       null,
    ts_result            timestamp       null,
    tm_resend            varchar(5)      null,
    token                varchar(60)     not null,
    subject              varchar(100)    null,
    name                 varchar(160)    not null,    
    url                  varchar(250)    not null,
    info                 text            null,

    primary key ( id )
);
create index ix_crm_publications_state    on crm_publications ( state );
create index ix_crm_publications_owner    on crm_publications ( ref_owner );
create index ix_crm_publications_team     on crm_publications ( ref_team );
create index ix_crm_publications_approver on crm_publications ( ref_approver );
create index ix_crm_publications_stage    on crm_publications ( stage );

-- -----------------------------------------------------------------------------
-- CRM_MAILINGS
--
-- Stores: com.interact.sas.crm.data.Mailing
-- -----------------------------------------------------------------------------
create table crm_mailings
(
    ref_publication      int             not null,    -- References: crm_publications.id
    ref_subscriber       int             not null,    -- References: cmn_users.id
    ref_channel          int             not null,    -- References: crm_channels.id
    num_tracked          int             not null,
    num_published        int             not null,
    batch                smallint        not null,
    state                smallint        not null,    -- See: com.interact.sas.crm.data.Mailing.STATE
    type                 smallint        not null,    -- See: com.interact.sas.crm.data.Mailing.TYPE
    ts_tracked           timestamp,
    ts_processed         timestamp       not null,        

    unique ( ref_publication, ref_subscriber, batch )
);

create index ix_crm_mailings_channel on crm_mailings ( ref_channel );

-- -----------------------------------------------------
-- CRM_CONTACTS
--
-- Stores: com.interact.sas.crm.data.Contact
-- -----------------------------------------------------
create table crm_contacts
(
    id                   int             not null,
    ref_account          int             not null,   -- References: crm_accounts.id
    ref_influence        int             not null,   -- References: crm_in
    ref_position         int             not null,   -- References: crm_classifications.id
    ref_chief            int             not null,   -- References: crm_contacts.id
    dt_birth             date            null,
    name                 varchar(160)    not null,
    department           varchar(160)    not null,
    "function"           varchar(160)    not null,
    
    primary key ( id )
 );
create index ix_crm_contacts_name       on crm_contacts ( name );
create index ix_crm_contacts_department on crm_contacts ( department );
create index ix_crm_contacts_function   on crm_contacts ( function );

-- -----------------------------------------------------------------------------
-- CRM_CLASSIFICATIONS
--
-- Stores: com.interact.sas.crm.data.Classification
-- -----------------------------------------------------------------------------
create table crm_classifications
(
    id                   int                 not null,
    seqno                int                 not null,
    family               smallint            not null,    -- See: com.interact.sas.crm.data.Classification.FAMILY
    domain               varchar(80)         not null,
    name                 varchar(160)        not null,
    info                 text                not null,

    primary key ( id )
);
create index ix_crm_classifications_name on crm_classifications ( family, name );

-- -----------------------------------------------------------------------------
-- CRM_ACTIVITIES
--
-- Stores: com.interact.sas.crm.data.Activity
-- -----------------------------------------------------------------------------
create table crm_activities 
(
    id                        int           not null,
    ref_user                  int           not null,    -- References: cmn_users.id
    ref_account               int           not null,    -- References: crm_accounts.id
    ref_opportunity           int           not null,    -- References: crm_opportunities.id
    ref_classification_type   int           not null,    -- References: crm_classifications.id
    ref_classification_nature int           null,        -- References: crm_classifications.id
    status                    smallint      not null,
    result                    smallint      not null,
    value_investment          double        null,
    dt_start                  date          null,
    dt_end                    date          null,
    hr_start                  varchar(5)    not null,
    hr_end                    varchar(5)    not null,
    subject                   varchar(80)   not null,
    place                     varchar(80)   not null,
    info                      text          not null,

    Primary key ( id )
 );

-- --------------------------------------------------------
-- CRM_TRACKINGS
--
-- Stores: com.interact.sas.crm.data.Tracking
-- --------------------------------------------------------
create table crm_trackings
( 
    ref_publication int         not null,    -- References: crm_publications.id
    ref_subscriber  int         not null,    -- References: crm_subscribers.id
    ts_tracked      timestamp   not null,
    origin          varchar(80) not null
);
create index ix_crm_trackings_publication on crm_trackings (ref_publication);
create index ix_crm_trackings_subscriber  on crm_trackings (ref_subscriber);
create index ix_crm_trackings_tracked     on crm_trackings (ts_tracked);
create index ix_crm_trackings_mailing     on crm_trackings (ref_publication,ref_subscriber);
create index ix_crm_trackings_origin      on crm_trackings (origin);

-- --------------------------------------------------------
-- CRM_PUBLICATION_CHANNELS
--
-- Stores: com.interact.sas.crm.data.Channel
-- --------------------------------------------------------
create table crm_publication_channels
(
    ref_publication int not null,    -- References: crm_publications.id
    ref_channel     int not null,    -- References: crm_channels.id
    
    unique ( ref_publication, ref_channel )
);