-- ----------------------------------------------------------------------------
--
-- Module:   SOL
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL$
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- SOL_LGPDS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPD
-- -----------------------------------------------------------------------------
create table sol_lgpds
(
    id                int        not null,
    ref_controller    int        not null,    -- References: cmn_users.id
    ref_dpo           int        not null,    -- References: cmn_users.id
    ref_team          int        not null,    -- References: cmn_groups.id
    ref_unit          int        not null,
    restriction       int        not null,
    state             tinyint    not null,
    description       text,
    
    primary key (id)
);
create index sol_lgpds_controller on sol_lgpds (ref_controller);
create index sol_lgpds_dpo        on sol_lgpds (ref_dpo);
create index sol_lgpds_team       on sol_lgpds (ref_team);
create index sol_lgpds_unit       on sol_lgpds (ref_unit);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_DATAS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDData
-- -----------------------------------------------------------------------------
create table sol_lgpd_datas
(
    id             int          not null,
    ref_owner      int          not null,
    state          tinyint      not null,
    classification tinyint      not null, 
    name           varchar(160) not null,
    info           text         null,
    
    primary key (id)
);
create index sol_lgpd_datas_owner on sol_lgpd_datas (ref_owner);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_RISKS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_risks
(
    ref_lgpd      int not null,   -- References: sol_lgpds.id
    ref_risk      int not null,   -- References: orm_risks.id
    ref_structure int not null,   -- References: orm_structure_categories.id
     
    unique(ref_lgpd, ref_risk,ref_structure)
);
create index sol_lgpd_risks_lgpd      on sol_lgpd_risks (ref_lgpd);
create index sol_lgpd_risks_risk      on sol_lgpd_risks (ref_risk);
create index sol_lgpd_risks_structure on sol_lgpd_risks (ref_structure);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_DOCUMENTS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_documents
(
    ref_lgpd     int not null,   -- References: sol_lgpds.id
    ref_document int not null,   -- References: dms_documents.id
 
    unique(ref_lgpd, ref_document)
);
create index sol_lgpd_documents_lgpd     on sol_lgpd_documents (ref_lgpd);
create index sol_lgpd_documents_document on sol_lgpd_documents (ref_document);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_REPORTS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDStatusReport
-- -----------------------------------------------------------------------------
create table sol_lgpd_reports
(
    id               int       not null,
    ref_lgpd         int       not null,   -- References: sol_lgpds.id
    ref_owner        int       not null,   -- References: cmn_users.id
    classification   int       not null,
    state            tinyint   not null, 
    type             tinyint   not null,
    dt_created       timestamp not null,
    dt_start         timestamp not null,
    dt_end           timestamp not null,
    dt_finished      timestamp,
    info             text,
    
    primary key (id)
);
create index sol_lgpd_reports_lgpd  on sol_lgpd_reports (ref_lgpd);
create index sol_lgpd_reports_owner on sol_lgpd_reports (ref_owner);


-- -----------------------------------------------------------------------------
-- SOL_LGPD_FORMS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_forms
(
    ref_lgpd            int not null,   -- References: sol_lgpds.id
    ref_occurrence_type int not null,   -- References: qms_types.id
    
    unique(ref_lgpd, ref_occurrence_type)
);
create index sol_lgpd_forms_lgpd on sol_lgpd_forms (ref_lgpd);
create index sol_lgpd_forms_occurrence_type on sol_lgpd_forms (ref_occurrence_type);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_FORM_CONFIGS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_form_configs
(
    ref_lgpd            int     not null,   -- References: sol_lgpds.id
    ref_report          int     not null,   -- References: sol_lgpd_reports.id
    ref_occurrence_type int     not null,   -- References: qms_types.id
    show_type           tinyint not null,
    
    unique (ref_lgpd, ref_report, ref_occurrence_type)
);
create index sol_lgpd_form_configs_lgpd     on sol_lgpd_form_configs (ref_lgpd);
create index sol_lgpd_form_configs_report   on sol_lgpd_form_configs (ref_report);
create index sol_lgpd_form_configs_occ_type on sol_lgpd_form_configs (ref_occurrence_type);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_REPORT_CONFIGS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDReportConfigWrapper
-- -----------------------------------------------------------------------------
create table sol_lgpd_report_configs
(
    id            int         not null,
    ref_lgpd      int         not null,   -- References: sol_lgpds.id
    ref_report    int         not null,   -- References: sol_lgpd_reports.id
    periodicity   tinyint     not null,
    consolidation tinyint     not null,
    dt_start      date,
    options       varchar(32) not null,
    
    primary key(id)
);
create index sol_lgpd_report_configs_lgpd   on sol_lgpd_report_configs (ref_lgpd);
create index sol_lgpd_report_configs_report on sol_lgpd_report_configs (ref_report);


-- -----------------------------------------------------------------------------
-- SOL_LGPD_DATA_MAPPINGS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_data_mappings
(
    ref_data       int null,        -- References: sol_lgpd_datas.id
    ref_lgpd       int null,        -- References: sol_lgpds.id
    ref_data_group int not null    -- References:sol_lgpd_data_groups.id
);
create index sol_lgpd_data_mappings_data  on sol_lgpd_data_mappings (ref_data);
create index sol_lgpd_data_mappings_lgpd  on sol_lgpd_data_mappings (ref_lgpd);
create index sol_lgpd_data_mappings_group on sol_lgpd_data_mappings( ref_data_group );

-- -----------------------------------------------------------------------------
-- SOL_LGPD_HANDLING_FORMS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDHandlingForm
-- -----------------------------------------------------------------------------
create table sol_lgpd_handling_forms
(
    id           int          not null,
    ref_owner    int          not null, -- References: cmn_users.id
    ref_team     int          not null, -- References: cmn_groups.id
    ref_category int          not null, -- References: cmn_categories.id
    state        tinyint not null,
    name         varchar(160) not null,
    dt_created   date         not null,
    info         text,

    primary key(id)
);
create index sol_lgpd_handling_forms_owner on sol_lgpd_handling_forms (ref_owner);
create index sol_lgpd_handling_forms_team  on sol_lgpd_handling_forms (ref_team);
create index sol_lgpd_handling_forms_cat   on sol_lgpd_handling_forms (ref_category);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_HANDLING_FORM_FIELDS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDHandlingFormField
-- -----------------------------------------------------------------------------
create table sol_lgpd_handling_form_fields
(
    id                int          not null,
    ref_handling_form int          not null,    -- References sol_lgpd_handling_forms.id
    ref_option        int          not null,    -- References sol_lgpd_options.id
    position          int          not null,
    type              tinyint      not null,
    options           varchar(32)  not null,
    name              varchar(160) not null, 
    
    primary key(id)
);
create index sol_lgpd_hand_form_f_hand_form on sol_lgpd_handling_form_fields (ref_handling_form);
create index sol_lgpd_hand_form_f_opt       on sol_lgpd_handling_form_fields (ref_option);


-- -----------------------------------------------------------------------------
-- SOL_LGPD_FIELD_MAPPINGS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_field_mappings
(
    ref_field      int   not null, -- References: sol_lgpd_handling_form_fields.id
    ref_lgpd       int   not null, -- References: sol_lgpds.id
    ref_lgpd_data  int   not null, -- References: sol_lgpd_datas.id
    ref_data_group int   not null, -- References: sol_lgpd_data_groups.id
    content        text
);
create index sol_lgpd_field_map_field      on sol_lgpd_field_mappings (ref_field);
create index sol_lgpd_field_map_lgpd       on sol_lgpd_field_mappings (ref_lgpd);
create index sol_lgpd_field_maps_lgpd_data on sol_lgpd_field_mappings (ref_lgpd_data);
create index sol_lgpd_field_maps_group     on sol_lgpd_field_mappings( ref_data_group );

-- -----------------------------------------------------------------------------
-- SOL_LGPD_OPTIONS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDOption
-- -----------------------------------------------------------------------------
create table sol_lgpd_options
(
    id           int          not null,
    ref_category int          not null, -- References: cmn_categories.id
    state        tinyint      not null,
    name         varchar(160) not null,
    info         text         not null,
    
    primary key(id)
);
create index sol_lgpd_options_category on sol_lgpd_options (ref_category);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_OPTION_ITEMS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDOptionItem
-- -----------------------------------------------------------------------------
create table sol_lgpd_option_items
(
    id         int          not null,
    ref_option int          not null, -- References: sol_lgpd_options.id
    position   int          not null,
    state      tinyint      not null,
    value      varchar(250) not null,
    
    primary key(id)
);
create index sol_lgpd_option_items_option on sol_lgpd_option_items (ref_option);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_DATA_GROUPS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDDataGroup
-- -----------------------------------------------------------------------------
create table sol_lgpd_data_groups
(
    id                int          not null,
    ref_owner         int          not null,    -- References: cmn_users.id
    ref_team          int          not null,    -- References: cmn_groups.id
    ref_category      int          not null,    -- References: cmn_categories.id
    ref_handling_form int          not null,    -- References: sol_lgpd_handling_forms.id
    state             tinyint      not null,
    options           varchar(32)  not null,
    name              varchar(160) not null,
    info              text         null,

    primary key ( id )
);
create index sol_lgpd_data_groups_owner    on sol_lgpd_data_groups (ref_owner);
create index sol_lgpd_data_groups_team     on sol_lgpd_data_groups (ref_team);
create index sol_lgpd_data_groups_category on sol_lgpd_data_groups (ref_category);
create index sol_lgpd_data_groups_handling on sol_lgpd_data_groups (ref_handling_form);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_GROUP_MAPPINGS
--
-- Stores: N/D
-- -----------------------------------------------------------------------------
create table sol_lgpd_group_mappings
(
    ref_lgpd       int not null,    -- References: sol_lgpds.id
    ref_data_group int not null,    -- References: sol_lgpd_data_groups.id
    
    unique(ref_lgpd, ref_data_group)
);
create index sol_lgpd_group_mappings_lgpd  on sol_lgpd_group_mappings (ref_lgpd);
create index sol_lgpd_group_mappings_group on sol_lgpd_group_mappings (ref_data_group);

-- -----------------------------------------------------------------------------
-- SOL_LGPD_GROUP_CONFIGS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDReportConfig
-- -----------------------------------------------------------------------------
create table sol_lgpd_group_configs
(
    ref_lgpd        int     not null,    -- References: sol_lgpds.id
    ref_report      int     not null,    -- References: sol_lgpd_reports.id
    ref_data_group  int     not null,    -- References: sol_lgpd_data_groups.id
    show_data_group tinyint not null,

    unique(ref_lgpd, ref_report, ref_data_group)
);
create index sol_lgpd_group_configs_lgpd   on sol_lgpd_group_configs (ref_lgpd);
create index sol_lgpd_group_configs_report on sol_lgpd_group_configs (ref_report);
create index sol_lgpd_group_configs_group  on sol_lgpd_group_configs (ref_data_group);

-- ---------------------------------------------------------
-- SOL_LGPD_ELEMENTS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDElement
-- ---------------------------------------------------------
create table sol_lgpd_elements
(
    id            int not       null,
    ref_category  int not       null,    -- References: cmn_categories.id 
    ref_team      int not       null,    -- References: cmn_groups.id 
    ref_owner     int not       null,    -- References: cmn_users.id
    state         tinyint       not null,
    name          varchar(80)   not null,
    info          varchar(4000) null, 

    primary key (id)
);
create index sol_lgpds_elements_category on sol_lgpd_elements (ref_category);
create index sol_lgpds_elements_team on sol_lgpd_elements (ref_team);
create index sol_lgpds_elements_owner on sol_lgpd_elements (ref_owner);

-- ---------------------------------------------------------
-- SOL_LGPD_ELEMENTS
--
-- Stores: com.interact.sas.solutions.lgpd.data.LGPDConsent
-- ---------------------------------------------------------
create table sol_lgpd_consents
(
    id             int         not null,
    ref_element    int         not null,    -- References: sol_lgpd_element.id
    state          tinyint     not null,
    origin         tinyint     not null, 
    ts_consent     datetime    not null,
    ts_expiration  datetime    null,
    ts_revocation  datetime    null,
    name           varchar(80) null,
    cpf            varchar(80) null,
    email          varchar(80) null,
    ip             varchar(80) null,

    primary key (id)
);
create index sol_lgpd_consents_element on sol_lgpd_consents (ref_element);