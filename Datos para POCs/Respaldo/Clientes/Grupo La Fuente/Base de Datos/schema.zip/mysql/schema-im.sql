-- --------------------------------------------------------
--
-- Module:   IM
--
-- Schema:   80.1
--
-- Revision: $Revision: 100701 $
--
-- Date:     $Date: 2011-12-21 15:01:03 -0200 (Qua, 21 Dez 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-ac.sql $
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- --------------------------------------------------------

-- --------------------------------------------------------
-- IM_INDICATORS
-- 
-- Stores: com.interact.sas.im.data.Indicator
-- --------------------------------------------------------
create table im_indicators
(
    id                   int           not null,
    ref_team             int           not null,    -- References: cmn_groups.id
    ref_owner            int           not null,    -- References: cmn_users.id
    ref_director         int           not null,    -- References: cmn_users.id
    ref_executive        int           not null,    -- References: cmn_users.id
    consolidation_mode   int           not null,
    restriction          int           not null,
    meta_default         double        not null,
    period               smallint      not null,
    mnemonic             varchar(40)   not null,
    formula_kind         varchar(40),
    name                 varchar(255)  not null,
    formula              varchar(4000) not null,
    chart_configurations varchar(4000) not null,
    info                 text          not null,
    
    primary key (id)
);
create index im_indicators_team        on im_indicators( ref_team ); 
create index im_indicators_owner       on im_indicators( ref_owner );
create index im_indicators_director    on im_indicators( ref_director );
create index im_indicators_executive   on im_indicators( ref_executive );
create index im_indicators_restriction on im_indicators( restriction );

-- --------------------------------------------------------
-- IM_INDICATOR_BONDS
-- 
-- Stores: com.interact.sas.im.data.IndicatorBond
-- --------------------------------------------------------
create table im_indicator_bonds
(
    ref_indicator int not null,    -- References: im_indicators.id
    ref_source    int not null,    -- References: source item id
    family        int not null,
    
    primary key (ref_indicator)
);
create index im_indicator_bonds_source on im_indicator_bonds( ref_source );

-- --------------------------------------------------------
-- IM_RESULTS
-- 
-- Stores: com.interact.sas.im.data.IndicatorResult
-- --------------------------------------------------------
create table im_results
(
    id            int      not null,
    ref_indicator int      not null,    -- References: im_indicators.id
    competence    int      not null,
    value         double   not null,
    dt_result     datetime not null,
    
    primary key (id)
);
create index im_results_indicator on im_results( ref_indicator );

-- --------------------------------------------------------
-- IM_METAS
-- 
-- Stores: com.interact.sas.im.data.IndicatorMeta
-- --------------------------------------------------------
create table im_metas
(
    id            int    not null,
    ref_indicator int    not null,    -- References: im_indicators.id
    competence    int    not null,
    value         double not null,
    
    primary key (id)
);
create index im_metas_indicator on im_metas( ref_indicator );

-- --------------------------------------------------------
-- IM_DEPENDENCIES
-- 
-- Stores: N/D
-- --------------------------------------------------------
create table im_dependencies
(
     ref_indicator int      not null,    -- References: im_indicators.id
     ref_source    int      not null,    -- References: source item id
     family        smallint not null,

     unique ( ref_indicator, ref_source, family )
);
create index im_dependencies_indicator on im_dependencies( ref_indicator );
create index im_dependencies_source    on im_dependencies( ref_source );