 -- -----------------------------------------------------------------------------
--
-- Module:   BSC
--
-- Schema:   80.1
--
-- Revision: $Revision: 101730 $
--
-- Date:     $Date: 2012-01-09 15:07:37 -0200 (Seg, 09 Jan 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-bsc.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- BSC_MODELS
--
-- Stores: com.interact.sas.bsc.data.Model
-- --------------------------------------------------------
create table bsc_models
(
    id                    int                not null,
    ref_unit              int                not null,    -- References: cmn_units.id
    ref_acevent           int                not null,    -- References: ac_events.id
    ref_analysis          int                not null,    -- References: ac_ocurrencies.id
    ref_dashboard         int                not null,    -- References: vfs_files.id
    ref_team              int                not null,    -- References: cmn_groups.id
    ref_owner             int                not null,    -- References: cmn_users.id
    ref_director          int                not null,    -- References: cmn_users.id
    ref_executive         int                not null,    -- References: cmn_users.id
    ref_tags              int                not null,    -- References: cmn_tag_kinds.id
    restriction           int                not null,
    analysed_by           tinyint            not null,
    obsolete              smallint           not null,
    locked                smallint           not null,
    weight                double             not null,
    performance           double             not null,
    limit_upper           double             not null,
    limit_match           double             not null,
    limit_lower           double             not null,
    dt_created            date               not null,
    dt_from               date,
    dt_until              date,
    options               varchar(32)        not null,
    mnemonic              varchar(40)        default null,
    organization          varchar(120)       not null,
    name                  varchar(160)       not null,
    info                  text               not null,

    primary key ( id ),
    unique ( name )
);
create index bsc_models_ref_unit      on bsc_models ( ref_unit );
create index bsc_models_acevent       on bsc_models ( ref_acevent );
create index bsc_models_ref_owner     on bsc_models ( ref_owner );
create index bsc_models_ref_director  on bsc_models ( ref_director );
create index bsc_models_ref_executive on bsc_models ( ref_executive );
create index bsc_models_ref_analysis  on bsc_models ( ref_analysis );
create index bsc_models_ref_team      on bsc_models ( ref_team );
create index bsc_models_restriction   on bsc_models ( restriction );
create index bsc_models_mnemonic      on bsc_models ( id, mnemonic );
create index bsc_models_tags          on bsc_models ( ref_tags );

-- --------------------------------------------------------
-- BSC_SCENARIOS
--
-- Stores: com.interact.sas.bsc.data.Scenario
-- --------------------------------------------------------
create table bsc_scenarios
(
    id                int           not null,
    ref_model         int           not null,    -- References: bsc_models.id
    name              varchar(80)   not null,
    info              text          not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- BSC_PERSPECTIVES
--
-- Stores: com.interact.sas.bsc.data.Perspective
-- --------------------------------------------------------
create table bsc_perspectives
(
    id                    int                not null,
    ref_model             int                not null,    -- References: bsc_models.id
    ref_acevent           int                not null,    -- References: ac_events.id
    ref_analysis          int                not null,    -- References: ac_ocurrencies.id
    ref_team              int                not null,    -- References: cmn_groups.id
    ref_owner             int                not null,    -- References: cmn_users.id
    ref_director          int                not null,    -- References: cmn_users.id
    ref_executive         int                not null,    -- References: cmn_users.id
    ref_tags              int                not null,    -- References: cmn_tag_kinds.id
    restriction           int                not null,
    locked                tinyint            not null,
    analysed_by           tinyint            not null,
    seq_no                smallint           not null,
    weight                double             not null,
    performance           double             not null,
    limit_upper           double             not null,
    limit_match           double             not null,
    limit_lower           double             not null,
    mnemonic              varchar(40)        default null,
    name                  varchar(160)       not null,
    info                  text               not null,

    primary key ( id )
);
create index bsc_perspectives_acevent       on bsc_perspectives ( ref_acevent );
create index bsc_perspectives_mnemonic      on bsc_perspectives ( ref_model, mnemonic );
create index bsc_perspectives_ref_owner     on bsc_perspectives ( ref_owner );
create index bsc_perspectives_ref_director  on bsc_perspectives ( ref_director );
create index bsc_perspectives_ref_executive on bsc_perspectives ( ref_executive );
create index bsc_perspectives_ref_analysis  on bsc_perspectives ( ref_analysis );
create index bsc_perspectives_ref_team      on bsc_perspectives ( ref_team );
create index bsc_perspectives_restriction   on bsc_perspectives ( restriction );
create index bsc_perspectives_seq_no        on bsc_perspectives ( seq_no );
create index bsc_perspectives_tags          on bsc_perspectives ( ref_tags );

-- --------------------------------------------------------
-- BSC_OBJECTIVES
--
-- Stores: com.interact.sas.bsc.data.Objective
-- --------------------------------------------------------
create table bsc_objectives
(
    id                    int               not null,
    ref_model             int               not null,    -- References: bsc_models.id
    ref_perspective       int               not null,    -- References: bsc_perspectives.id
    ref_acevent           int               not null,    -- References: ac_events.id
    ref_analysis          int               not null,    -- References: ac_ocurrencies.id
    ref_team              int               not null,    -- References: cmn_groups.id
    ref_owner             int               not null,    -- References: cmn_users.id
    ref_director          int               not null,    -- References: cmn_users.id
    ref_executive         int               not null,    -- References: cmn_users.id
    ref_tags              int               not null,    -- References: cmn_tag_kinds.id
    restriction           int               not null,
    locked                tinyint           not null,
    analysed_by           tinyint           not null,
    seq_no                smallint          not null,
    monitor               smallint          not null,
    layout_x              smallint          not null,
    layout_y              smallint          not null,
    weight                double            not null,
    performance           double            not null,
    limit_upper           double            not null,
    limit_match           double            not null,
    limit_lower           double            not null,
    name                  varchar(160)      not null,
    mnemonic              varchar(40)       default null,
    info                  text              not null,

    primary key ( id )
);
create index bsc_objectives_acevent         on bsc_objectives ( ref_acevent );
create index bsc_objectives_mnemonic        on bsc_objectives ( ref_model, mnemonic );
create index bsc_objectives_ref_owner       on bsc_objectives ( ref_owner );
create index bsc_objectives_ref_director    on bsc_objectives ( ref_director );
create index bsc_objectives_ref_executive   on bsc_objectives ( ref_executive );
create index bsc_objectives_ref_perspective on bsc_objectives ( ref_perspective );
create index bsc_objectives_ref_analysis    on bsc_objectives ( ref_analysis );
create index bsc_objectives_ref_team        on bsc_objectives ( ref_team );
create index bsc_objectives_restriction     on bsc_objectives ( restriction );
create index bsc_objectives_seq_no          on bsc_objectives ( seq_no );
create index bsc_objectives_tags            on bsc_objectives ( ref_tags );

-- --------------------------------------------------------
-- BSC_STRATEGIES
--
-- Stores: com.interact.sas.bsc.data.Strategy
-- --------------------------------------------------------
create table bsc_strategies
(
    id                    int               not null,
    ref_model             int               not null,    -- References: bsc_models.id
    ref_perspective       int               not null,    -- References: bsc_perspectives.id
    ref_objective         int               not null,    -- References: bsc_objectives.id
    ref_acevent           int               not null,    -- References: ac_events.id
    ref_analysis          int               not null,    -- References: ac_ocurrencies.id
    ref_team              int               not null,    -- References: cmn_groups.id
    ref_owner             int               not null,    -- References: cmn_users.id
    ref_director          int               not null,    -- References: cmn_users.id
    ref_executive         int               not null,    -- References: cmn_users.id
    ref_tags              int               not null,    -- References: cmn_tag_kinds.id
    restriction           int               not null,
    locked                tinyint           not null,
    analysed_by           tinyint           not null,
    monitor               smallint          not null,
    seq_no                smallint          not null,
    dt_start              date              default null,
    dt_end                date              default null,
    limit_upper           double            not null,
    limit_match           double            not null,
    limit_lower           double            not null,
    weight                double            not null,
    performance           double            not null,
    name                  varchar(160)      not null,
    mnemonic              varchar(40)       default null,
    info                  text              not null,

    primary key ( id )
);
create index bsc_strategies_acevent         on bsc_strategies ( ref_acevent );
create index bsc_strategies_mnemonic        on bsc_strategies ( ref_model, mnemonic );
create index bsc_strategies_ref_owner       on bsc_strategies ( ref_owner );
create index bsc_strategies_ref_director    on bsc_strategies ( ref_director );
create index bsc_strategies_ref_executive   on bsc_strategies ( ref_executive );
create index bsc_strategies_ref_perspective on bsc_strategies ( ref_perspective );
create index bsc_strategies_ref_objective   on bsc_strategies ( ref_objective );
create index bsc_strategies_ref_analysis    on bsc_strategies ( ref_analysis );
create index bsc_strategies_ref_team        on bsc_strategies ( ref_team );
create index bsc_strategies_restriction     on bsc_strategies ( restriction );
create index bsc_strategies_seq_no          on bsc_strategies ( seq_no );
create index bsc_strategies_tags            on bsc_strategies ( ref_tags );

-- --------------------------------------------------------
-- BSC_INDICATORS
--
-- Stores: com.interact.sas.bsc.data.Indicator
-- --------------------------------------------------------
create table bsc_indicators
(
    id                   int               not null,
    ref_model            int               not null,    -- References: bsc_models.id
    ref_perspective      int               not null,    -- References: bsc_perspectives.id
    ref_objective        int               not null,    -- References: bsc_objectives.id
    ref_strategy         int               not null,    -- References: bsc_strategies.id
    ref_indicator        int               not null,    -- References: bsc_indicators.id
    ref_acevent          int               not null,    -- References: ac_events.id
    ref_analysis         int               not null,    -- References: ac_ocurrencies.id
    ref_compareto        int               not null,    -- References: bsc_indicators.id
    ref_team             int               not null,    -- References: cmn_users.id
    ref_owner            int               not null,    -- References: cmn_users.id
    ref_director         int               not null,    -- References: cmn_users.id
    ref_executive        int               not null,    -- References: cmn_users.id
    ref_tags             int               not null,    -- References: cmn_tag_kinds.id
    ref_fellow_analysis  int,                           -- References: cmn_users.id
    chart_options        int               not null,
    restriction          int               not null,
    ac_reference_period  tinyint           not null,
    ac_history_periods   tinyint           not null,
    locked               tinyint           not null,
    cumulative           tinyint           not null,
    analysed_by          tinyint           not null,
    kind                 tinyint           not null,    
    chart_periods        smallint          not null,
    period               smallint          not null,    -- See: com.interact.sas.bsc.data.Indicator.PERIODS 
    prec                 smallint          not null,
    chart_type           smallint          not null,    -- See: com.interact.sas.bsc.data.Indicator.CHARTS 
    chart_representation smallint          not null,
    chart_disposition    smallint          not null,
    monitor              smallint          not null,
    chart_mode           smallint          not null,
    meta_direction       smallint          not null,
    meta_semaphore       smallint          not null,
    meta_tolerance       smallint          not null,
    state_update         smallint          not null,
    state_performance    smallint          not null,
    tendence             smallint          not null,
    formula_flags        smallint          not null,
    origin               smallint          not null,    -- See: com.interact.sas.bsc.data.Indicator.ORIGINS
    tendence_mode        smallint          not null,
    tendence_history     smallint          not null,
    tendence_shift       smallint          not null,
    history_mode         smallint          not null,
    tendence_sampling    smallint          not null,
    seq_no               smallint          not null,
    family               smallint          not null,    -- See: com.interact.sas.bsc.data.Indicator.FAMILY
    chart_scale          double            not null,
    chart_min            double            not null,
    chart_max            double            not null,
    meta_start           double            not null,
    meta_end             double            not null,
    meta_limit_upper     double            not null,
    meta_limit_match     double            not null,
    meta_limit_lower     double            not null,
    meta                 double            not null,
    result               double            not null,
    benchmark            double            not null,
    performance          double            not null,
    score                double            not null,
    weight               double            not null,
    chart_start_date     date              not null,
    chart_end_date       date              not null,
    meta_start_date      date              default null,
    meta_end_date        date              default null,
    next_update          date              default null,
    last_update          date              default null,
    dt_future            date              default null,
    chart_subtitle       varchar(250)      default null,
    units                varchar(20)       not null,
    mnemonic             varchar(40)       default null,
    chart_font           varchar(50)       null,
    meta_label           varchar(80)       not null,
    result_label         varchar(80)       not null,
    benchmark_label      varchar(80)       not null,
    tendency_label       varchar(80)       not null,
    name                 varchar(200)      not null,
    formula              varchar(4000)     not null,
    chart_configurations text              not null,
    ac_input             text              not null,
    info                 text              not null,


    primary key ( id )
);
create index bsc_indicators_family          on bsc_indicators( family );
create index bsc_indicators_model           on bsc_indicators( ref_model );
create index bsc_indicators_perspective     on bsc_indicators( ref_perspective );
create index bsc_indicators_objective       on bsc_indicators( ref_objective );
create index bsc_indicators_strategy        on bsc_indicators( ref_strategy );
create index bsc_indicators_analysis        on bsc_indicators( ref_analysis );
create index bsc_indicators_acevent         on bsc_indicators( ref_acevent );
create index bsc_indicators_mnemonic        on bsc_indicators( ref_model, mnemonic );
create index bsc_indicators_ref_owner       on bsc_indicators( ref_owner );
create index bsc_indicators_ref_director    on bsc_indicators( ref_director );
create index bsc_indicators_ref_executive   on bsc_indicators( ref_executive );
create index bsc_indicators_ref_indicator   on bsc_indicators( ref_indicator );
create index bsc_indicators_ref_compareto   on bsc_indicators( ref_compareto );
create index bsc_indicators_ref_team        on bsc_indicators( ref_team );
create index bsc_indicators_restriction     on bsc_indicators( restriction );
create index bsc_indicators_seq_no          on bsc_indicators( seq_no );
create index bsc_indicators_tags            on bsc_indicators( ref_tags );
create index bsc_indicators_fellow_analysis on bsc_indicators(ref_fellow_analysis);

-- --------------------------------------------------------
-- BSC_ITEMS
--
-- Stores: com.interact.sas.bsc.data.Item
-- --------------------------------------------------------
create table bsc_items
(
    ref_indicator        int               not null,    -- References: bsc_indicators.id
    competence           int               not null,
    family               smallint          not null,    -- See: com.interact.sas.bsc.data.Item.FAMILY
    ref_indicator_kind   tinyint           not null,    -- References: bsc_indicators.kind
    meta                 double            not null,
    result               double            not null,
    benchmark            double            not null,
    dt_meta              date              not null,
    dt_result            date              default null,
    dt_benchmark         date              null,    

    unique ( family, ref_indicator, dt_meta ),
    unique ( family, ref_indicator, competence )
);
create index bsc_items_indicator      on bsc_items( ref_indicator );
create index bsc_items_competence     on bsc_items( competence );
create index bsc_items_result         on bsc_items( result );
create index bsc_items_indicator_kind on bsc_items( ref_indicator_kind );

-- --------------------------------------------------------
-- BSC_DEPENDENCIES
--
-- Stores: N/A
-- --------------------------------------------------------
create table bsc_dependencies
(
    ref_model      int            not null,    -- References: bsc_models.id
    ref_target     int            not null,    -- References: target item id
    ref_source     int            not null,    -- References: source item id
    family         smallint       not null,

    unique ( ref_model, ref_target, ref_source, family )
);
create index bsc_dependencies_target    on bsc_dependencies( family, ref_target );
create index bsc_dependencies_model     on bsc_dependencies( ref_model );
create index bsc_dependencies_source    on bsc_dependencies( ref_source );

-- --------------------------------------------------------
-- BSC_ACTIONPLANS
--
-- Stores: com.interact.sas.bsc.data.Actionplan
-- --------------------------------------------------------
create table bsc_actionplans
(
    id                   int               not null,
    ref_model            int               not null,    -- References: bsc_models.id
    ref_perspective      int               not null,    -- References: bsc_perspectives.id
    ref_objective        int               not null,    -- References: bsc_objectives.id
    ref_strategy         int               not null,    -- References: bsc_strategies.id
    ref_indicator        int               not null,    -- References: bsc_indicators.id
    ref_acevent          int               not null,    -- References: ac_events.id
    ref_analysis         int               not null,    -- References: ac_ocurrencies.id
    ref_team             int               not null,    -- References: cmn_groups.id
    ref_iniciative       int               not null,    -- References: bsc_iniciatives.id
    ref_owner            int               not null,    -- References: cmn_users.id
    ref_director         int               not null,    -- References: cmn_users.id
    ref_executive        int               not null,    -- References: cmn_users.id
    ref_next_update      int               not null,    -- References: bsc_iniciatives.id
    ref_tags             int               not null,    -- References: cmn_tag_kinds.id
    ref_verificator      int               not null,
    ref_previous         int               not null,
    restriction          int               not null,
    estim_days           int               not null,
    real_days            int               not null,
    effective            tinyint           not null,
    locked               tinyint           not null,
    analysed_by          tinyint           not null,
    family               smallint          not null,    -- See: com.interact.sas.bsc.data.Actionplan.FAMILY
    monitor              smallint          not null,
    state_execution      smallint          not null,
    state_investment     smallint          not null,
    seq_no               smallint          not null,
    investment           double            not null,
    estim_investment     double            not null,
    real_investment      double            not null,
    start_date           date              default null,
    end_date             date              default null,
    estim_start_date     date              default null,
    estim_end_date       date              default null,
    real_start_date      date              default null,
    real_end_date        date              default null,
    dt_next_update       date              default null,
    dt_last_update       date              default null,
    dt_created           date		       default null,
    dt_verify            date              null,
    currency             varchar(4)        not null,
    options              varchar(32)       not null,
    mnemonic             varchar(40)       default null,
    title                varchar(160)      not null,
    protocol             varchar(250)      not null,
    verify_info          text              not null,
    info                 text              not null,

    primary key ( id )
);
create index bsc_actionplans_family         on bsc_actionplans( family );
create index bsc_actionplans_restriction    on bsc_actionplans( restriction );
create index bsc_actionplans_model          on bsc_actionplans( ref_model );
create index bsc_actionplans_perspective    on bsc_actionplans( ref_perspective );
create index bsc_actionplans_objective      on bsc_actionplans( ref_objective );
create index bsc_actionplans_strategy       on bsc_actionplans( ref_strategy );
create index bsc_actionplans_indicator      on bsc_actionplans( ref_indicator );
create index bsc_actionplans_acevent        on bsc_actionplans( ref_acevent );
create index bsc_actionplans_analysed_by1   on bsc_actionplans( analysed_by, ref_owner );
create index bsc_actionplans_analysed_by2   on bsc_actionplans( analysed_by, ref_executive );
create index bsc_actionplans_analysed_by3   on bsc_actionplans( analysed_by, ref_director );
create index bsc_actionplans_mnemonic       on bsc_actionplans( ref_model, mnemonic );
create index bsc_actionplans_ref_owner      on bsc_actionplans( ref_owner );
create index bsc_actionplans_ref_director   on bsc_actionplans( ref_director );
create index bsc_actionplans_ref_executive  on bsc_actionplans( ref_executive );
create index bsc_actionplans_ref_next       on bsc_actionplans( ref_next_update );
create index bsc_actionplans_dt_next        on bsc_actionplans( dt_next_update );
create index bsc_actionplans_dt_last        on bsc_actionplans( dt_last_update );
create index bsc_actionplans_seq_no         on bsc_actionplans( seq_no );
create index ix_bsc_actionplans_analysis    on bsc_actionplans( ref_analysis );
create index ix_bsc_actionplans_ref_ini     on bsc_actionplans(ref_iniciative);
create index bsc_actionplans_tags           on bsc_actionplans( ref_tags );

-- --------------------------------------------------------
-- BSC_INICIATIVES
--
-- Stores: com.interact.sas.bsc.data.Initiative
-- --------------------------------------------------------
create table bsc_iniciatives
(
    id                   int               not null,
    ref_model            int               not null,    -- References: bsc_models.id
    ref_actionplan       int               not null,    -- References: bsc_actionplans.id
    ref_previous         int               not null,    -- References: bsc_iniciatives.id
    ref_delegate         int               not null,    -- References: cmn_users.id
    ref_team             int               not null,    -- References: cmn_groups.id
    ref_owner            int               not null,    -- References: cmn_users.id
    ref_verificator      int               not null,    -- References: cmn_users.id
    progress             tinyint           not null,
    effective            tinyint           not null,    -- See: com.interact.sas.bsc.data.Initiative.EFFECTIVITY
    seq_no               smallint          not null,
    state                smallint          not null,    -- See: com.interact.sas.bsc.data.Initiative.STATES 
    estim_investment     double            not null,
    real_investment      double            not null,
    estim_start_date     date              default null,
    estim_end_date       date              default null,
    real_start_date      date              default null,
    real_end_date        date              default null,
    state_date           date              default null,
    real_verify_date     date              default null,
    location             varchar(80)       not null,
    title                varchar(160)      not null,
    scope                varchar(160)      not null,
    reason               varchar(160)      not null,
    method               varchar(160)      not null,
    verify_info          text              not null,
    instructions         text              not null,
    feedback             text              not null,

    primary key ( id )
);
create index bsc_iniciatives_model           on bsc_iniciatives( ref_model );
create index bsc_iniciatives_actionplan      on bsc_iniciatives( ref_actionplan );
create index bsc_iniciatives_ref_owner       on bsc_iniciatives( ref_owner );
create index bsc_iniciatives_ref_verificator on bsc_iniciatives( ref_verificator );
create index bsc_iniciatives_ref_previous    on bsc_iniciatives( ref_previous );
create index bsc_iniciatives_ref_delegate    on bsc_iniciatives( ref_delegate );
create index bsc_iniciatives_ref_team        on bsc_iniciatives( ref_team );
create index bsc_iniciatives_estim_start     on bsc_iniciatives( estim_start_date );
create index bsc_iniciatives_estim_end       on bsc_iniciatives( estim_end_date );
create index bsc_iniciatives_real_start      on bsc_iniciatives( real_start_date );
create index bsc_iniciatives_real_end        on bsc_iniciatives( real_end_date );

-- --------------------------------------------------------
-- BSC_QUERIES
--
-- Stores: com.interact.sas.bsc.data.Query
-- --------------------------------------------------------
create table bsc_queries
(
    id                int           not null,
    ref_model         int           not null,    -- References: bsc_models.id
    ref_indicator     int           not null,    -- References: bsc_indicators.id
    ref_folder        int           not null,    -- References: bsc_folders.id
    type              smallint      not null,
    "mode"            smallint      not null,
    dt_competence     date          default null,
    dt_execution      datetime      default null,
    dsn               varchar(80)   not null,
    "sql"             text          not null,
    info              text          not null,

    primary key ( id )
);
create index bsc_queries_folder on bsc_queries( ref_folder );

-- --------------------------------------------------------
-- BSC_VAULT
--
-- Stores: N/A
-- --------------------------------------------------------
create table bsc_vault
(
    id           int                not null,
    name         varchar(255)       not null,
    seal         varchar(40)        not null,

    primary key ( id )
);

-- --------------------------------------------------------
-- BSC_THEMES
--
-- Stores: com.interact.sas.bsc.data.StrategicTheme
-- --------------------------------------------------------
create table bsc_themes
(
    id              int           not null,
    ref_model       int           not null,    -- References: bsc_models.id
    state           tinyint       not null,
    color           varchar(7)    not null,
    name            varchar(80)   not null,
    info            text          not null,

    primary key ( id ),
    unique ( ref_model, name )
);

-- --------------------------------------------------------
-- BSC_RELATIONS
--
-- Stores: com.interact.sas.bsc.data.RelationItem
-- --------------------------------------------------------
create table bsc_relations
(
    ref_model        int              not null,    -- References: bsc_models.id
    ref_theme        int              not null,    -- References: bsc_themes.id
    ref_this         int              not null,    -- References: item id
    ref_other        int              not null,    -- References: item id
    strength         double           not null,
    family           smallint         not null,

    unique ( ref_model, ref_theme, family, ref_this, ref_other )
);
create index bsc_relations_theme            on bsc_relations( ref_theme );
create index bsc_relations_this             on bsc_relations( ref_this );
create index bsc_relations_other            on bsc_relations( ref_other );

-- --------------------------------------------------------
-- BSC_CLASSIFICATIONS
--
-- Stores: com.interact.sas.bsc.data.Classification
-- --------------------------------------------------------
create table bsc_classifications
(
    id               int          not null,
    ref_model        int          not null,    -- References: bsc_models.id
    ref_parent       int          not null,    -- References: bsc_classifications.id
    ref_source       int          not null,    -- References: source item id
    family           smallint     not null,    -- See: com.interact.sas.bsc.data.Classification.FAMILY
    type             smallint     not null,    -- See: com.interact.sas.bsc.data.Classification.TYPE
    "number"         varchar(32)  not null,

    primary key ( id )
);
create index bsc_classifications_number     on bsc_classifications( "number" );
create index bsc_classifications_model      on bsc_classifications( ref_model );
create index bsc_classifications_parent     on bsc_classifications( ref_parent );
create index bsc_classifications_source     on bsc_classifications( type, ref_source );

-- --------------------------------------------------------
-- BSC_FOLDERS
--
-- Stores: com.interact.sas.bsc.data.ClassificationFolder
-- --------------------------------------------------------
create table bsc_folders
(
    id              int               not null,
    ref_model       int               not null,    -- References: bsc_models.id
    ref_acevent     int               not null,    -- References: ac_events.id
    ref_analysis    int               not null,    -- References: ac_ocurrencies.id
    ref_team        int               not null,    -- References: cmn_groups.id
    ref_owner       int               not null,    -- References: cmn_users.id
    ref_director    int               not null,    -- References: cmn_users.id
    ref_executive   int               not null,    -- References: cmn_users.id
    restriction     int               not null,
    locked          tinyint           not null,
    analysed_by     tinyint           not null,
    monitor         smallint          not null,
    icon            smallint          not null,
    score           double            not null,
    limit_upper     double            not null,
    limit_match     double            not null,
    limit_lower     double            not null,
    weight          double            not null,
    type            varchar(40)       not null,    -- See: com.interact.sas.bsc.data.ClassificationFolder.TYPES
    mnemonic        varchar(40)       default null,
    name            varchar(120)      not null,
    info            text              not null,



    primary key ( id )
);
create index bsc_folders_mnemonic           on bsc_folders( ref_model, mnemonic );
create index bsc_folders_ref_owner          on bsc_folders( ref_owner );
create index bsc_folders_ref_director       on bsc_folders( ref_director );
create index bsc_folders_ref_executive      on bsc_folders( ref_executive );
create index bsc_folders_ref_acevent        on bsc_folders( ref_acevent );
create index bsc_folders_ref_analysis       on bsc_folders( ref_analysis );
create index bsc_folders_ref_team           on bsc_folders( ref_team );
create index bsc_folders_restriction        on bsc_folders( restriction );


-- -----------------------------------------------------------------------------
-- BSC_CLONES
--
-- Stores: com.interact.sas.bsc.data.EntityClone
-- -----------------------------------------------------------------------------
create table bsc_clones
(
    id              int          not null,
    ref_source      int          not null,    -- References: source item id
    ref_model       int          not null,    -- References: bsc_models.id
    ref_perspective int          not null,    -- References: bsc_perspectives.id
    ref_objective   int          not null,    -- References: bsc_objectives.id
    ref_strategy    int          not null,    -- References: bsc_strategies.id
    ref_indicator   int          not null,    -- References: bsc_indicators.id
    type            smallint     not null,    -- See: com.interact.sas.bsc.data.EntityClone.TYPE
    seq_no          smallint     not null,

    primary key ( id )
);
create index bsc_clones_source              on bsc_clones ( ref_source );
create index bsc_clones_strategy            on bsc_clones ( ref_strategy );
create index bsc_clones_perspective         on bsc_clones ( ref_perspective );
create index bsc_clones_objective           on bsc_clones ( ref_objective );
create index bsc_clones_indicator           on bsc_clones ( ref_indicator );
create index bsc_clones_model               on bsc_clones ( ref_model );
create index bsc_clones_type                on bsc_clones ( type );
create index bsc_clones_seq_no              on bsc_clones ( seq_no );