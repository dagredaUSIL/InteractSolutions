-- -----------------------------------------------------------------------------
--
-- Module:   CLB
--
-- Schema:   80.1
--
-- Revision: $Revision: 88688 $
--
-- Date:     $Date: 2011-05-02 17:45:23 -0300 (Seg, 02 Mai 2011) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-clb.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- CLB_MESSAGES
--
-- Stores: N/A
-- --------------------------------------------------------
create table clb_messages
(
    id              int              not null,
    ref_user        int              not null,    -- References: cmn_users.id
    ref_thread      int              not null,    -- References: clb_messages.id
    ref_reply       int              not null,    -- References: clb_messages.id
    source          int              not null,
    type            smallint         not null,
    family          smallint         not null,
    dt_published    datetime         not null,
    options         varchar(32)      not null,
    subject         varchar(160)     not null,
    body            text             not null,

    primary key ( id )
);
create index clb_messages_user      on clb_messages ( ref_user );
create index clb_messages_published on clb_messages ( dt_published );
create index clb_messages_thread    on clb_messages ( ref_thread );
create index clb_messages_family    on clb_messages ( family );
create index clb_messages_source    on clb_messages ( source );
create index clb_messages_type      on clb_messages ( type );
create index clb_messages_reply     on clb_messages ( ref_reply );

-- --------------------------------------------------------
-- CLB_RECIPIENTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table clb_recipients
(
    ref_message     int              not null,    -- References: clb_messages.id
    ref_user        int              not null,    -- References: cmn_users.id
    dt_received     date             default null,
    "comment"       text             default null,

    unique ( ref_message, ref_user )
);
create index clb_recipients_message  on clb_recipients( ref_message );
create index clb_recipients_user     on clb_recipients( ref_user );
create index clb_recipients_received on clb_recipients( dt_received );