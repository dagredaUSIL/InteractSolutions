	-- ----------------------------------------------------------------------------
--
-- Module:   HRM
--
-- Schema:   80.1
--
-- Revision: $Revision: 104140 $
--
-- Date:     $Date: 2012-03-01 13:49:50 -0300 (Qui, 01 Mar 2012) $
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-hrm.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- ------------------------------------------------------------------------------
-- HRM_QUALIFICATIONS
--
-- Stores: com.interact.sas.hrm.data.Qualification
-- ------------------------------------------------------------------------------
create table hrm_qualifications
(
    id                      int                 not null,
    ref_scale               int                 not null,    -- References: hrm_rating_scales.id
    ref_type_qualification  int                 not null,    -- References: hrm_categories.id
    ref_category            int                 not null,    -- References: hrm_categories.id
    state                   int                 not null,    -- See: com.interact.sas.hrm.data.Qualification.STATE
    "order"                 int                 not null,
    num_qualified           int                 not null,
    num_unqualified         int                 not null,
    classification          tinyint             not null,
    course_provenient       tinyint             not null,
    implicit                tinyint             not null,
    name                    varchar(160)        not null,
    info                    text                not null,

    primary key ( id )
);
create index hrm_qualifications_category   on hrm_qualifications ( ref_category );

-- --------------------------------------------------------
-- HRM_COURSES
--
-- Stores: com.interact.sas.hrm.data.Course
-- --------------------------------------------------------
create table hrm_courses
(
    id                       int                not null,
    ref_serial               int                not null,    -- References: cmn_serials.id
    ref_category             int                not null,    -- References: hrm_categories.id
    ref_owner                int                not null,    -- References: cmn_users.id
    average_vote             int                not null,
    validity_value           int                not null,
    avaliation_mode          smallint           not null,
    offered                  tinyint            not null,
    validity_type            tinyint            not null,
    notify_type              tinyint            not null,
    notify_value             double             not null,
    required_frequency       double             not null,
    duration                 double             not null,
    investment               double             not null,
    start_date               date               default null,
    end_date                 date               default null,
    currency                 varchar(8)         not null,
    institution              varchar(80)        not null,
    location                 varchar(80)        not null,
    professor                varchar(80)        not null,
    name                     varchar(160)       not null,
    info                     text               not null,

    primary key ( id )
);
create index hrm_courses_category on hrm_courses ( ref_category );
create index hrm_courses_serial   on hrm_courses ( ref_serial );
create index hrm_courses_owner    on hrm_courses ( ref_owner );

-- --------------------------------------------------------
-- HRM_MATRICULATIONS
--
-- Stores: com.interact.sas.hrm.data.Matriculation
-- --------------------------------------------------------
create table hrm_matriculations
(
    id                       int                 not null,
    ref_user                 int                 not null,    -- References: cmn_users.id
    ref_course               int                 not null,    -- References: hrm_courses.id
    ref_team                 int                 not null,    -- References: cmn_groups.id
    ref_unit                 int                 not null,    -- References: cmn_units.id
    ref_department           int                 not null,    -- References: cmn_departments.id
    ref_sector               int                 not null,    -- References: cmn_sectors.id
    approved                 tinyint             not null,
    vote                     smallint            not null,    -- See: com.interact.sas.hrm.data.Matriculation.VOTES
    frequency                double              not null,
    duration                 double              not null,
    investment               double              not null,
    dt_start                 date                default null,
    dt_conclusion            date                default null,
    matriculation            varchar(20)         not null,
    serie                    varchar(24)         not null,
    result                   varchar(80)         not null,
    feedback                 text                not null,

    primary key ( id )
);
create index hrm_matriculations_user        on hrm_matriculations ( ref_user );
create index hrm_matriculations_course      on hrm_matriculations ( ref_course );
create index hrm_matriculations_team        on hrm_matriculations ( ref_team );
create index hrm_matriculations_unit        on hrm_matriculations ( ref_unit );
create index hrm_matriculations_department  on hrm_matriculations ( ref_department );
create index hrm_matriculations_sector      on hrm_matriculations ( ref_sector );

-- --------------------------------------------------------
-- HRM_REQUIREMENTS
--
-- Stores: com.interact.sas.hrm.data.Requirement
-- --------------------------------------------------------
create table hrm_requirements
(
    ref_function              int                 not null,    -- References: cmn_functions.id
    ref_qualification         int                 not null,    -- References: hrm_qualifications.id
    skill                     smallint            not null,

    unique ( ref_function, ref_qualification )
);

-- --------------------------------------------------------
-- Table HRM_CAPACITATIONS
--
-- Stores: N/A
-- --------------------------------------------------------
create table hrm_capacitations
(
    ref_course                int                 not null,    -- References: hrm_courses.id
    ref_qualification         int                 not null,    -- References: hrm_qualifications.id

    unique ( ref_course, ref_qualification )
);

-- --------------------------------------------------------
-- HRM_JOBS
--
-- Stores: com.interact.sas.hrm.data.Job
-- --------------------------------------------------------
create table hrm_jobs
(
    id                          int                 not null,
    ref_user                    int                 not null,    -- References: cmn_users.id
    dt_start                    date                default null,
    dt_end                      date                default null,
    "function"                  varchar(80)         not null,
    location                    varchar(80)         not null,
    department                  varchar(80)         not null,
    type_job                    varchar(80)         not null,
    reference                   varchar(160)        not null,
    organization                varchar(160)        not null,
    activities                  text                not null,

    primary key  ( id )
);

-- --------------------------------------------------------
-- HRM_DEFICIENTS
--
-- Stores: com.interact.sas.hrm.data.Deficiency
-- --------------------------------------------------------
create table hrm_deficiencies
(
    ref_user             int        not null,    -- References: cmn_users.id
    ref_function         int        not null,    -- References: cmn_functions.id
    ref_qualification    int        not null,    -- References: hrm_qualifications.id
    current_skill        int        not null,
    skill                tinyint    not null,

    unique ( ref_user, ref_function, ref_qualification )
);

-- --------------------------------------------------------
-- HRM_INSCRIPTIONS
--
-- Stores: N/A
-- --------------------------------------------------------
create table hrm_inscriptions
(
    ref_team    int    not null,    -- References: cmn_groups.id
    ref_user    int    not null,    -- References: cmn_users.id

    unique ( ref_team, ref_user )
);

-- --------------------------------------------------------
-- HRM_PARTICIPANTS
--
-- Stores: com.interact.sas.hrm.data.Participation
-- --------------------------------------------------------
create table hrm_participations
(
    ref_team       int         not null,    -- References: cmn_groups.id
    ref_session    int         not null,    -- References: hrm_sessions.id
    ref_user       int         not null,    -- References: cmn_users.id
    role           tinyint     not null,    -- See: com.interact.sas.hrm.data.Participation.ROLES
    score          smallint    not null,
    state          smallint    not null,    -- See: com.interact.sas.hrm.data.Participation.STATE
    feedback       text        not null,

    unique ( ref_session, ref_user )
);
create index hrm_participations_session on hrm_participations ( ref_session );
create index hrm_participations_team    on hrm_participations ( ref_team );

-- --------------------------------------------------------
-- HRM_RATING_SCALES
--
-- Stores: com.interact.sas.hrm.data.RatingScale
-- --------------------------------------------------------
create table hrm_rating_scales
(
    id                          int             not null,
    ref_questionnaire           int             default 0,    -- References: hrm_pr_questionnaires.id
    family                      int             not null,     -- See: com.interact.sas.hrm.data.RatingScale.FAMILY 
    max_option                  double          not null,
    name                        varchar(160)    not null,

    primary key  ( id )
);
create index hrm_rating_scales_family on hrm_rating_scales ( family );

-- --------------------------------------------------------
-- HRM_RATING_SCALE_OPTIONS
--
-- Stores: com.interact.sas.hrm.data.RatingScaleOption
-- --------------------------------------------------------
create table hrm_rating_scale_options
(
    ref_scale           int            not null,    -- References: hrm_rating_scales.id
    fl_rating           int            not null,
    justify_required    tinyint        not null,
    score               double         not null,
    name                varchar(80)    not null,
    info                text           not null,
    
    unique ( ref_scale, name )
);
create index hrm_rat_scale_opt_ref on hrm_rating_scale_options ( ref_scale );

-- --------------------------------------------------------
-- HRM_RATERS
--
-- Stores: com.interact.sas.hrm.data.Rater
-- --------------------------------------------------------
create table hrm_raters
(
    ref_user                     int            not null,     -- References: cmn_users.id
    ref_occurrence               int            not null,     -- References: hrm_cr_occurrences.id
    ref_employee                 int            not null,     -- References: cmn_employments.id
    family                       tinyint        default 0,    -- See: com.interact.sas.hrm.data.Rater.FAMILY 
    type                         smallint       not null,     -- See: com.interact.sas.hrm.data.Rater.RATING_TYPES 
    period_from                  date           not null,
    period_until                 date           not null,
    role                         varchar(160)   not null,

    unique ( ref_user, ref_occurrence, type, family )
);
create index hrm_raters_user         on hrm_raters (ref_user);
create index hrm_raters_occurrence   on hrm_raters (ref_occurrence);
create index hrm_raters_employee     on hrm_raters (ref_employee);
create index hrm_raters_type         on hrm_raters (type);
create index hrm_raters_period_from  on hrm_raters (period_from);
create index hrm_raters_period_until on hrm_raters (period_until);
create index hrm_raters_family       on hrm_raters ( family );

-- --------------------------------------------------------
-- HRM_OCCURRENCES
--
-- Stores: com.interact.sas.hrm.data.RatingOccurrence
-- --------------------------------------------------------
create table hrm_occurrences
(
    id                           int            not null,
    ref_user                     int            not null,        -- References: cmn_users.id
    ref_function                 int            not null,        -- References: cmn_functions.id
    ref_cycle                    int            not null,        -- References: hrm_cr_cycle.id
    ref_unit                     int            not null,        -- References: cmn_units.id
    ref_department               int            not null,        -- References: cmn_departments.id
    ref_sector                   int            not null,        -- References: cmn_sectors.id
    period_from                  date           not null,
    period_until                 date           not null,
    dt_opened                    date           default null,
    dt_closed                    date           default null,
    state                        smallint       not null,        -- See: com.interact.sas.hrm.data.RatingOccurrence.STATES 
    weight_organizational        double         not null,
    justification                text           not null,
    evaluation_number            int            not null,
    family                       int            not null,        -- See: com.interact.sas.hrm.data.RatingOccurrence.FAMILY

    primary key  ( id )
);
create index hrm_occurrences_user     on hrm_occurrences (ref_user);
create index hrm_occurrences_function on hrm_occurrences (ref_function);

-- --------------------------------------------------------
-- HRM_CR_APPLICATIONS
--
-- Stores: com.interact.sas.hrm.data.RatingApplication
-- --------------------------------------------------------
create table hrm_cr_applications
(
    id                           int              not null,
    ref_occurrence               int              not null,    -- References: hrm_cr_occurrences.id
    ref_rater                    int              not null,    -- References: hrm_raters.id
    mode_result                  int,
    dt_opened                    date             not null,
    dt_closed                    date             default null,
    type                         smallint         not null,
    state                        smallint         not null,    -- See: com.interact.sas.hrm.data.RatingApplication.STATES
    score_achieved               double           not null,
    score_max                    double           not null,
    role                         varchar(160)     not null,
    mode_info                    varchar(4000),
    feedback                     text,
    
    primary key  ( id )
);
create index hrm_cr_applications_occur on hrm_cr_applications (ref_occurrence);
create index hrm_cr_applications_rater on hrm_cr_applications (ref_rater);
create index hrm_cr_applications_type  on hrm_cr_applications (type);

-- --------------------------------------------------------
-- HRM_RATING_CLASSIFICATIONS
--
-- Stores: com.interact.sas.hrm.data.RatingClassification
-- --------------------------------------------------------
create table hrm_classification_scale_items
(
    id                          int               not null,
    color                       int               not null,
    result                      int               default 0,
    ref_scale                   int               not null,    -- References: hrm_rating_scales.id
    update_by                   int               not null,
    score_from                  double            not null,
    score_until                 double            not null,
    update_at                   date              not null,
    name                        varchar(80)       not null,

    primary key  ( id )
);
create index hrm_classifications_color      on hrm_classification_scale_items ( color );
create index hrm_classifications_ref_scale  on hrm_classification_scale_items ( ref_scale );
create index hrm_classifications_update_by  on hrm_classification_scale_items ( update_by );

-- --------------------------------------------------------
-- HRM_CR_RESULTS
--
-- Stores: com.interact.sas.hrm.data.Result
-- --------------------------------------------------------
create table hrm_cr_results
(
    ref_application              int                not null,    -- References: hrm_cr_applications.id
    ref_qualification            int                not null,    -- References: hrm_qualifications.id
    ref_evidences                int                not null,    -- References: hrm_evidences.id
    fl_rating                    int                not null,
    score_achieved               double             not null,
    score_max                    double             not null,
    "option"                     varchar(80)        not null,
    info                         text               not null,
    
    unique ( ref_application, ref_qualification, ref_evidences )
);
create index hrm_cr_results_evidence      on hrm_cr_results ( ref_evidences );
create index hrm_cr_results_application   on hrm_cr_results ( ref_application );
create index hrm_cr_results_qualification on hrm_cr_results ( ref_qualification );

-- --------------------------------------------------------
-- HRM_SESSIONS
--
-- Stores: com.interact.sas.hrm.data.Session
-- --------------------------------------------------------
create table hrm_sessions
(
    id                int             not null,
    ref_team          int             not null,    -- References: cmn_groups.id
    ref_course        int             not null,    -- References: hrm_courses.id
    ref_instructor    int             not null,    -- References: hrm_sessions_instructor
    participants      int             not null,
    state             smallint        not null,    -- See: com.interact.sas.hrm.data.Session.STATES
    duration          double          not null,
    idle              double          not null,
    dt_due            date            default null,
    tm_start          varchar(20)     not null,
    tm_finish         varchar(20)     not null,
    name              varchar(160)    not null,
    instructor        varchar(160)    not null,
    location          varchar(160)    not null,
    info              text            not null,

    primary key ( id )
);
create index hrm_sessions_team       on hrm_sessions ( ref_team );
create index hrm_sessions_course     on hrm_sessions ( ref_course );
create index hrm_sessions_instructor on hrm_sessions ( ref_instructor );

-- --------------------------------------------------------
-- HRM_SKILLS
--
-- Stores: com.interact.sas.hrm.data.Skill
-- --------------------------------------------------------
create table hrm_skills
(
    ref_user             int        not null,    -- References: cmn_users.id
    ref_qualification    int        not null,    -- References: hrm_qualifications.id
    ref_matriculation    int        not null,    -- References: hrm_matriculations.id
    ref_function         int        not null,    -- References: cmn_functions.id
    level_required       int        not null,
    "level"              tinyint    not null,

    unique ( ref_user, ref_qualification, ref_matriculation, ref_function )
);
create index hrm_skills_function      on hrm_skills ( ref_function );
create index hrm_skills_user          on hrm_skills ( ref_user );
create index hrm_skills_qualification on hrm_skills ( ref_qualification );
create index hrm_skills_matriculation on hrm_skills ( ref_matriculation );

-- --------------------------------------------------------
-- HRM_TEAMS
--
-- Stores: com.interact.sas.hrm.data.Team
-- --------------------------------------------------------
create table hrm_teams
(
   id                      int            not null,
   ref_course              int            not null,    -- References: hrm_courses.id
   state                   int            not null,    -- See: com.interact.sas.hrm.data.Team.STATES
   total_participants      int            not null,
   average_participants    int            not null,
   active_session          int            not null,
   certificate             int            not null,
   validity_value          int            not null,
   validity_type           tinyint        not null,
   total_hours             double         not null,
   due_hours               double         not null,
   dt_certificate          date           null,
   name                    varchar(80)    not null,
   info                    text           not null,
   feedback                text           not null,

   primary key ( id )
);
create index hrm_teams_course on hrm_teams ( ref_course );

-- --------------------------------------------------------
-- HRM_OBJECTIVES
--
-- Stores: N/A
-- --------------------------------------------------------
create table hrm_objectives
(
    ref_qualification             int             not null,    -- References: hrm_qualifications.id
    ref_objective                 int             not null,    -- References: hrm_objectives.id

    unique ( ref_qualification, ref_objective )
);

-- ------------------------------------------------------------------------------
-- HRM_CATEGORIES
--
-- Stores: com.interact.sas.hrm.data.Category
-- ------------------------------------------------------------------------------
create table hrm_categories
(
    id                      int                 not null,
    ref_user                int                 not null,     -- References: cmn_users.id
    ref_parent              int                 default 0,    -- References: hrm_categories.id
    family                  int                 not null,     -- See: com.interact.sas.hrm.data.Category.FAMILIES
    state                   smallint            not null,     -- See: com.interact.sas.hrm.data.Category.STATES
    name                    varchar(80)         not null,
    description             text                not null,

    primary key ( id )
);
create index hrm_categories_family         on hrm_categories ( family );
create index hrm_categories_name           on hrm_categories ( name );
create index hrm_categories_state          on hrm_categories ( state );

-- ------------------------------------------------------------------------------
-- HRM_CONSOLIDATIONS
--
-- Stores: com.interact.sas.hrm.data.RatingConsolidation
-- ------------------------------------------------------------------------------
create table hrm_consolidations
(
    ref_owner           int              not null,     -- References: cmn_users.id
    ref_cycle           int              not null,     -- References: hrm_cr_cycle.id
    ref_function        int              not null,     -- References: cmn_functions.id
    ref_unit            int              not null,     -- References: cmn_units.id
    ref_department      int              not null,     -- References: cmn_departments.id
    ref_sector          int              not null,     -- References: cmn_sectors.id
    score_achieved      double           not null,
    score_max           double           not null,
    family              int              default 0,    -- See: com.interact.sas.hrm.data.RatingConsolidation.FAMILY

    unique ( ref_owner, ref_cycle, ref_function, family )
);
create index hrm_consolidations_department on hrm_consolidations ( ref_department );
create index hrm_consolidations_sector     on hrm_consolidations ( ref_sector );
create index hrm_consolidations_unit       on hrm_consolidations ( ref_unit );
create index hrm_consolidations_family     on hrm_consolidations ( family );

-- ------------------------------------------------------------------------------
-- HRM_EVIDENCES
--
-- Stores: com.interact.sas.hrm.data.Evidence
-- ------------------------------------------------------------------------------
create table hrm_evidences
(
    id              int             not null,
    ref_category    int             not null,    -- References: hrm_categories.id
    name            varchar(250)    not null,
    info            text            not null,
    state           smallint        not null,    -- See: com.interact.sas.hrm.data.Evidence.STATUS 

    primary key ( id )
);
create index hrm_evidences_state    on hrm_evidences (state);
create index hrm_evidences_category on hrm_evidences (ref_category);

-- ------------------------------------------------------------------------------
-- HRM_EVIDENCES_QUALIFICATIONS
--
-- Stores: N/A
-- ------------------------------------------------------------------------------
create table hrm_evidences_qualifications
(
    ref_qualification      int        not null,    -- References: hrm_qualifications.id
    ref_evidences          int        not null,    -- References: hrm_evidences.id

    unique ( ref_qualification, ref_evidences )
);

-- ------------------------------------------------------------------------------
-- HRM_PDI_INITIATIVES
--
-- Stores: com.interact.sas.hrm.data.PDIInitiative
-- ------------------------------------------------------------------------------
create table hrm_pdi_initiatives
(
    id                  int        not null,
    ref_initiative      int        not null,    -- References: hrm_pdi_initiatives.id
    ref_occurrence      int        not null,    -- References: hrm_cr_occurrences.id
    ref_author          int        not null,    -- References: cmn_users.id
    ref_owner_update    int        not null,    -- References: cmn_users.id
    ref_top_rater       int        not null,    -- References: cmn_users.id
    ref_employment      int        not null,    -- References: cmn_employments.id
    type                tinyint    not null,    -- See: com.interact.sas.hrm.data.PDIInitiative.TYPES
    origin              tinyint    not null,    -- See: com.interact.sas.hrm.data.PDIInitiative.ORIGINS
    released            tinyint    not null,

    primary key (id)
);
create index hrm_pdi_initiatives_initiative on hrm_pdi_initiatives ( ref_initiative );
create index hrm_pdi_initiatives_occurrence on hrm_pdi_initiatives ( ref_occurrence );
create index hrm_pdi_initiatives_author     on hrm_pdi_initiatives ( ref_author );
create index hrm_pdi_initiatives_update     on hrm_pdi_initiatives ( ref_owner_update );
create index hrm_pdi_initiatives_top_rater  on hrm_pdi_initiatives ( ref_top_rater );
create index hrm_pdi_initiatives_employment on hrm_pdi_initiatives ( ref_employment );
create index hrm_pdi_initiatives_type       on hrm_pdi_initiatives ( type );
create index hrm_pdi_initiatives_origin     on hrm_pdi_initiatives ( origin );
create index hrm_pdi_initiatives_released   on hrm_pdi_initiatives ( released );

-- ------------------------------------------------------------------------------
-- HRM_CYCLES
--
-- Stores: com.interact.sas.hrm.data.RatingCycle
-- ------------------------------------------------------------------------------
create table hrm_cycles
(
    id                          int            not null,
    ref_owner                   int            not null,    -- References: cmn_users.id
    ref_category                int            not null,    -- References: hrm_categories.id
    "mode"                      int            not null,    -- See: com.interact.sas.hrm.data.RatingCycle.MODE_OPTIONS 
    revision_number             int            not null,
    competence                  int            not null,
    ind_consensus               tinyint        not null,
    ind_pairs                   tinyint        not null,
    ind_staff                   tinyint        not null,
    ind_top                     tinyint        not null,
    ind_self_rating             tinyint        not null,
    ind_client                  tinyint        not null,
    state                       smallint       not null,    -- See: com.interact.sas.hrm.data.RatingCycle.STATUS
    weight_pairs                double         not null,
    weight_top                  double         not null,
    weight_staff                double         not null,
    weight_self_rating          double         not null,
    weight_client               double         not null,
    weight_individual_target    double         not null,
    weight_team_target          double         not null,
    weight_global_target        double         not null,
    dt_start                    date           not null,
    dt_end                      date           not null,
    dt_rating_start             date           not null,
    dt_rating_end               date           not null,
    dt_hiring_start             date           null,
    dt_hiring_end               date           null,
    dt_approval_start           date           null,
    dt_approval_end             date           null,
    "options"                   varchar(32)    not null,
    name                        varchar(80)    not null,
    description                 text           not null,

    primary key (id)
);
create index hrm_cycles_category     on hrm_cycles ( ref_category );
create index hrm_cycles_competence   on hrm_cycles ( competence );

-- ------------------------------------------------------------------------------
-- HRM_FUNCTION_MAPPINGS
--
-- Stores: com.interact.sas.hrm.data.FunctionMapping
-- ------------------------------------------------------------------------------
create table hrm_function_mappings
(
    ref_function             int              not null,    -- References: cmn_functions.id
    ref_qualification        int              not null,    -- References: hrm_qualifications.id
    ref_cycle                int              not null,    -- References: hrm_cr_cycle.id
    ref_owner                int              not null,    -- References: cmn_users.id
    ref_evidence             int              not null,    -- References: hrm_evidences.id
    target                   double           not null,
    weight                   double           not null,
    weight_evidence          double precision not null,

    unique ( ref_function, ref_qualification, ref_cycle, ref_evidence )
);
create index hrm_function_mappings_owner on hrm_function_mappings ( ref_owner );

-- -----------------------------------------------------------------------------
-- HRM_PR_CYCLES
--
-- Stores: com.interact.sas.hrm.data.PerformanceRatingCycle
-- -----------------------------------------------------------------------------
create table hrm_pr_cycles
(
    id                      int                 not null,
    ref_owner               int                 not null,     -- References: cmn_users.id
    ref_category            int                 not null,     -- References: hrm_categories.id
    competence              int                 not null,
    state                   tinyint             default 0,    -- See: com.interact.sas.hrm.data.PerformanceRatingCycleS.TATUS
    fl_manager              tinyint             not null,
    fl_self_rating          tinyint             not null,
    fl_questionnaire        tinyint             not null,
    dt_start                date                not null,
    dt_end                  date                not null,
    dt_rating_start         date                not null,
    dt_rating_end           date                not null,
    name                    varchar(160)        not null,
    description             text                not null,

    primary key ( id )
);
create index hrm_pr_cycles_category   on hrm_pr_cycles ( ref_category );
create index hrm_pr_cycles_competence on hrm_pr_cycles ( competence );
create index hrm_pr_cycles_owner      on hrm_pr_cycles ( ref_owner );
create index hrm_pr_cycles_state      on hrm_pr_cycles ( state );

-- -----------------------------------------------------------------------------
-- HRM_PR_OCCURRENCES
--
-- Stores: com.interact.sas.hrm.data.PerformanceRatingOccurrence
-- -----------------------------------------------------------------------------
create table hrm_pr_occurrences
(
    id                      int                 not null,
    ref_user                int                 not null,    -- References: cmn_users.id
    ref_function            int                 not null,    -- References: cmn_functions.id
    ref_cycle               int                 not null,    -- References: hrm_pr_cycles.id
    ref_unit                int                 not null,    -- References: cmn_units.id
    ref_department          int                 not null,    -- References: cmn_departments.id
    ref_sector              int                 not null,    -- References: cmn_sectors.id
    dt_period_from          date                not null,
    dt_period_until         date                not null,
    dt_closed               date                null,
    state                   tinyint             not null,    -- See: com.interact.sas.hrm.data.PerformanceRatingOccurrence.STATES
    fl_questionnaire        tinyint             not null,
    score_final             double              not null,
    justification           text                not null,
    info                    text                not null,

    primary key ( id )
);
create index hrm_pr_occurrences_cycle      on hrm_pr_occurrences ( ref_cycle );
create index hrm_pr_occurrences_department on hrm_pr_occurrences ( ref_department );
create index hrm_pr_occurrences_function   on hrm_pr_occurrences ( ref_function );
create index hrm_pr_occurrences_sector     on hrm_pr_occurrences ( ref_sector );
create index hrm_pr_occurrences_state      on hrm_pr_occurrences ( state );
create index hrm_pr_occurrences_unit       on hrm_pr_occurrences ( ref_unit );
create index hrm_pr_occurrences_user       on hrm_pr_occurrences ( ref_user );

-- --------------------------------------------------------
-- HRM_PR_APPLICATIONS
--
-- Stores: com.interact.sas.hrm.data.PerformanceRatingApplication
-- --------------------------------------------------------
create table hrm_pr_applications
(
    id              int            not null,
    ref_occurrence  int            not null,    -- References: hrm_pr_occurrences
    ref_target      int            not null,    -- References: hrm_pr_targets.id
    ref_result      int            not null,    -- References: hrm_pr_results.id
    ref_rater       int            not null,    -- References: hrm_raters.id
    state           tinyint        not null,    -- See: com.interact.sas.hrm.data.PerformanceRatingApplication.STATES
    weight          double         not null,
    target_value    double         not null,

    primary key ( id )
);
create index hrm_pr_applications_ocurrence on hrm_pr_applications ( ref_occurrence );
create index hrm_pr_applications_rater     on hrm_pr_applications ( ref_rater );
create index hrm_pr_applications_result    on hrm_pr_applications ( ref_result );
create index hrm_pr_applications_state     on hrm_pr_applications ( state );
create index hrm_pr_applications_target    on hrm_pr_applications ( ref_target );

-- --------------------------------------------------------
-- HRM_PR_RESULTS
--
-- Stores: com.interact.sas.hrm.data.PerformanceRatingResultItem
-- --------------------------------------------------------
create table hrm_pr_results
(
    id                 int            not null,
    ref_application    int            not null,    -- References: hrm_pr_applications.id
    user_rating        int            not null,
    score_weighted     double         not null,
    score_rated        double         not null,
    score_achieved     double         not null,
    percent_achieved   double         not null,
    dt_rating          date           null,
    info               text           not null,
    justify            text           default null,

    primary key ( id )
);
create index hrm_pr_results_application on hrm_pr_results ( ref_application );
create index hrm_pr_results_user        on hrm_pr_results ( user_rating );

-- --------------------------------------------------------
-- HRM_PR_TARGETS
--
-- Stores: com.interact.sas.hrm.data.PerformanceTarget
-- --------------------------------------------------------
create table hrm_pr_targets
(
    id                      int                 not null,
    ref_cycle               int                 not null,    -- References: hrm_pr_cycles.id
    ref_category            int                 not null,    -- References: hrm_categories.id
    ref_source              int                 not null,    -- References: source item id
    ref_indicator           int                 null,        -- References: bsc_indicators.id
    ref_owner               int                 not null,    -- References: cmn_users.id
    target_direction        int                 not null,
    scope                   tinyint             not null,    -- See: com.interact.sas.hrm.data.PerformanceTarget.SCOPES
    type                    tinyint             not null,    -- See: com.interact.sas.hrm.data.PerformanceTarget.TYPES
    weight                  double              not null,
    target_value            double              not null,
    dt_period_from          date                not null,
    dt_period_until         date                not null,
    dt_created              date                not null,
    dt_changed              date                null,
    name                    varchar(250)        not null,
    description             text                not null,

    primary key ( id )
);
create index hrm_pr_targets_category  on hrm_pr_targets ( ref_category );
create index hrm_pr_targets_cycle     on hrm_pr_targets ( ref_cycle );
create index hrm_pr_targets_indicator on hrm_pr_targets ( ref_indicator );
create index hrm_pr_targets_owner     on hrm_pr_targets ( ref_owner );
create index hrm_pr_targets_scope     on hrm_pr_targets ( scope );
create index hrm_pr_targets_source    on hrm_pr_targets ( ref_source );
create index hrm_pr_targets_type      on hrm_pr_targets ( type );

-- --------------------------------------------------------
-- HRM_PR_QUESTIONNAIRES
--
-- Stores: com.interact.sas.hrm.data.Questionnaire
-- --------------------------------------------------------
create table hrm_pr_questionnaires 
( 
    id            int            not null,
    ref_cycle     int            not null,    -- References: hrm_pr_cycles.id
    ref_scale     int            not null,    -- References: hrm_rating_scales
    ref_origin    int            not null,    -- References: origin item id
    state         int            not null,    -- See: com.interact.sas.hrm.data.Questionnaire.STATE
    name          varchar(80)    not null,
    info          text           not null,

    primary key ( id )
);
create index hrm_pr_questionnaires_cycle  on hrm_pr_questionnaires ( ref_cycle );
create index hrm_pr_questionnaires_origin on hrm_pr_questionnaires ( ref_origin );
create index hrm_pr_questionnaires_scale  on hrm_pr_questionnaires ( ref_scale );
create index hrm_pr_questionnaires_state  on hrm_pr_questionnaires ( state );

-- --------------------------------------------------------
-- HRM_PR_QUESTIONNAIRE_TOPICS
--
-- Stores: com.interact.sas.hrm.data.QuestionnaireTopic
-- --------------------------------------------------------
create table hrm_pr_questionnaire_topics 
(
    id                      int             not null,
    ref_questionnaire       int             not null,    -- References: hrm_pr_questionnaires.id
    name                    varchar(250)    not null,
    info                    text            not null,

    primary key ( id )
);
create index hrm_pr_questionnaire_topics_questionnaire on hrm_pr_questionnaire_topics ( ref_questionnaire );

-- --------------------------------------------------------
-- HRM_PR_WEIGHTS
--
-- Stores: com.interact.sas.hrm.data.Weight
-- --------------------------------------------------------
create table hrm_pr_weights 
( 
    ref_function           int      not null,    -- References: cmn_functions.id
    ref_cycle              int      not null,    -- References: hrm_pr_cycles.id
    ref_questionnaire      int      not null,    -- References: hrm_pr_questionnaires.id
    ref_owner              int      not null,    -- References: cmn_users.id
    weight_indicators      double   not null,
    weight_questionnaire   double   not null,

    unique ( ref_function, ref_cycle, ref_questionnaire )
);
create index hrm_pr_weights_cycle         on hrm_pr_weights ( ref_cycle );
create index hrm_pr_weights_function      on hrm_pr_weights ( ref_function );
create index hrm_pr_weights_owner         on hrm_pr_weights ( ref_owner );
create index hrm_pr_weights_questionnaire on hrm_pr_weights ( ref_questionnaire );

-- --------------------------------------------------------
-- HRM_PR_QUESTIONNAIRE_RESULT
--
-- Stores: com.interact.sas.hrm.data.Result
-- --------------------------------------------------------
create table hrm_pr_questionnaire_result
(
    ref_occurrence      int         not null,    -- References: hrm_pr_occurrences.id
    ref_questionnaire   int         not null,    -- References: hrm_pr_questionnaires.id
    ref_question        int         not null,    -- References: hrm_pr_questionnaires.id
    state               tinyint     not null,
    score_achieved      double      not null,
    score_max           double      not null,
    "option"            varchar(80) not null,
    justification       text        not null,

    unique key ( ref_occurrence, ref_questionnaire, ref_question )
);
create index hrm_pr_questionnaire_result_occurrence    on hrm_pr_questionnaire_result ( ref_occurrence );
create index hrm_pr_questionnaire_result_questionnaire on hrm_pr_questionnaire_result ( ref_questionnaire );
create index hrm_pr_questionnaire_result_question      on hrm_pr_questionnaire_result ( ref_question );
create index hrm_pr_questionnaire_result_state         on hrm_pr_questionnaire_result ( state );

-- --------------------------------------------------------
-- HRM_MAPPINGS_SCALES
--
-- Stores: com.interact.sas.hrm.data.MappingScale
-- --------------------------------------------------------
create table hrm_mappings_scales
(
    id                int            not null,
    ref_cycle_graph   int            not null,    -- References: hrm_cycles_graphics.id
    type              int            not null,    -- See: com.interact.sas.hrm.data.MappingScale.TYPES
    state             int            not null,    -- See: com.interact.sas.hrm.data.MappingScale.STATES
    name              varchar(250)   not null,
    info              text           not null,

    primary key ( id )
);
create index hrm_map_scales_cycle on hrm_mappings_scales ( ref_cycle_graph );
create index hrm_map_scales_state on hrm_mappings_scales ( state );
create index hrm_map_scales_type  on hrm_mappings_scales ( type );

-- --------------------------------------------------------
-- HRM_MAPPING_SCALE_OPTIONS
--
-- Stores: com.interact.sas.hrm.data.MappingScaleOption
-- --------------------------------------------------------
create table hrm_mapping_scale_options
(
    ref_mappings_scales    int            not null,    -- References: hrm_mappings_scales.id
    color                  int            not null,
    score_from_x           double         not null,
    score_until_x          double         not null,
    score_from_y           double         not null,
    score_until_y          double         not null,
    name                   varchar(250)   not null

);
create index hrm_map_options_ref_scale on hrm_mapping_scale_options ( ref_mappings_scales );

-- --------------------------------------------------------
-- HRM_CYCLES_GRAPHICS
--
-- Stores: com.interact.sas.hrm.data.CyclesGraphic
-- --------------------------------------------------------
create table hrm_cycles_graphics
(
    id                int           not null,
    ref_cycle_cr      int           not null,    -- References: hrm_cr_cycle.id
    ref_cycle_pr      int           not null,    -- References: hrm_pr_cycles.id
    type              int           not null,
    created_by        int           not null,
    updated_by        int           default 0,
    created_at        date          not null,
    updated_at        date          null,
    info              text          not null,

    primary key ( id )
);
create index hrm_graphics_cycle_created_by on hrm_cycles_graphics ( created_by );
create index hrm_graphics_cycle_cr         on hrm_cycles_graphics ( ref_cycle_cr );
create index hrm_graphics_cycle_pr         on hrm_cycles_graphics ( ref_cycle_pr );
create index hrm_graphics_cycle_type       on hrm_cycles_graphics ( type );
create index hrm_graphics_cycle_updated_by on hrm_cycles_graphics ( updated_by );

-- --------------------------------------------------------
-- HRM_EMPLOYMENT_STATES
--
-- Stores: com.interact.sas.hrm.data.EmploymentState
-- --------------------------------------------------------
create table hrm_employment_states
(
    ref_source          int      not null,    -- References: item source id
    num_qualified       int      default 0,
    num_unqualified     int      default 0,
    family              tinyint  not null,    -- See: com.interact.sas.hrm.data.EmploymentState.FAMILY 
    
    unique key ( family, ref_source )
);
create index hrm_employment_states_family   on hrm_employment_states ( family );
create index hrm_employment_states_source   on hrm_employment_states ( ref_source );

-- --------------------------------------------------------
-- HRM_CLASSIFICATIONS_SCALES
--
-- Stores: com.interact.sas.hrm.data.ClassificationsScale
-- --------------------------------------------------------
create table hrm_classifications_scales
(
    id                  int             not null,
    ref_cycle           int             not null,    -- References: hrm_cr_cycle.id
    state               int             not null,    -- See: com.interact.sas.hrm.data.ClassificationsScale.STATES
    family              int             not null,    -- See: com.interact.sas.hrm.data.ClassificationsScale.FAMILY
    classification      int             not null,
    created_by          int             not null,
    created_at          date            null,
    name                varchar(250)    not null,
    info                text            not null,

    primary key ( id )
);
create index hrm_classifications_scales_ref_cycle    on hrm_classifications_scales ( ref_cycle );
create index hrm_classifications_scales_state        on hrm_classifications_scales ( state );
create index hrm_classifications_scales_family       on hrm_classifications_scales ( family );
create index hrm_classifications_scales_created_by   on hrm_classifications_scales ( created_by );

-- --------------------------------------------------
-- HRM_PDI_QUALIFICATIONS
--
-- Stores: N/A
-- --------------------------------------------------
create table hrm_pdi_qualifications
(
    ref_pdi_initiative  int not null,    -- References: hrm_pdi_initiatives.id
    ref_qualification   int not null,    -- References: hrm_pdi_qualifications.id

    unique key (ref_pdi_initiative, ref_qualification)
);
create index hrm_pdi_qualifications_initiative    on hrm_pdi_qualifications ( ref_pdi_initiative );
create index hrm_pdi_qualifications_qualification on hrm_pdi_qualifications ( ref_qualification );

-- --------------------------------------------------
-- HRM_PDI_TARGETS
--
-- Stores: N/A
-- --------------------------------------------------
create table hrm_pdi_targets
(
    ref_pdi_initiative  int not null,    -- References: hrm_pdi_initiatives.id
    ref_target          int not null,    -- References: hrm_pdi_targets.id

    unique key (ref_pdi_initiative, ref_target)
);
create index hrm_pdi_targets_initiative on hrm_pdi_targets ( ref_pdi_initiative );
create index hrm_pdi_targets_target     on hrm_pdi_targets ( ref_target );

-- --------------------------------------------------
-- HRM_PDI_TARGETS
--
-- Stores: com.interact.sas.hrm.data.SkillQualificationMapping
-- --------------------------------------------------
create table hrm_course_skills
(
    ref_qualification int(11) not null,    -- References: hrm_qualifications.id
    ref_course        int(11) not null,    -- References: hrm_courses.id
    skill_level       int(11) not null,

    unique ( ref_course, ref_qualification )
);
create index hrm_course_skills_qualification on hrm_course_skills( ref_qualification );
create index hrm_course_skills_course        on hrm_course_skills( ref_course );

-- ------------------------------------------------------------------------------
-- HRM_FEEDBACKS
--
-- Stores: com.interact.sas.hrm.data.Feedback
-- ------------------------------------------------------------------------------
create table hrm_feedbacks
(
    id                 int              not null,
    ref_author         int              not null,   -- References: cmn_users.id
    ref_user           int              not null,   -- References: cmn_users.id
    type               tinyint          not null,   -- See: com.interact.sas.hrm.data.Feedback.TYPES
    state              tinyint          not null,   -- See: com.interact.sas.hrm.data.Feedback.STATES
    dt_performed       date             null,
    dt_confirmation    date             null,
    positive_info      text             null,
    to_improve_info    text             null,
    comments           text             null,
    considerations     text             null,

    primary key ( id )
);
create index hrm_feedbacks_author on hrm_feedbacks( ref_author );
create index hrm_feedbacks_user   on hrm_feedbacks( ref_user );

-- --------------------------------------------------------
-- HRM_RT_TARGETS
--
-- Stores: com.interact.sas.hrm.data.Target
-- --------------------------------------------------------
create table hrm_rt_targets 
(
    id                 int             not null,
    ref_application    int             not null,    -- References: hrm_rt_ratings.id
    ref_indicator      int             null,        -- References: bsc_indicators.id
    ref_owner          int             not null,    -- References: cmn_users.id
    state              int             not null,    -- See: com.interact.sas.hrm.data.Target.STATE
    weight             double          not null,
    target_value       double          not null,
    score              double          null,
    date_from          date            null,
    date_until         date            null,
    name               varchar(250)    null,    
    description        text            null,
    
    primary key ( id )
);
create index hrm_rt_targets_application    on hrm_rt_targets( ref_application );
create index hrm_rt_targets_indicator      on hrm_rt_targets( ref_indicator );
create index hrm_rt_targets_owner          on hrm_rt_targets( ref_owner );

-- --------------------------------------------------------
-- HRM_RT_APPLICATIONS 
-- 
-- Stores: com.interact.sas.hrm.data.RatingTargetApplication
-- --------------------------------------------------------
create table hrm_rt_applications
(    
    id                int       not null,
    ref_occurrence    int       not null,    -- References: hrm_occurrences.id
    ref_owner         int       not null,    -- References: cmn_users.id
    ref_hirer         int       not null,    -- References: cmn_users.id
    ref_approver      int       not null,    -- References: cmn_users.id
    ref_rater         int       not null,    -- References: cmn_users.id
    state             int       not null,    -- See: com.interact.sas.hrm.data.RatingTargetApplication.STATES
    type              int       not null,    -- See: com.interact.sas.hrm.data.RatingTargetApplication.TYPES
    score             double    null,

    primary key ( id )
);
create index hrm_rt_applications_occurrence on hrm_rt_applications( ref_occurrence );
create index hrm_rt_applications_owner      on hrm_rt_applications( ref_owner );
create index hrm_rt_applications_hirer      on hrm_rt_applications( ref_hirer );
create index hrm_rt_applications_approver   on hrm_rt_applications( ref_approver );
create index hrm_rt_applications_rater      on hrm_rt_applications( ref_rater );

-- --------------------------------------------------------
-- HRM_RT_TEAM_MAPPINGS
-- 
-- Stores: com.interact.sas.hrm.data.RatingTargetTeamMapping
-- --------------------------------------------------------
create table hrm_rt_team_mappings
(
    ref_application    int    not null,    -- References: hrm_rt_applications.id
    ref_employee       int    not null,    -- References: cmn_employments.id

    unique ( ref_application, ref_employee )
);