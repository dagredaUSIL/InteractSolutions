-- ----------------------------------------------------------------------------
--
-- Module:   DAT
--
-- Schema:   80.1
--
-- Revision: 
--
-- Date:     
--
-- URL:      $URL: svn://svn.interact.com.br/sas/work/6.5.0.0/schema/db/install/40/mysql/schema-dat.sql $
--
-- Author:   Thomas Spriestersbach (ts@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- --------------------------------------------------------
-- DAT_IMPORTS
--
-- Stores: N/A
-- --------------------------------------------------------
create table dat_imports
(
    value         double            not null,
    created       timestamp         not null default current_timestamp,
    competence    date              not null,
    origin        varchar(40)       not null,
    mnemonic      varchar(60)       not null,

    unique ( mnemonic, competence )
);