-- ----------------------------------------------------------------------------
--
-- Module:   MOB
--
-- Schema:   80.1
--
-- Revision: $Revision$
--
-- Date:     $Date$
--
-- URL:      $URL$
--
-- Author:   Tiago Ely (te@interact.com.br)
--
-- -----------------------------------------------------------------------------

-- -----------------------------------------------------------------------------
-- MOB_NOTIFICATION_TOKENS
--
-- Stores: com.interact.sas.mob.data.PushNotificationToken
-- -----------------------------------------------------------------------------
create table mob_notification_tokens 
(
    id             int  not null,
    ref_user       int  not null,
    token          text not null,

    primary key ( id ),
    unique ( ref_user )
);